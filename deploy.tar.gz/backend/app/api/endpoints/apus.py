from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError
from typing import List, Optional
from app.schemas.apu import (
    APUCreate, APUResponse, APUUpdate, APUImportRequest, 
    APUBulkDeleteRequest, APUBulkDeleteResponse, APUClipboardImportItem, APULineaMoveRequest,
    APUImpactSummaryResponse, APUBatchDetailRequest
)
from app.services.apu import apu_service
from app.models.usuario import Usuario
from app.api.deps import get_db, get_current_user

router = APIRouter()

@router.get("/", response_model=List[APUResponse])
def read_apus(
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user),
    skip: int = 0,
    limit: int = 100,
    q: Optional[str] = Query(None),
    empresa_id: Optional[int] = Query(None),
    base_trabajo_id: Optional[int] = Query(None),
    base_id: Optional[int] = Query(None),
    subcategoria_item_id: Optional[int] = Query(None),
    revision: Optional[int] = Query(None)
):
    """Lista los APUs."""
    effective_base_id = base_id or base_trabajo_id
    
    target_empresa_id = current_user.empresa_id
    if current_user.rol.lower() == "superadministrador" and empresa_id:
        target_empresa_id = empresa_id
    
    from app.repositories.apu import apu_repo
    return apu_repo.get_all(
        db, target_empresa_id, effective_base_id, subcategoria_item_id, q, revision
    )[skip : skip + limit]

@router.post("/", response_model=APUResponse)
def create_apu(
    *,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user),
    apu_in: APUCreate,
    revision: Optional[int] = Query(0),
    empresa_id: Optional[int] = Query(None)
):
    """Crea un nuevo APU."""
    target_empresa_id = current_user.empresa_id
    if current_user.rol.lower() == "superadministrador" and empresa_id:
        target_empresa_id = empresa_id

    try:
        return apu_service.create_apu(db, apu_in, target_empresa_id, revision=revision)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.put("/{id}", response_model=APUResponse)
def update_apu(
    *,
    id: int,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user),
    apu_in: APUUpdate,
    empresa_id: Optional[int] = Query(None)
):
    """Actualiza un APU."""
    target_empresa_id = current_user.empresa_id
    if current_user.rol.lower() == "superadministrador" and empresa_id:
        target_empresa_id = empresa_id

    try:
        apu = apu_service.update_apu(db, id, apu_in, target_empresa_id)
        if not apu:
            raise HTTPException(status_code=404, detail="APU no encontrado")
        return apu
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.put("/{id}/lineas/move", response_model=APUResponse)
def move_apu_linea(
    *,
    id: int,
    move_in: APULineaMoveRequest,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user),
    empresa_id: Optional[int] = Query(None)
):
    target_empresa_id = current_user.empresa_id
    if current_user.rol.lower() == "superadministrador" and empresa_id:
        target_empresa_id = empresa_id

    try:
        return apu_service.move_linea(db, id, move_in.linea_id, move_in.target_index, target_empresa_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.delete("/{id}")
def delete_apu(
    id: int,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user),
    empresa_id: Optional[int] = Query(None)
):
    """Elimina un APU con validación de integridad."""
    target_empresa_id = current_user.empresa_id
    if current_user.rol.lower() == "superadministrador" and empresa_id:
        target_empresa_id = empresa_id
    
    try:
        if not apu_service.delete_apu(db, id, target_empresa_id):
            raise HTTPException(status_code=404, detail="APU no encontrado")
        return {"message": "APU eliminado correctamente"}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/bulk-delete", response_model=APUBulkDeleteResponse)
def bulk_delete_apus(
    delete_in: APUBulkDeleteRequest,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user),
    empresa_id: Optional[int] = Query(None)
):
    """Elimina múltiples APUs de forma atómica."""
    target_empresa_id = current_user.empresa_id
    if current_user.rol.lower() == "superadministrador" and empresa_id:
        target_empresa_id = empresa_id
    try:
        deleted_ids = apu_service.bulk_delete(db, delete_in.apu_ids, target_empresa_id)
        return {
            "deleted_ids": deleted_ids,
            "deleted_count": len(deleted_ids),
            "message": f"Se eliminaron {len(deleted_ids)} APUs correctamente."
        }
    except ValueError as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/{id}/duplicate", response_model=APUResponse)
def duplicate_apu(
    id: int,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user),
    empresa_id: Optional[int] = Query(None)
):
    """Duplica un APU con sus líneas."""
    target_empresa_id = current_user.empresa_id
    if current_user.rol.lower() == "superadministrador" and empresa_id:
        target_empresa_id = empresa_id
    try:
        return apu_service.duplicate_apu(db, id, target_empresa_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

@router.post("/import-clipboard")
def import_clipboard(
    items: List[APUClipboardImportItem],
    base_id: int = Query(...),
    subcat_id: int = Query(...),
    revision: Optional[int] = Query(0),
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user),
    empresa_id: Optional[int] = Query(None)
):
    """Importa APUs desde portapapeles."""
    target_empresa_id = current_user.empresa_id
    if current_user.rol.lower() == "superadministrador" and empresa_id:
        target_empresa_id = empresa_id
    try:
        return apu_service.import_clipboard(db, items, target_empresa_id, base_id, subcat_id, revision=revision)
    except ValueError as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=400, detail="No se pudo completar la importación por conflicto de códigos o duplicados en la base activa.")

@router.post("/batch/details", response_model=List[APUResponse])
def read_apus_batch_details(
    payload: APUBatchDetailRequest,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user),
    empresa_id: Optional[int] = Query(None)
):
    """Obtiene detalles completos de APUs en lote, incluyendo recursos y CPC."""
    target_empresa_id = current_user.empresa_id
    if current_user.rol.lower() == "superadministrador" and empresa_id:
        target_empresa_id = empresa_id
    return apu_service.get_apus_by_ids(db, payload.apu_ids, target_empresa_id)

@router.get("/{id}", response_model=APUResponse)
def read_apu(
    id: int,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user),
    empresa_id: Optional[int] = Query(None)
):
    """Obtener detalle completo de un APU."""
    target_empresa_id = current_user.empresa_id
    if current_user.rol.lower() == "superadministrador" and empresa_id:
        target_empresa_id = empresa_id
    
    apu = apu_service.get_apu(db, id, target_empresa_id)
    if not apu:
        raise HTTPException(status_code=404, detail="APU no encontrado")
    return apu

@router.get("/{id}/impact-summary", response_model=APUImpactSummaryResponse)
def read_apu_impact_summary(
    id: int,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user),
    empresa_id: Optional[int] = Query(None)
):
    target_empresa_id = current_user.empresa_id
    if current_user.rol.lower() == "superadministrador" and empresa_id:
        target_empresa_id = empresa_id
    try:
        return apu_service.get_apu_impact_summary(db, id, target_empresa_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

@router.post("/import-from-base")
def import_from_base(
    request: APUImportRequest,
    db: Session = Depends(get_db),
    current_user: Usuario = Depends(get_current_user),
    empresa_id: Optional[int] = Query(None)
):
    """Importa APUs y sus dependencias desde otra base de trabajo."""
    target_empresa_id = current_user.empresa_id
    if current_user.rol.lower() == "superadministrador" and empresa_id:
        target_empresa_id = empresa_id
    try:
        return apu_service.import_from_other_base(
            db=db,
            source_base_id=request.source_base_id,
            target_base_id=request.target_base_id,
            source_revision=request.source_revision or 0,
            target_revision=request.target_revision or 0,
            apu_ids=request.apu_ids,
            empresa_id=target_empresa_id,
            dry_run=request.dry_run,
            resolutions=request.resolutions,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
