from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List
from app.api import deps
from app.schemas.polinomica import FormulaPolinomicaResponse, IndiceINECResponse
from app.services.formula_polinomica import formula_polinomica_service
from app.models.polinomica import FormulaPolinomica
from app.core.database import SessionLocal

router = APIRouter()

def _verify_module_access(db: Session, presupuesto_id: int, usuario_id: int):
    from app.services.proyecto import proyecto_service
    from app.models.presupuesto import Presupuesto
    pres = db.query(Presupuesto).filter(Presupuesto.id == presupuesto_id).first()
    if not pres:
        return # Let the main logic handle 404
    
    perms = proyecto_service.get_user_permissions(db, pres.proyecto_id, usuario_id)
    if not perms["has_assignment"]:
        return
    if "todos" in perms["allowed_modules"] or "formula_polinomica" in perms["allowed_modules"]:
        return
    raise HTTPException(status_code=403, detail="Acceso denegado al módulo fórmula polinómica")

@router.get("/{presupuesto_id}", response_model=FormulaPolinomicaResponse)
def get_formula(
    presupuesto_id: int,
    db: Session = Depends(deps.get_db),
    current_user = Depends(deps.get_current_active_user)
):
    """
    Obtiene la fórmula polinómica de un presupuesto.
    Si no existe, el frontend debería invocar la regeneración.
    """
    _verify_module_access(db, presupuesto_id, current_user.id)
    formula = formula_polinomica_service.get_formula(db, presupuesto_id=presupuesto_id)
    if not formula:
        raise HTTPException(status_code=404, detail="Fórmula no encontrada para este presupuesto")

    return formula_polinomica_service.decorate_formula_view(db, presupuesto_id, formula)

@router.post("/{presupuesto_id}/regenerate", response_model=FormulaPolinomicaResponse)
def regenerate_formula(
    presupuesto_id: int,
    tipo: str = Query("SIN_DESGLOSE"),
    db: Session = Depends(deps.get_db),
    current_user = Depends(deps.get_current_active_user)
):
    """
    Calcula o recalcula los coeficientes de la fórmula basados en el presupuesto actual.
    """
    _verify_module_access(db, presupuesto_id, current_user.id)
    print(f"[API] regenerate_formula called with id={presupuesto_id} and tipo=[{tipo}]")
    try:
        formula = formula_polinomica_service.regenerate_formula(db, presupuesto_id=presupuesto_id, tipo=tipo)
        return formula
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al generar la fórmula: {e}")

@router.get("/indices-inec", response_model=List[IndiceINECResponse])
def get_indices_inec(
    db: Session = Depends(deps.get_db),
    current_user = Depends(deps.get_current_active_user)
):
    """
    Lista el catálogo de índices INEC.
    """
    from app.models.polinomica import IndiceINEC
    return db.query(IndiceINEC).all()

@router.patch("/{presupuesto_id}", response_model=FormulaPolinomicaResponse)
def update_formula(
    presupuesto_id: int,
    obj_in: dict,
    db: Session = Depends(deps.get_db),
    current_user = Depends(deps.get_current_active_user)
):
    """
    Actualiza la cabecera de la fórmula.
    """
    _verify_module_access(db, presupuesto_id, current_user.id)
    formula = formula_polinomica_service.get_formula(db, presupuesto_id=presupuesto_id)
    if not formula:
        raise HTTPException(status_code=404, detail="Fórmula no encontrada")
    
    from app.repositories.formula_polinomica import formula_polinomica_repo
    return formula_polinomica_repo.update(db, db_obj=formula, obj_in=obj_in)

@router.get("/{presupuesto_id}/resources")
def get_formula_resources(
    presupuesto_id: int, 
    db: Session = Depends(deps.get_db),
    current_user = Depends(deps.get_current_active_user)
):
    """
    Lista todos los recursos agregados en el presupuesto con su estado de asignación actual.
    """
    _verify_module_access(db, presupuesto_id, current_user.id)
    try:
        return formula_polinomica_service.get_formula_resources(db, presupuesto_id)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/{presupuesto_id}/assignments")
def save_assignments(
    presupuesto_id: int, 
    assignments: List[dict], 
    db: Session = Depends(deps.get_db),
    current_user = Depends(deps.get_current_active_user)
):
    """
    Guarda las asignaciones manuales de recursos a monomios.
    """
    _verify_module_access(db, presupuesto_id, current_user.id)
    try:
        formula_polinomica_service.save_assignments(db, presupuesto_id, assignments)
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{presupuesto_id}/indices", response_model=FormulaPolinomicaResponse)
def save_indices(
    presupuesto_id: int,
    payload: dict,
    db: Session = Depends(deps.get_db),
    current_user=Depends(deps.get_current_active_user),
):
    """
    Guarda las selecciones de índices para monomios y cuadrilla tipo.
    """
    _verify_module_access(db, presupuesto_id, current_user.id)
    try:
        formula = formula_polinomica_service.save_indices(db, presupuesto_id, payload)
        return formula_polinomica_service.decorate_formula_view(db, presupuesto_id, formula)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
