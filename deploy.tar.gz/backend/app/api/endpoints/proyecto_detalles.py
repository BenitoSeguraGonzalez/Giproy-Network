import os
import mimetypes
from pathlib import Path
import uuid
from datetime import datetime, timezone
from typing import Any, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status, Query
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from sqlalchemy import or_
from app.api import deps
from app.schemas.proyecto_detalle import ProyectoDetalleCreate, ProyectoDetalleUpdate, ProyectoDetalleResponse, ProyectoDocumentoResponse
from app.repositories.proyecto_detalle import proyecto_detalle_repo
from app.models.usuario import Usuario
from app.models.proyecto import Proyecto
from app.models.proyecto_documento import ProyectoDocumento

router = APIRouter()


def _resolve_target_empresa_id(current_user: Usuario, empresa_id: Optional[int]) -> int:
    if current_user.rol.lower() == "superadministrador" and empresa_id:
        return empresa_id
    return current_user.empresa_id


def _project_exists_for_root(db: Session, codigo_root: str, empresa_id: int) -> bool:
    return (
        db.query(Proyecto.id)
        .filter(
            Proyecto.empresa_id == empresa_id,
            or_(Proyecto.codigo_root == codigo_root, Proyecto.codigo == codigo_root),
        )
        .first()
        is not None
    )


def _resolve_project_upload_path(raw_path: str) -> Path:
    normalized = str(raw_path or "").strip().replace("\\", "/")
    if normalized.startswith("/"):
        normalized = normalized[1:]
    if not normalized.startswith("uploads/proyectos/"):
        raise HTTPException(status_code=400, detail="Ruta de imagen no permitida.")

    relative_path = Path(normalized)
    if relative_path.is_absolute():
        candidates = [relative_path]
    else:
        backend_root = Path(__file__).resolve().parents[3]
        repo_root = backend_root.parent
        candidates = [
            Path.cwd() / relative_path,
            backend_root / relative_path,
            repo_root / relative_path,
        ]

    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate

    raise HTTPException(status_code=404, detail="Imagen no encontrada.")


def _project_image_file_response(raw_path: str) -> FileResponse:
    absolute_path = _resolve_project_upload_path(raw_path)
    media_type, _ = mimetypes.guess_type(str(absolute_path))
    return FileResponse(str(absolute_path), media_type=media_type or "application/octet-stream")


def _sanitize_upload_filename(filename: str) -> str:
    raw_name = Path(filename or "documento.pdf").name.strip() or "documento.pdf"
    safe_name = "".join(char if char.isalnum() or char in (" ", ".", "_", "-") else "_" for char in raw_name)
    return safe_name[:180] or "documento.pdf"


def _ensure_project_document_access(db: Session, codigo_root: str, empresa_id: int) -> None:
    if not _project_exists_for_root(db, codigo_root, empresa_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Proyecto no encontrado o acceso denegado.")


def _load_project_document_or_404(db: Session, document_id: int, empresa_id: int) -> ProyectoDocumento:
    document = (
        db.query(ProyectoDocumento)
        .filter(
            ProyectoDocumento.id == document_id,
            ProyectoDocumento.empresa_id == empresa_id,
            ProyectoDocumento.deleted_at.is_(None),
        )
        .first()
    )
    if not document:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Documento no encontrado.")
    return document


def _project_document_file_response(document: ProyectoDocumento) -> FileResponse:
    absolute_path = Path(document.storage_path)
    if not absolute_path.exists() or not absolute_path.is_file():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Archivo PDF no encontrado.")
    return FileResponse(
        str(absolute_path),
        media_type=document.content_type or "application/pdf",
        filename=document.file_name,
    )


@router.get("/media/image-proxy")
def read_project_image_media_proxy(
    path: str = Query(...),
) -> Any:
    """
    Sirve la imagen referencial del proyecto con una ruta estable que no colisiona
    con `/{codigo_root}` y que puede usarse directamente desde etiquetas <img>.
    """
    return _project_image_file_response(path)


@router.get("/{codigo_root}/documents", response_model=list[ProyectoDocumentoResponse])
def list_project_documents(
    codigo_root: str,
    empresa_id: Optional[int] = Query(None),
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_active_user),
) -> Any:
    target_empresa_id = _resolve_target_empresa_id(current_user, empresa_id)
    _ensure_project_document_access(db, codigo_root, target_empresa_id)
    return (
        db.query(ProyectoDocumento)
        .filter(
            ProyectoDocumento.codigo_root == codigo_root,
            ProyectoDocumento.empresa_id == target_empresa_id,
            ProyectoDocumento.deleted_at.is_(None),
        )
        .order_by(ProyectoDocumento.created_at.desc(), ProyectoDocumento.id.desc())
        .all()
    )


@router.post("/{codigo_root}/documents", response_model=ProyectoDocumentoResponse)
async def upload_project_document(
    codigo_root: str,
    file: UploadFile = File(...),
    empresa_id: Optional[int] = Query(None),
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_active_user),
) -> Any:
    user_role = (current_user.rol or "").lower()
    if user_role not in ["administrador", "superadministrador"]:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No tiene permisos para subir documentos.")

    target_empresa_id = _resolve_target_empresa_id(current_user, empresa_id)
    _ensure_project_document_access(db, codigo_root, target_empresa_id)

    original_name = _sanitize_upload_filename(file.filename or "documento.pdf")
    if not original_name.lower().endswith(".pdf") or file.content_type not in {"application/pdf", "application/x-pdf"}:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Solo se permiten documentos PDF.")

    upload_dir = Path("uploads") / "proyectos" / str(target_empresa_id) / codigo_root / "documentos"
    upload_dir.mkdir(parents=True, exist_ok=True)
    unique_filename = f"{uuid.uuid4()}.pdf"
    file_path = upload_dir / unique_filename

    content = await file.read()
    if not content:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="El PDF está vacío.")

    with open(file_path, "wb") as buffer:
        buffer.write(content)

    document = ProyectoDocumento(
        codigo_root=codigo_root,
        empresa_id=target_empresa_id,
        uploaded_by_user_id=current_user.id,
        file_name=original_name,
        storage_path=str(file_path),
        content_type="application/pdf",
        size_bytes=len(content),
    )
    db.add(document)
    db.commit()
    db.refresh(document)
    return document


@router.get("/documents/{document_id}/download")
def download_project_document(
    document_id: int,
    empresa_id: Optional[int] = Query(None),
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_active_user),
) -> Any:
    target_empresa_id = _resolve_target_empresa_id(current_user, empresa_id)
    document = _load_project_document_or_404(db, document_id, target_empresa_id)
    _ensure_project_document_access(db, document.codigo_root, target_empresa_id)
    return _project_document_file_response(document)


@router.delete("/documents/{document_id}", response_model=ProyectoDocumentoResponse)
def delete_project_document(
    document_id: int,
    empresa_id: Optional[int] = Query(None),
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_active_user),
) -> Any:
    user_role = (current_user.rol or "").lower()
    if user_role not in ["administrador", "superadministrador"]:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No tiene permisos para eliminar documentos.")

    target_empresa_id = _resolve_target_empresa_id(current_user, empresa_id)
    document = _load_project_document_or_404(db, document_id, target_empresa_id)
    _ensure_project_document_access(db, document.codigo_root, target_empresa_id)
    document.deleted_at = datetime.now(timezone.utc)
    db.add(document)
    db.commit()
    db.refresh(document)
    return document

@router.get("/{codigo_root}", response_model=ProyectoDetalleResponse)
def read_proyecto_detalle(
    codigo_root: str,
    empresa_id: Optional[int] = Query(None),
    db: Session = Depends(deps.get_db),
    current_user: Usuario = Depends(deps.get_current_active_user)
) -> Any:
    """
    Obtiene los detalles comunes del proyecto.
    """
    target_empresa_id = _resolve_target_empresa_id(current_user, empresa_id)
    if not _project_exists_for_root(db, codigo_root, target_empresa_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Proyecto no encontrado o acceso denegado.")

    detalle = proyecto_detalle_repo.get_by_root(db=db, codigo_root=codigo_root, empresa_id=target_empresa_id)
    if not detalle:
        # Si no existe, devolvemos un objeto vacío con el codigo_root para inicializarlo en el front
        return {"codigo_root": codigo_root, "empresa_id": target_empresa_id}
    return detalle

@router.post("/", response_model=ProyectoDetalleResponse)
def create_or_update_proyecto_detalle(
    *,
    db: Session = Depends(deps.get_db),
    detalle_in: ProyectoDetalleCreate,
    empresa_id: Optional[int] = Query(None),
    current_user: Usuario = Depends(deps.get_current_active_user)
) -> Any:
    """
    Crea o actualiza los detalles del proyecto. Solo Admin/Superadmin.
    """
    user_role = (current_user.rol or "").lower()
    if user_role not in ["administrador", "superadministrador"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tiene permisos para modificar los detalles del proyecto."
        )

    target_empresa_id = _resolve_target_empresa_id(current_user, empresa_id)
    if not _project_exists_for_root(db, detalle_in.codigo_root, target_empresa_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Proyecto no encontrado o acceso denegado.",
        )

    db_obj = proyecto_detalle_repo.get_by_root(
        db=db,
        codigo_root=detalle_in.codigo_root,
        empresa_id=target_empresa_id,
    )
    if db_obj:
        return proyecto_detalle_repo.update(db=db, db_obj=db_obj, obj_in=detalle_in)
    else:
        return proyecto_detalle_repo.create(db=db, obj_in=detalle_in, empresa_id=target_empresa_id)

@router.post("/upload-image")
async def upload_project_image(
    file: UploadFile = File(...),
    current_user: Usuario = Depends(deps.get_current_active_user)
) -> Any:
    """
    Sube una imagen referencial del proyecto.
    """
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="El archivo debe ser una imagen.")
    
    upload_dir = "uploads/proyectos"
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir, exist_ok=True)
    
    file_extension = os.path.splitext(file.filename)[1]
    unique_filename = f"{uuid.uuid4()}{file_extension}"
    file_path = os.path.join(upload_dir, unique_filename)
    
    with open(file_path, "wb") as buffer:
        content = await file.read()
        buffer.write(content)
    
    return {"url": f"/uploads/proyectos/{unique_filename}"}


@router.get("/image-proxy")
def read_project_image_proxy(
    path: str = Query(...),
    current_user: Usuario = Depends(deps.get_current_active_user),
) -> Any:
    """
    Sirve la imagen referencial del proyecto a traves del prefijo API para evitar
    dependencias de proxy sobre /uploads.
    """
    return _project_image_file_response(path)
