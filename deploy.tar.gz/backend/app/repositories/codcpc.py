"""
Repositorio para el Catálogo CPC
"""
from sqlalchemy.orm import Session
from sqlalchemy import or_
from app.models.codcpc import CodCPC

class CodCPCRepository:
    def __init__(self, db: Session):
        self.db = db

    def get_by_id(self, cpc_id: int):
        return self.db.query(CodCPC).get(cpc_id)

    def search(self, query: str, limit: int = 50):
        """
        Busca por código o descripción. 
        Ideal para el autocompletado en el frontend.
        """
        if not query:
            return self.db.query(CodCPC).limit(limit).all()
            
        search_filter = or_(
            CodCPC.codCPC.ilike(f"%{query}%"),
            CodCPC.descripcion.ilike(f"%{query}%")
        )
        return self.db.query(CodCPC).filter(search_filter).limit(limit).all()

    def get_by_code(self, code: str):
        return self.db.query(CodCPC).filter(CodCPC.codCPC == code).first()
