"""Servicios del dominio BIM."""
