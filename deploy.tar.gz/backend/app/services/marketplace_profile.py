from app.models.usuario import Usuario


FIELD_LABELS = {
    "nombre_completo": "nombre completo",
    "ruc": "identificacion fiscal",
    "nombres": "nombres",
    "apellidos": "apellidos",
    "alias": "alias",
    "nacionalidad": "nacionalidad",
    "profesion": "profesion",
    "ciudad": "ciudad",
    "provincia": "provincia",
    "canton": "canton",
    "pais": "pais",
    "movil": "movil",
    "acepta_politica_privacidad": "aceptacion de politica de privacidad",
}


def _has_text(value) -> bool:
    return isinstance(value, str) and bool(value.strip())


def evaluate_marketplace_profile(user: Usuario) -> dict:
    missing_fields: list[str] = []
    required_text_fields = [
        "nombre_completo",
        "ruc",
        "nombres",
        "apellidos",
        "alias",
        "nacionalidad",
        "profesion",
        "ciudad",
        "provincia",
        "pais",
        "movil",
    ]

    for field in required_text_fields:
        if not _has_text(getattr(user, field, None)):
            missing_fields.append(field)

    if (getattr(user, "pais", "") or "").strip().lower() == "ecuador" and not _has_text(getattr(user, "canton", None)):
        missing_fields.append("canton")

    if not bool(getattr(user, "acepta_politica_privacidad", False)):
        missing_fields.append("acepta_politica_privacidad")

    return {
        "complete": len(missing_fields) == 0,
        "missing_fields": missing_fields,
        "missing_labels": [FIELD_LABELS.get(field, field) for field in missing_fields],
    }
