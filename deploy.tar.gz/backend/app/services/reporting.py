import os
import io
import re
import base64
import struct
import urllib.parse
import zlib
from copy import copy
from collections import OrderedDict
from decimal import Decimal, ROUND_HALF_UP
from datetime import date, datetime, time
from zipfile import ZIP_DEFLATED, ZipFile
from typing import Any, Dict, List, Optional, Tuple
from pathlib import Path
import openpyxl
import httpx
from openpyxl.cell.cell import Cell as OpenPyxlCell, MergedCell
from openpyxl.drawing.image import Image as OpenPyxlImage
from openpyxl.worksheet.cell_range import CellRange
from openpyxl.formula.translate import Translator
from openpyxl.writer.excel import ExcelWriter
from sqlalchemy.orm import selectinload
from app.core.config import settings
from app.core.rounding import round_decimal
from app.core.text_formatting import normalize_sentence_case
from openpyxl.styles import Alignment, Font
from openpyxl.styles.numbers import is_date_format
from openpyxl.utils import get_column_letter
from openpyxl.utils.cell import range_boundaries
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfgen import canvas
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Image as ReportLabImage, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from app.api.endpoints.maestros import TIPOS_PROYECTO, CATEGORIAS

class ReportingService:
    REPORT_AUTHOR = "GIPROY Network"
    PROJECT_TYPES_BY_ID = {int(item["id"]): item.get("descripcion") or "" for item in TIPOS_PROYECTO}
    PROJECT_CATEGORIES_BY_ID = {int(item["id"]): item.get("descripcion") or item.get("description") or "" for item in CATEGORIAS}

    def __init__(self, templates_dir: str = None):
        self.templates_dir = templates_dir or str(settings.REPORTS_DIR)
        self._apu_template_metadata_cache: Dict[str, Dict[str, Any]] = {}
        self._workbook_bytes_cache: "OrderedDict[Tuple[Any, ...], bytes]" = OrderedDict()
        self._report_export_cache: "OrderedDict[Tuple[Any, ...], bytes]" = OrderedDict()
        self._map_image_cache: "OrderedDict[Tuple[Any, ...], bytes]" = OrderedDict()
        self._workbook_bytes_cache_limit = 8
        self._report_export_cache_limit = 32
        self._map_image_cache_limit = 16

    def _get_cached_bytes(
        self,
        cache_store: "OrderedDict[Tuple[Any, ...], bytes]",
        cache_key: Tuple[Any, ...],
    ) -> Optional[bytes]:
        payload = cache_store.get(cache_key)
        if payload is None:
            return None
        cache_store.move_to_end(cache_key)
        return payload

    def _set_cached_bytes(
        self,
        cache_store: "OrderedDict[Tuple[Any, ...], bytes]",
        cache_key: Tuple[Any, ...],
        payload: bytes,
        limit: int,
    ) -> None:
        cache_store[cache_key] = payload
        cache_store.move_to_end(cache_key)
        while len(cache_store) > max(int(limit or 0), 1):
            cache_store.popitem(last=False)

    def _number_to_spanish_words(self, value: int) -> str:
        units = {
            0: "cero",
            1: "uno",
            2: "dos",
            3: "tres",
            4: "cuatro",
            5: "cinco",
            6: "seis",
            7: "siete",
            8: "ocho",
            9: "nueve",
            10: "diez",
            11: "once",
            12: "doce",
            13: "trece",
            14: "catorce",
            15: "quince",
            16: "dieciseis",
            17: "diecisiete",
            18: "dieciocho",
            19: "diecinueve",
            20: "veinte",
            21: "veintiuno",
            22: "veintidos",
            23: "veintitres",
            24: "veinticuatro",
            25: "veinticinco",
            26: "veintiseis",
            27: "veintisiete",
            28: "veintiocho",
            29: "veintinueve",
        }
        tens = {
            30: "treinta",
            40: "cuarenta",
            50: "cincuenta",
            60: "sesenta",
            70: "setenta",
            80: "ochenta",
            90: "noventa",
        }
        hundreds = {
            100: "cien",
            200: "doscientos",
            300: "trescientos",
            400: "cuatrocientos",
            500: "quinientos",
            600: "seiscientos",
            700: "setecientos",
            800: "ochocientos",
            900: "novecientos",
        }

        def under_hundred(n: int) -> str:
            if n < 30:
                return units[n]
            ten = (n // 10) * 10
            unit = n % 10
            return tens[ten] if unit == 0 else f"{tens[ten]} y {units[unit]}"

        def under_thousand(n: int) -> str:
            if n < 100:
                return under_hundred(n)
            if n in hundreds:
                return hundreds[n]
            hundred = (n // 100) * 100
            remainder = n % 100
            prefix = "ciento" if hundred == 100 else hundreds[hundred]
            return f"{prefix} {under_hundred(remainder)}"

        if value < 1000:
            return under_thousand(value)
        if value < 1_000_000:
            thousands = value // 1000
            remainder = value % 1000
            if thousands == 1:
                prefix = "mil"
            else:
                prefix = f"{under_thousand(thousands)} mil"
            return prefix if remainder == 0 else f"{prefix} {under_thousand(remainder)}"
        millions = value // 1_000_000
        remainder = value % 1_000_000
        if millions == 1:
            prefix = "un millon"
        else:
            prefix = f"{self._number_to_spanish_words(millions)} millones"
        if remainder == 0:
            return prefix
        return f"{prefix} {self._number_to_spanish_words(remainder)}"

    def _money_to_words_es(self, value: Any, currency_singular: str = "dolar", currency_plural: str = "dolares") -> str:
        amount = Decimal(str(value if value is not None else 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        integer_part = int(amount)
        cents = int((amount - Decimal(integer_part)) * 100)

        integer_words = self._number_to_spanish_words(integer_part)
        currency_word = currency_singular if integer_part == 1 else currency_plural
        cents_words = self._number_to_spanish_words(cents)
        cent_word = "centavo" if cents == 1 else "centavos"

        text = f"Son: {integer_words} con {cents_words} {cent_word} de {currency_word}"
        return text[:1].upper() + text[1:]

    def _save_workbook_buffer(self, wb) -> io.BytesIO:
        wb.properties.creator = self.REPORT_AUTHOR
        wb.properties.lastModifiedBy = self.REPORT_AUTHOR
        wb.properties.lastPrinted = None
        if not wb.properties.title:
            wb.properties.title = "Reporte"
        for ws in wb.worksheets:
            self._normalize_report_sheet_print_setup(ws)
        output = io.BytesIO()
        archive = ZipFile(output, mode="w", compression=ZIP_DEFLATED, compresslevel=1, allowZip64=True)
        try:
            writer = ExcelWriter(wb, archive)
            writer.save()
        finally:
            archive.close()
        output.seek(0)
        return output

    def _buffer_from_cached_bytes(self, payload: bytes) -> io.BytesIO:
        output = io.BytesIO(payload)
        output.seek(0)
        return output

    def _clear_sheet_headers_and_footers(self, ws) -> None:
        for header_name in ("oddHeader", "oddFooter", "evenHeader", "evenFooter", "firstHeader", "firstFooter"):
            header = getattr(ws, header_name, None)
            if not header:
                continue
            for part_name in ("left", "center", "right"):
                part = getattr(header, part_name, None)
                if part is None:
                    continue
                part.text = ""
                if hasattr(part, "font"):
                    part.font = None
                if hasattr(part, "size"):
                    part.size = None

    def _normalize_report_sheet_print_setup(self, ws) -> None:
        self._clear_sheet_headers_and_footers(ws)
        used_range = ws.calculate_dimension()
        if used_range and used_range != "A1:A1":
            ws.print_area = used_range
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        ws.page_setup.scale = None
        if ws.sheet_properties.pageSetUpPr is None:
            ws.sheet_properties.pageSetUpPr = openpyxl.worksheet.properties.PageSetupProperties(fitToPage=True)
        else:
            ws.sheet_properties.pageSetUpPr.fitToPage = True

    def _convert_excel_buffer_to_pdf(self, xlsx_buffer: io.BytesIO, timeout_seconds: int = 120) -> io.BytesIO:
        try:
            workbook = openpyxl.load_workbook(io.BytesIO(xlsx_buffer.getvalue()), data_only=True)
        except Exception as exc:
            raise RuntimeError("No fue posible abrir el archivo Excel para convertirlo a PDF por código.") from exc

        output = io.BytesIO()
        pdf = canvas.Canvas(output, pagesize=A4)
        pdf.setAuthor(self.REPORT_AUTHOR)
        pdf.setCreator(self.REPORT_AUTHOR)
        pdf.setTitle("Reporte")

        rendered_any_sheet = False
        for worksheet in workbook.worksheets:
            rendered_any_sheet = self._render_workbook_sheet_to_pdf(pdf, worksheet) or rendered_any_sheet

        if not rendered_any_sheet:
            raise RuntimeError("El archivo Excel no contiene hojas imprimibles para convertir a PDF.")

        pdf.save()
        output.seek(0)
        return output

    def _worksheet_print_bounds(self, ws) -> Tuple[int, int, int, int]:
        print_area = str(getattr(ws, "print_area", "") or "").strip()
        raw_ranges = [print_area] if print_area else [ws.calculate_dimension()]
        boundaries: List[Tuple[int, int, int, int]] = []

        for raw_range in raw_ranges:
            for chunk in str(raw_range).split(","):
                area = chunk.strip()
                if not area:
                    continue
                if "!" in area:
                    area = area.split("!", 1)[1]
                area = area.replace("$", "")
                try:
                    boundaries.append(range_boundaries(area))
                except Exception:
                    continue

        if not boundaries:
            return 1, 1, max(ws.max_row, 1), max(ws.max_column, 1)

        min_col = min(item[0] for item in boundaries)
        min_row = min(item[1] for item in boundaries)
        max_col = max(item[2] for item in boundaries)
        max_row = max(item[3] for item in boundaries)
        return min_col, min_row, max_col, max_row

    def _excel_color_to_reportlab(self, color_obj, fallback: colors.Color = colors.white) -> colors.Color:
        rgb = getattr(color_obj, "rgb", None)
        if not rgb:
            return fallback
        rgb = str(rgb).strip()
        if len(rgb) == 8:
            rgb = rgb[-6:]
        if len(rgb) != 6:
            return fallback
        try:
            return colors.HexColor(f"#{rgb}")
        except Exception:
            return fallback

    def _excel_border_color(self, side) -> colors.Color:
        color_obj = getattr(side, "color", None)
        return self._excel_color_to_reportlab(color_obj, colors.black)

    def _worksheet_column_width_points(self, ws, column_index: int) -> float:
        column_letter = get_column_letter(column_index)
        column_dimension = ws.column_dimensions.get(column_letter)
        if column_dimension and getattr(column_dimension, "hidden", False):
            return 0.0
        width = getattr(column_dimension, "width", None) or 8.43
        return max((float(width) * 7 + 5) * 0.75, 12.0)

    def _worksheet_row_height_points(self, ws, row_index: int) -> float:
        row_dimension = ws.row_dimensions.get(row_index)
        if row_dimension and getattr(row_dimension, "hidden", False):
            return 0.0
        height = getattr(row_dimension, "height", None) or 15
        return max(float(height), 8.0)

    def _format_excel_display_value(self, cell) -> str:
        value = cell.value
        if value in (None, ""):
            return ""

        if isinstance(value, datetime):
            return value.strftime("%d/%m/%Y %H:%M")
        if isinstance(value, date):
            return value.strftime("%d/%m/%Y")
        if isinstance(value, time):
            return value.strftime("%H:%M")

        number_format = str(getattr(cell, "number_format", "") or "")
        if is_date_format(number_format):
            try:
                return value.strftime("%d/%m/%Y")
            except Exception:
                return str(value)

        if isinstance(value, (int, float, Decimal)):
            decimals = 0
            decimal_match = re.search(r"\.([0#]+)", number_format)
            if decimal_match:
                decimals = len(decimal_match.group(1))
            amount = Decimal(str(value))
            if "%" in number_format:
                amount *= Decimal("100")
                quant = Decimal("1") if decimals <= 0 else Decimal("1." + ("0" * decimals))
                rendered = f"{amount.quantize(quant, rounding=ROUND_HALF_UP):,.{decimals}f}"
                return rendered.replace(",", "_").replace(".", ",").replace("_", ".") + "%"
            quant = Decimal("1") if decimals <= 0 else Decimal("1." + ("0" * decimals))
            rendered = f"{amount.quantize(quant, rounding=ROUND_HALF_UP):,.{decimals}f}"
            rendered = rendered.replace(",", "_").replace(".", ",").replace("_", ".")
            if "$" in number_format:
                return f"${rendered}"
            return rendered

        return str(value)

    def _wrap_pdf_text(self, text: str, font_name: str, font_size: float, max_width: float) -> List[str]:
        normalized = str(text or "").replace("\r", "")
        if not normalized:
            return [""]
        wrapped_lines: List[str] = []
        for source_line in normalized.split("\n"):
            words = source_line.split()
            if not words:
                wrapped_lines.append("")
                continue
            current = words[0]
            for word in words[1:]:
                trial = f"{current} {word}".strip()
                if pdfmetrics.stringWidth(trial, font_name, font_size) <= max_width:
                    current = trial
                else:
                    wrapped_lines.append(current)
                    current = word
            wrapped_lines.append(current)
        return wrapped_lines or [normalized]

    def _render_workbook_sheet_to_pdf(self, pdf: canvas.Canvas, ws) -> bool:
        min_col, min_row, max_col, max_row = self._worksheet_print_bounds(ws)
        column_indexes = [index for index in range(min_col, max_col + 1) if self._worksheet_column_width_points(ws, index) > 0]
        row_indexes = [index for index in range(min_row, max_row + 1) if self._worksheet_row_height_points(ws, index) > 0]
        if not column_indexes or not row_indexes:
            return False

        column_widths = {index: self._worksheet_column_width_points(ws, index) for index in column_indexes}
        row_heights = {index: self._worksheet_row_height_points(ws, index) for index in row_indexes}
        total_width = sum(column_widths.values())
        if total_width <= 0:
            return False

        sheet_landscape = str(getattr(ws.page_setup, "orientation", "") or "").lower() == "landscape"
        pagesize = landscape(A4) if sheet_landscape or total_width > (A4[0] * 0.9) else A4
        page_width, page_height = pagesize
        margin_x = 10 * mm
        margin_y = 10 * mm
        available_width = page_width - (margin_x * 2)
        available_height = page_height - (margin_y * 2)
        scale = min(available_width / total_width, 1.0)
        usable_unscaled_height = available_height / max(scale, 0.01)

        merged_map: Dict[Tuple[int, int], Tuple[int, int]] = {}
        merged_children: set[Tuple[int, int]] = set()
        for merged_range in ws.merged_cells.ranges:
            if merged_range.max_col < min_col or merged_range.min_col > max_col or merged_range.max_row < min_row or merged_range.min_row > max_row:
                continue
            start = (merged_range.min_row, merged_range.min_col)
            merged_map[start] = (merged_range.max_row, merged_range.max_col)
            for row_idx in range(merged_range.min_row, merged_range.max_row + 1):
                for col_idx in range(merged_range.min_col, merged_range.max_col + 1):
                    if (row_idx, col_idx) != start:
                        merged_children.add((row_idx, col_idx))

        image_entries: List[Dict[str, Any]] = []
        for image in getattr(ws, "_images", []) or []:
            anchor = getattr(image, "anchor", None)
            anchor_from = getattr(anchor, "_from", None)
            if anchor_from is None:
                continue
            try:
                raw_image = image._data()
            except Exception:
                continue
            image_entries.append(
                {
                    "row": int(getattr(anchor_from, "row", 0)) + 1,
                    "col": int(getattr(anchor_from, "col", 0)) + 1,
                    "width_pt": max(float(getattr(image, "width", 0) or 0) * 0.75, 12.0),
                    "height_pt": max(float(getattr(image, "height", 0) or 0) * 0.75, 12.0),
                    "payload": raw_image,
                }
            )

        row_pointer = 0
        while row_pointer < len(row_indexes):
            pdf.setPageSize(pagesize)
            page_start_pointer = row_pointer
            consumed_height = 0.0
            while row_pointer < len(row_indexes):
                candidate_row = row_indexes[row_pointer]
                candidate_height = row_heights[candidate_row]
                if row_pointer > page_start_pointer and consumed_height + candidate_height > usable_unscaled_height:
                    break
                consumed_height += candidate_height
                row_pointer += 1

            page_rows = row_indexes[page_start_pointer:row_pointer]
            if not page_rows:
                page_rows = [row_indexes[page_start_pointer]]
                row_pointer = page_start_pointer + 1

            x_positions: Dict[int, float] = {}
            current_x = margin_x
            for col_idx in column_indexes:
                x_positions[col_idx] = current_x
                current_x += column_widths[col_idx] * scale

            row_top_positions: Dict[int, float] = {}
            current_y = page_height - margin_y
            for row_idx in page_rows:
                row_top_positions[row_idx] = current_y
                current_y -= row_heights[row_idx] * scale

            for row_idx in page_rows:
                for col_idx in column_indexes:
                    if (row_idx, col_idx) in merged_children:
                        continue

                    cell = ws.cell(row=row_idx, column=col_idx)
                    merge_end = merged_map.get((row_idx, col_idx), (row_idx, col_idx))
                    span_end_row = min(merge_end[0], page_rows[-1])
                    span_end_col = merge_end[1]
                    visible_cols = [index for index in column_indexes if col_idx <= index <= span_end_col]
                    visible_rows = [index for index in page_rows if row_idx <= index <= span_end_row]
                    if not visible_cols or not visible_rows:
                        continue

                    cell_x = x_positions[col_idx]
                    cell_width = sum(column_widths[index] for index in visible_cols) * scale
                    cell_height = sum(row_heights[index] for index in visible_rows) * scale
                    cell_top = row_top_positions[row_idx]
                    cell_y = cell_top - cell_height

                    fill = getattr(getattr(cell, "fill", None), "fill_type", None)
                    fill_color = self._excel_color_to_reportlab(getattr(getattr(cell, "fill", None), "fgColor", None), colors.white)
                    if fill == "solid" and fill_color != colors.white:
                        pdf.setFillColor(fill_color)
                        pdf.rect(cell_x, cell_y, cell_width, cell_height, stroke=0, fill=1)

                    border = getattr(cell, "border", None)
                    if border:
                        side_specs = [
                            ("left", cell_x, cell_y, cell_x, cell_y + cell_height),
                            ("right", cell_x + cell_width, cell_y, cell_x + cell_width, cell_y + cell_height),
                            ("top", cell_x, cell_y + cell_height, cell_x + cell_width, cell_y + cell_height),
                            ("bottom", cell_x, cell_y, cell_x + cell_width, cell_y),
                        ]
                        for side_name, x1, y1, x2, y2 in side_specs:
                            side = getattr(border, side_name, None)
                            if side and getattr(side, "style", None):
                                pdf.setStrokeColor(self._excel_border_color(side))
                                pdf.setLineWidth(0.8 if side.style in {"medium", "thick", "double"} else 0.45)
                                pdf.line(x1, y1, x2, y2)

                    rendered_value = self._format_excel_display_value(cell)
                    if not rendered_value:
                        continue

                    font = getattr(cell, "font", None)
                    font_name = "Helvetica-Bold" if getattr(font, "bold", False) else "Helvetica"
                    font_size = min(max((float(getattr(font, "sz", 10) or 10) * scale), 5.0), 18.0)
                    horizontal = str(getattr(getattr(cell, "alignment", None), "horizontal", "") or "").lower()
                    padding = 2.5
                    text_width = max(cell_width - (padding * 2), 6)
                    lines = self._wrap_pdf_text(rendered_value, font_name, font_size, text_width)
                    line_height = font_size * 1.15
                    total_text_height = max(len(lines), 1) * line_height
                    text_start_y = cell_y + cell_height - padding - font_size
                    if total_text_height + (padding * 2) < cell_height:
                        text_start_y = cell_y + ((cell_height + total_text_height) / 2) - font_size + 1

                    text_color = self._excel_color_to_reportlab(getattr(font, "color", None), colors.black)
                    pdf.setFillColor(text_color)
                    pdf.setFont(font_name, font_size)
                    for line_index, line in enumerate(lines):
                        line_y = text_start_y - (line_index * line_height)
                        if line_y < cell_y + padding:
                            break
                        line_width = pdfmetrics.stringWidth(line, font_name, font_size)
                        if horizontal in {"center", "centercontinuous", "distributed"}:
                            line_x = cell_x + max((cell_width - line_width) / 2, padding)
                        elif horizontal == "right":
                            line_x = cell_x + cell_width - line_width - padding
                        else:
                            line_x = cell_x + padding
                        pdf.drawString(line_x, line_y, line)

            first_page_row = page_rows[0]
            last_page_row = page_rows[-1]
            for image_entry in image_entries:
                row_idx = image_entry["row"]
                col_idx = image_entry["col"]
                if row_idx < first_page_row or row_idx > last_page_row or col_idx not in x_positions:
                    continue
                cell_x = x_positions[col_idx]
                cell_top = row_top_positions[row_idx]
                image_width = image_entry["width_pt"] * scale
                image_height = image_entry["height_pt"] * scale
                image_y = cell_top - image_height
                try:
                    pdf.drawImage(
                        ImageReader(io.BytesIO(image_entry["payload"])),
                        cell_x,
                        image_y,
                        width=image_width,
                        height=image_height,
                        preserveAspectRatio=True,
                        mask="auto",
                    )
                except Exception:
                    continue

            pdf.showPage()

        return True

    def _build_presupuesto_bundle_cache_key(
        self,
        presupuesto: Any,
        empresa_id: int,
        template_id: str,
        use_omniclass: bool,
        apus_map: Dict[int, Any],
    ) -> Tuple[Any, ...]:
        presupuesto_stamp = getattr(presupuesto, "ultima_modificacion", None) or getattr(presupuesto, "fecha_creacion", None)
        apu_stamps = [
            (apu.id, getattr(apu, "ultima_modificacion", None) or getattr(apu, "fecha_creacion", None))
            for apu in apus_map.values()
        ]
        latest_apu_stamp = max((stamp for _, stamp in apu_stamps if stamp is not None), default=None)
        return (
            "presupuesto_bundle",
            template_id,
            int(empresa_id),
            int(presupuesto.id),
            bool(use_omniclass),
            presupuesto_stamp.isoformat() if presupuesto_stamp else "",
            len(apus_map),
            latest_apu_stamp.isoformat() if latest_apu_stamp else "",
        )

    def _build_report_export_cache_key(
        self,
        db: Any,
        report_type: str,
        entity_ids: List[int],
        empresa_id: int,
        template_id: str = "001",
        variant: Optional[str] = None,
        export_format: str = "xlsx",
    ) -> Tuple[Any, ...]:
        report_type = str(report_type or "").lower()
        export_format = str(export_format or "xlsx").lower()
        template_id = template_id or "001"
        entity_ids = [int(entity_id) for entity_id in (entity_ids or [])]

        if report_type == "apu":
            apus_map = self._get_apus_map(db, entity_ids, empresa_id)
            latest_stamp = max(
                (
                    getattr(apu, "ultima_modificacion", None) or getattr(apu, "fecha_creacion", None)
                    for apu in apus_map.values()
                    if apu is not None
                ),
                default=None,
            )
            return (
                "export",
                report_type,
                export_format,
                template_id,
                variant or "",
                int(empresa_id),
                tuple(entity_ids),
                latest_stamp.isoformat() if latest_stamp else "",
            )

        if report_type in {"presupuesto", "vae", "polinomica"}:
            presupuesto = self._get_presupuesto(db, entity_ids[0], empresa_id)
            presupuesto_stamp = getattr(presupuesto, "ultima_modificacion", None) or getattr(presupuesto, "fecha_creacion", None)
            latest_apu_stamp = ""
            apu_count = 0
            if report_type == "presupuesto" and variant == "with_apus":
                apus_map = self._get_presupuesto_apus_map(db, presupuesto, empresa_id)
                latest_apu = max(
                    (
                        getattr(apu, "ultima_modificacion", None) or getattr(apu, "fecha_creacion", None)
                        for apu in apus_map.values()
                        if apu is not None
                    ),
                    default=None,
                )
                latest_apu_stamp = latest_apu.isoformat() if latest_apu else ""
                apu_count = len(apus_map)
            return (
                "export",
                report_type,
                export_format,
                template_id,
                variant or "",
                int(empresa_id),
                int(presupuesto.id),
                presupuesto_stamp.isoformat() if presupuesto_stamp else "",
                apu_count,
                latest_apu_stamp,
            )

        if report_type == "edt":
            from app.models.proyecto import Proyecto

            proyecto = db.query(Proyecto).filter(Proyecto.id == entity_ids[0], Proyecto.empresa_id == empresa_id).first()
            proyecto_stamp = None
            if proyecto is not None:
                proyecto_stamp = getattr(proyecto, "ultima_modificacion", None) or getattr(proyecto, "fecha_creacion", None)
            return (
                "export",
                report_type,
                export_format,
                template_id,
                variant or "",
                int(empresa_id),
                int(entity_ids[0]),
                proyecto_stamp.isoformat() if proyecto_stamp else "",
            )

        return (
            "export",
            report_type,
            export_format,
            template_id,
            variant or "",
            int(empresa_id),
            tuple(entity_ids),
        )

    def get_cached_report_export(self, cache_key: Tuple[Any, ...]) -> Optional[bytes]:
        return self._get_cached_bytes(self._report_export_cache, cache_key)

    def set_cached_report_export(self, cache_key: Tuple[Any, ...], payload: bytes) -> None:
        self._set_cached_bytes(
            self._report_export_cache,
            cache_key,
            payload,
            self._report_export_cache_limit,
        )

    def _money_to_words_body_es(
        self,
        value: Any,
        currency_singular: str = "dolar",
        currency_plural: str = "dolares",
        uppercase: bool = False,
    ) -> str:
        full_text = self._money_to_words_es(value, currency_singular, currency_plural)
        body = full_text[5:] if full_text.startswith("Son: ") else full_text
        return body.upper() if uppercase else body

    def _money_to_words_excel_usd_upper(self, value: Any) -> str:
        amount = Decimal(str(value if value is not None else 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        integer_part = int(amount)
        cents = int((amount - Decimal(integer_part)) * 100)
        integer_words = self._number_to_spanish_words(integer_part).upper()
        return f"{integer_words}  CON {cents:02d}/100 DÓLARES DE LOS ESTADOS UNIDOS DE AMÉRICA"

    def _normalize_report_description(self, value: Any) -> str:
        normalized = normalize_sentence_case(value)
        return normalized or ""

    def _resolve_project_title(self, proyecto: Any = None, fallback: Any = "") -> str:
        if proyecto and getattr(proyecto, "nombre", None):
            return self._normalize_report_description(proyecto.nombre)
        return self._normalize_report_description(fallback)

    def _format_revision_label(self, revision: Any) -> str:
        try:
            revision_number = int(revision or 0)
        except (TypeError, ValueError):
            revision_number = 0
        return f"R{revision_number:03d}"

    def _format_percent_label(self, value: Any, decimals: int = 2) -> str:
        amount = Decimal(str(value if value is not None else 0)).quantize(
            Decimal("1." + ("0" * max(int(decimals or 0), 0))),
            rounding=ROUND_HALF_UP,
        )
        normalized = format(amount.normalize(), "f")
        if "." in normalized:
            normalized = normalized.rstrip("0").rstrip(".")
        return f"{normalized} %"

    def _format_date_label(self, value: Any) -> str:
        if not value:
            return ""
        if hasattr(value, "strftime"):
            return value.strftime("%d/%m/%Y")
        return str(value or "").strip()

    def _resolve_project_type_label(self, detail: Any) -> str:
        raw_id = getattr(detail, "tipo_proyecto_id", None)
        try:
            type_id = int(raw_id) if raw_id is not None else None
        except (TypeError, ValueError):
            type_id = None
        if type_id is None:
            return ""
        return self._normalize_report_description(self.PROJECT_TYPES_BY_ID.get(type_id, ""))

    def _resolve_project_category_label(self, detail: Any) -> str:
        raw_id = getattr(detail, "categoria_id", None)
        try:
            category_id = int(raw_id) if raw_id is not None else None
        except (TypeError, ValueError):
            category_id = None
        if category_id is None:
            return ""
        return self._normalize_report_description(self.PROJECT_CATEGORIES_BY_ID.get(category_id, ""))

    def _format_area_label(self, value: Any) -> str:
        if value in (None, ""):
            return ""
        try:
            return self._format_fixed(float(value), 2)
        except (TypeError, ValueError):
            return str(value or "").strip()

    def _format_money_label(self, value: Any, decimals: int = 2) -> str:
        return f"${self._round_half_up(value or 0, decimals):,.{decimals}f}"

    def _format_geo_reference(self, detail: Any) -> str:
        if not detail:
            return ""
        lat = getattr(detail, "latitud", None)
        lng = getattr(detail, "longitud", None)
        if lat in (None, "") or lng in (None, ""):
            return ""
        try:
            return f"{float(lat):.6f}, {float(lng):.6f}"
        except (TypeError, ValueError):
            return ""

    def _get_project_map_zoom(self, detail: Any) -> int:
        if not detail:
            return 13
        try:
            zoom = int(getattr(detail, "map_zoom", None) or 13)
        except (TypeError, ValueError):
            zoom = 13
        return max(1, min(18, zoom))

    def _build_project_map_image_url(self, detail: Any, width: int = 900, height: int = 520) -> str:
        if not detail:
            return ""
        lat = getattr(detail, "latitud", None)
        lng = getattr(detail, "longitud", None)
        if lat in (None, "") or lng in (None, ""):
            return ""
        try:
            lat_value = f"{float(lat):.6f}"
            lng_value = f"{float(lng):.6f}"
        except (TypeError, ValueError):
            return ""

        params = urllib.parse.urlencode({
            "center": f"{lat_value},{lng_value}",
            "zoom": self._get_project_map_zoom(detail),
            "size": f"{max(int(width), 320)}x{max(int(height), 180)}",
            "maptype": "mapnik",
            "markers": f"{lat_value},{lng_value},lightblue1",
        })
        return f"https://staticmap.openstreetmap.de/staticmap.php?{params}"

    def _write_png_chunk(self, buffer: io.BytesIO, chunk_type: bytes, data: bytes) -> None:
        buffer.write(struct.pack(">I", len(data)))
        buffer.write(chunk_type)
        buffer.write(data)
        buffer.write(struct.pack(">I", zlib.crc32(chunk_type + data) & 0xFFFFFFFF))

    def _build_png_from_rgb_rows(self, width: int, height: int, pixels: List[List[Tuple[int, int, int]]]) -> bytes:
        raw = bytearray()
        for row in pixels:
            raw.append(0)
            for red, green, blue in row:
                raw.extend((red, green, blue))

        buffer = io.BytesIO()
        buffer.write(b"\x89PNG\r\n\x1a\n")
        self._write_png_chunk(buffer, b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
        self._write_png_chunk(buffer, b"IDAT", zlib.compress(bytes(raw), 9))
        self._write_png_chunk(buffer, b"IEND", b"")
        return buffer.getvalue()

    def _build_project_map_snapshot_bytes(self, detail: Any, width: int = 900, height: int = 520) -> Optional[bytes]:
        if not detail:
            return None
        lat = getattr(detail, "latitud", None)
        lng = getattr(detail, "longitud", None)
        if lat in (None, "") or lng in (None, ""):
            return None
        try:
            lat_value = float(lat)
            lng_value = float(lng)
        except (TypeError, ValueError):
            return None

        width = max(int(width or 900), 320)
        height = max(int(height or 520), 180)
        bg = (248, 250, 252)
        grid = (226, 232, 240)
        grid_strong = (203, 213, 225)
        orange = (243, 146, 0)
        blue = (19, 97, 145)
        dark = (30, 41, 59)
        pixels = [[bg for _ in range(width)] for _ in range(height)]

        for x in range(0, width, max(width // 12, 48)):
            color = grid_strong if x % max(width // 4, 1) == 0 else grid
            for y in range(height):
                pixels[y][x] = color
        for y in range(0, height, max(height // 8, 40)):
            color = grid_strong if y % max(height // 4, 1) == 0 else grid
            pixels[y] = [color if x % 3 != 0 else pixels[y][x] for x in range(width)]

        center_x = width // 2
        center_y = height // 2
        for x in range(max(center_x - 95, 0), min(center_x + 96, width)):
            for offset in (-1, 0, 1):
                y = center_y + offset
                if 0 <= y < height:
                    pixels[y][x] = blue
        for y in range(max(center_y - 95, 0), min(center_y + 96, height)):
            for offset in (-1, 0, 1):
                x = center_x + offset
                if 0 <= x < width:
                    pixels[y][x] = blue

        radius = max(min(width, height) // 22, 14)
        radius_sq = radius * radius
        for y in range(max(center_y - radius, 0), min(center_y + radius + 1, height)):
            for x in range(max(center_x - radius, 0), min(center_x + radius + 1, width)):
                dx = x - center_x
                dy = y - center_y
                dist = dx * dx + dy * dy
                if dist <= radius_sq:
                    pixels[y][x] = orange if dist >= (radius - 4) * (radius - 4) else (255, 247, 237)
        for y in range(center_y + radius - 2, min(center_y + radius + 24, height)):
            spread = max(1, (y - center_y - radius + 2) // 2)
            for x in range(max(center_x - spread, 0), min(center_x + spread + 1, width)):
                pixels[y][x] = orange

        header_height = min(58, max(36, height // 9))
        for y in range(header_height):
            for x in range(width):
                if x < width:
                    pixels[y][x] = (255, 255, 255)
        for y in range(header_height, min(header_height + 2, height)):
            for x in range(width):
                pixels[y][x] = grid_strong

        # Firma visual mínima sin dependencia de fuentes: barras codifican lat/lng/zoom.
        values = [
            abs(int(lat_value * 1000)) % 100,
            abs(int(lng_value * 1000)) % 100,
            self._get_project_map_zoom(detail) * 5,
        ]
        x_cursor = 24
        for value in values:
            bar_width = max(20, min(180, value + 24))
            for y in range(18, min(36, header_height)):
                for x in range(x_cursor, min(x_cursor + bar_width, width - 24)):
                    pixels[y][x] = dark if y < 24 else orange
            x_cursor += bar_width + 16

        return self._build_png_from_rgb_rows(width, height, pixels)

    def _build_project_map_snapshot_data_url(self, detail: Any, width: int = 900, height: int = 520) -> str:
        payload = self._build_project_map_snapshot_bytes(detail, width, height)
        if not payload:
            return ""
        return f"data:image/png;base64,{base64.b64encode(payload).decode('ascii')}"

    def _get_project_map_image_data_url(self, detail: Any, width: int = 900, height: int = 520) -> str:
        payload = self._get_project_map_image_bytes(detail, width, height)
        if not payload:
            return ""
        return f"data:image/png;base64,{base64.b64encode(payload).decode('ascii')}"

    def _get_project_map_image_bytes(self, detail: Any, width: int = 900, height: int = 520) -> Optional[bytes]:
        remote_payload = self._fetch_remote_image_bytes(self._build_project_map_image_url(detail, width, height))
        if remote_payload:
            return remote_payload
        return self._build_project_map_snapshot_bytes(detail, width, height)

    def _get_project_referential_image_url(self, detail: Any) -> str:
        if not detail:
            return ""
        return str(getattr(detail, "imagen_referencial_url", None) or "").strip()

    def _fetch_local_upload_bytes(self, image_url: str) -> Optional[bytes]:
        normalized_url = str(image_url or "").strip().replace("\\", "/")
        if not normalized_url:
            return None
        if normalized_url.startswith("/uploads/"):
            relative_path = normalized_url.lstrip("/")
        elif normalized_url.startswith("uploads/"):
            relative_path = normalized_url
        else:
            return None

        path_value = Path(relative_path)
        if path_value.is_absolute():
            candidates = [path_value]
        else:
            backend_root = Path(__file__).resolve().parents[2]
            repo_root = backend_root.parent
            candidates = [
                Path.cwd() / path_value,
                backend_root / path_value,
                repo_root / path_value,
            ]
        for file_path in candidates:
            if not file_path.exists() or not file_path.is_file():
                continue
            try:
                return file_path.read_bytes()
            except Exception:
                return None
        return None

    def _fetch_remote_image_bytes(self, image_url: str) -> Optional[bytes]:
        normalized_url = str(image_url or "").strip()
        if not normalized_url:
            return None
        if normalized_url.startswith("data:image/") and ";base64," in normalized_url:
            try:
                _, payload = normalized_url.split(";base64,", 1)
                return base64.b64decode(payload)
            except Exception:
                return None
        cache_key = ("remote-image", normalized_url)
        cached = self._get_cached_bytes(self._map_image_cache, cache_key)
        if cached is not None:
            return cached

        local_payload = self._fetch_local_upload_bytes(normalized_url)
        if local_payload:
            self._set_cached_bytes(
                self._map_image_cache,
                cache_key,
                local_payload,
                self._map_image_cache_limit,
            )
            return local_payload

        try:
            with httpx.Client(timeout=8.0, follow_redirects=True) as client:
                response = client.get(normalized_url)
                response.raise_for_status()
                content_type = str(response.headers.get("content-type", "")).lower()
                if not content_type.startswith("image/"):
                    return None
                payload = response.content
                if not payload:
                    return None
                self._set_cached_bytes(
                    self._map_image_cache,
                    cache_key,
                    payload,
                    self._map_image_cache_limit,
                )
                return payload
        except Exception:
            return None

    def _find_placeholder_cell(self, ws: Any, placeholder: str) -> Optional[Any]:
        placeholder_value = str(placeholder or "").strip()
        if not placeholder_value:
            return None
        for row in ws.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and placeholder_value in cell.value:
                    return cell
        return None

    def _resolve_placeholder_range(self, ws: Any, cell: Any) -> CellRange:
        for merged_range in ws.merged_cells.ranges:
            merged = CellRange(str(merged_range))
            if (
                merged.min_row <= cell.row <= merged.max_row
                and merged.min_col <= cell.column <= merged.max_col
            ):
                return merged
        coord = f"{cell.coordinate}:{cell.coordinate}"
        return CellRange(coord)

    def _estimate_range_pixels(self, ws: Any, target_range: CellRange) -> Tuple[int, int]:
        width_units = 0.0
        for column in range(target_range.min_col, target_range.max_col + 1):
            letter = get_column_letter(column)
            width_units += float(ws.column_dimensions[letter].width or 10)
        height_points = 0.0
        for row in range(target_range.min_row, target_range.max_row + 1):
            height_points += float(ws.row_dimensions[row].height or 15)

        width_px = max(int(width_units * 7), 220)
        height_px = max(int(height_points * 96 / 72), 140)
        return width_px, height_px

    def _insert_image_placeholder(self, ws: Any, placeholder: str, image_bytes: Optional[bytes]) -> None:
        cell = self._find_placeholder_cell(ws, placeholder)
        if cell is None:
            return
        cell.value = ""
        if not image_bytes:
            return
        target_range = self._resolve_placeholder_range(ws, cell)
        width_px, height_px = self._estimate_range_pixels(ws, target_range)
        image = OpenPyxlImage(io.BytesIO(image_bytes))
        image.width = width_px
        image.height = height_px
        ws.add_image(image, cell.coordinate)

    def _build_acta_constitucion_preview(self, db: Any, proyecto: Any, empresa_id: int) -> Dict[str, Any]:
        detail = self._get_project_detail(db, proyecto, empresa_id)
        money_decimals = self._get_empresa_format_config(db, empresa_id)["money_decimals"]
        start_date = getattr(detail, "fecha_inicio", None) or getattr(proyecto, "fecha_inicio", None)
        end_date = getattr(detail, "fecha_finalizacion", None) or getattr(proyecto, "fecha_fin_estimada", None)
        plazo = getattr(detail, "plazo_ejecucion", None)
        presupuesto_entidad = float(getattr(proyecto, "presupuesto_estimado", 0) or 0)
        ciudad = getattr(detail, "ciudad", None) or ""
        provincia = getattr(detail, "provincia", None) or ""
        pais = getattr(detail, "pais", None) or ""

        fields = [
            {"label": "Código del proyecto", "value": getattr(proyecto, "codigo", None) or getattr(proyecto, "codigo_root", None) or "-"},
            {"label": "Código referencial", "value": getattr(detail, "cod_referencial", None) or "-"},
            {"label": "Dirección del proyecto", "value": getattr(detail, "direccion", None) or "-"},
            {"label": "Ciudad", "value": ciudad or "-"},
            {"label": "Provincia", "value": provincia or "-"},
            {"label": "País", "value": pais or "-"},
            {"label": "Alcance detallado", "value": getattr(detail, "alcance_detallado", None) or "-"},
            {"label": "Ámbito de contratación", "value": getattr(detail, "ambito_contratacion", None) or "-"},
            {"label": "Tipo de contrato", "value": getattr(detail, "tipo_contrato", None) or "-"},
            {"label": "Tipo de proyecto", "value": self._resolve_project_type_label(detail) or "-"},
            {"label": "Categoría del proyecto", "value": self._resolve_project_category_label(detail) or "-"},
            {"label": "Tipo de construcción", "value": getattr(detail, "tipo_construccion", None) or "-"},
            {"label": "Área de terreno (m²)", "value": self._format_area_label(getattr(detail, "area_terreno", None)) or "-"},
            {"label": "Área de construcción (m²)", "value": self._format_area_label(getattr(detail, "area_construccion", None)) or "-"},
            {"label": "Fecha de inicio", "value": self._format_date_label(start_date) or "-"},
            {"label": "Plazo", "value": f"{int(plazo)} días" if plazo not in (None, "") else "-"},
            {"label": "Fecha de finalización", "value": self._format_date_label(end_date) or "-"},
            {"label": "Georreferenciación", "value": self._format_geo_reference(detail) or "-"},
        ]

        return {
            "id": getattr(proyecto, "id", 0) or 0,
            "codigo": getattr(proyecto, "codigo", None) or getattr(proyecto, "codigo_root", None) or "-",
            "descripcion": self._resolve_project_title(proyecto, getattr(proyecto, "descripcion", None)),
            "categoria_base": "Acta de constitución del proyecto",
            "unidad": getattr(detail, "moneda", None) or getattr(proyecto, "moneda", None) or "USD",
            "costo_directo": 0,
            "costo_indirecto": 0,
            "precio_total": presupuesto_entidad,
            "summary_direct_kind": "text",
            "summary_indirect_kind": "text",
            "summary_total_kind": "money",
            "summary_cards": [
                {"label": "Fecha de inicio", "value": self._format_date_label(start_date) or "Sin fecha", "kind": "text"},
                {"label": "Plazo", "value": f"{int(plazo)} días" if plazo not in (None, "") else "Sin plazo", "kind": "text"},
                {"label": "Presupuesto entidad", "value": presupuesto_entidad, "kind": "money", "tone": "total"},
            ],
            "image_referencial_url": self._get_project_referential_image_url(detail),
            "map_image_url": self._get_project_map_image_data_url(detail),
            "fields": fields,
            "lineas": [],
            "metadata_hint": f"Documento base · {self._format_money_label(presupuesto_entidad, money_decimals)}",
        }

    def _build_stakeholders_preview(self, db: Any, proyecto: Any, empresa_id: int) -> Dict[str, Any]:
        from app.repositories.stakeholder import stakeholder_repo

        detail = self._get_project_detail(db, proyecto, empresa_id)
        stakeholders = stakeholder_repo.get_by_project_root(
            db,
            getattr(proyecto, "codigo_root", None) or getattr(proyecto, "codigo", None) or "",
            empresa_id,
            proyecto_id=getattr(proyecto, "id", None),
        )

        assigned_count = sum(1 for stk in stakeholders if getattr(stk, "assigned", False))
        lineas = []
        for stk in stakeholders:
            location_parts = [
                getattr(stk, "ciudad", None),
                getattr(stk, "canton", None),
                getattr(stk, "provincia", None),
                getattr(stk, "pais", None),
            ]
            ubicacion = " / ".join([part.strip() for part in location_parts if isinstance(part, str) and part.strip()])
            contacto = " · ".join([part.strip() for part in [getattr(stk, "movil", None), getattr(stk, "email", None)] if isinstance(part, str) and part.strip()])
            lineas.append({
                "codigo": getattr(stk, "codigo", None) or "-",
                "nombres": getattr(stk, "nombre", None) or "-",
                "apellidos": getattr(stk, "apellidos", None) or "-",
                "profesion": getattr(stk, "profesion", None) or getattr(stk, "institucion", None) or "-",
                "contacto": contacto or "-",
                "ubicacion": ubicacion or "-",
                "rol": getattr(stk, "rol_nombre", None) or "Sin rol",
            })

        fields = [
            {"label": "Código del proyecto", "value": getattr(proyecto, "codigo", None) or getattr(proyecto, "codigo_root", None) or "-"},
            {"label": "Código referencial", "value": getattr(detail, "cod_referencial", None) or "-"},
            {"label": "Ciudad base", "value": getattr(detail, "ciudad", None) or "-"},
            {"label": "Fecha del reporte", "value": self._format_date_label(getattr(proyecto, "fecha_creacion", None)) or "-"},
        ]

        return {
            "id": getattr(proyecto, "id", 0) or 0,
            "codigo": getattr(proyecto, "codigo", None) or getattr(proyecto, "codigo_root", None) or "-",
            "descripcion": self._resolve_project_title(proyecto, getattr(proyecto, "descripcion", None)),
            "categoria_base": "Equipo del proyecto (Stakeholders)",
            "unidad": "Stakeholders",
            "costo_directo": 0,
            "costo_indirecto": 0,
            "precio_total": len(stakeholders),
            "summary_direct_kind": "text",
            "summary_indirect_kind": "text",
            "summary_total_kind": "text",
            "summary_cards": [
                {"label": "Stakeholders", "value": str(len(stakeholders)), "kind": "text"},
                {"label": "Asignados", "value": str(assigned_count), "kind": "text"},
                {"label": "Sin rol", "value": str(max(len(stakeholders) - assigned_count, 0)), "kind": "text", "tone": "total"},
            ],
            "fields": fields,
            "lineas": lineas,
            "table_columns": [
                {"key": "codigo", "label": "Código"},
                {"key": "nombres", "label": "Nombres"},
                {"key": "apellidos", "label": "Apellidos"},
                {"key": "profesion", "label": "Profesión / Inst."},
                {"key": "contacto", "label": "Contacto"},
                {"key": "ubicacion", "label": "Ubicación"},
                {"key": "rol", "label": "Rol"},
            ],
            "metadata_hint": "Directorio común del proyecto compartido entre revisiones",
        }

    def generate_acta_constitucion_report(self, db: Any, proyecto_id: int, empresa_id: int, template_id: str = "001") -> io.BytesIO:
        from app.models.proyecto import Proyecto

        proyecto = (
            db.query(Proyecto)
            .filter(Proyecto.id == proyecto_id, Proyecto.empresa_id == empresa_id)
            .first()
        )
        if not proyecto:
            raise ValueError("Proyecto no encontrado")

        detail = self._get_project_detail(db, proyecto, empresa_id)
        filename = "001 - Acta de Constitucion - General.xlsx"
        data = {
            "#REVISION": self._format_revision_label(getattr(proyecto, "revision", None)),
            "#PRO_TITULO": self._resolve_project_title(proyecto, getattr(proyecto, "descripcion", None)),
            "#CODIGOPROYECTO": getattr(proyecto, "codigo", None) or getattr(proyecto, "codigo_root", None) or "",
            "#CODIGOREFERENCIAL": getattr(detail, "cod_referencial", None) or "",
            "#GEOREFERENCIACION": self._format_geo_reference(detail),
            "#IMAGENPROYECTO": "",
            "#DIRECCIONPROYECTO": getattr(detail, "direccion", None) or "",
            "#CIUDAD": getattr(detail, "ciudad", None) or "",
            "#PROVINCIA": getattr(detail, "provincia", None) or "",
            "#PAIS": getattr(detail, "pais", None) or "Ecuador",
            "#OBJETOCONTRATO": self._normalize_report_description(getattr(detail, "alcance_detallado", None)),
            "#AMBITOCONTRATACION": getattr(detail, "ambito_contratacion", None) or "",
            "#TIPOCONTRATO": getattr(detail, "tipo_contrato", None) or "",
            "#TIPOPROYECTO": self._resolve_project_type_label(detail),
            "#CATEGORIAPROYECTO": self._resolve_project_category_label(detail),
            "#TIPOCONSTRUCCION": getattr(detail, "tipo_construccion", None) or "",
            "#AREATERRENO": getattr(detail, "area_terreno", None) or 0,
            "#AREACONSTRUCCION": getattr(detail, "area_construccion", None) or 0,
            "#PRO_FECHA_INICIO": self._format_date_label(getattr(detail, "fecha_inicio", None) or getattr(proyecto, "fecha_inicio", None)),
            "#PRO_PLAZO": f"{int(detail.plazo_ejecucion)} días" if detail and getattr(detail, "plazo_ejecucion", None) not in (None, "") else "",
            "#PRO_FECHA_FIN": self._format_date_label(getattr(detail, "fecha_finalizacion", None) or getattr(proyecto, "fecha_fin_estimada", None)),
            "#CIUDADF": getattr(detail, "ciudad", None) or "",
            "#PRO_FECHA": self._format_date_label(getattr(proyecto, "fecha_creacion", None)),
        }

        format_config = self._get_empresa_format_config(db, empresa_id)
        formatted_data = self._format_excel_data(
            data,
            {
                "#AREATERRENO": "calc",
                "#AREACONSTRUCCION": "calc",
            },
            format_config["money_decimals"],
            format_config["calc_decimals"],
        )
        template_path = os.path.join(self.templates_dir, filename)
        if not os.path.exists(template_path):
            raise FileNotFoundError(f"Plantilla no encontrada: {template_path}")
        wb = openpyxl.load_workbook(template_path)
        ws = wb.active
        self._apply_template_to_sheet(ws, formatted_data, [], None)
        self._apply_omniclass_visibility(ws, False)
        map_image_bytes = self._get_project_map_image_bytes(detail)
        referential_image_bytes = self._fetch_remote_image_bytes(self._get_project_referential_image_url(detail))
        self._insert_image_placeholder(ws, "#GEOREFERENCIACION", map_image_bytes)
        self._insert_image_placeholder(ws, "#IMAGENPROYECTO", referential_image_bytes or map_image_bytes)
        return self._save_workbook_buffer(wb)

    def _join_report_parts(self, parts: List[Any], separator: str = " · ") -> str:
        normalized_parts: List[str] = []
        for part in parts:
            value = str(part or "").strip()
            if value and value not in normalized_parts:
                normalized_parts.append(value)
        return separator.join(normalized_parts)

    def _estimate_stakeholder_row_height(self, ws, row_index: int, min_col: int = 1, max_col: int = 12) -> float:
        max_lines = 1
        for column_index in range(min_col, max_col + 1):
            cell = ws.cell(row=row_index, column=column_index)
            value = str(cell.value or "").strip()
            if not value:
                continue
            column_letter = get_column_letter(column_index)
            column_width = float(getattr(ws.column_dimensions[column_letter], "width", None) or 10)
            approx_chars_per_line = max(int(column_width * 0.9), 8)
            line_count = 0
            for source_line in value.splitlines() or [value]:
                line_count += max(1, (len(source_line) + approx_chars_per_line - 1) // approx_chars_per_line)
            max_lines = max(max_lines, line_count)
        return min(max(24.0, (max_lines * 11.5) + 8.0), 96.0)

    def _prepare_stakeholders_report_sheet(self, ws, table_start_row: int, table_rows: int) -> None:
        ws.page_setup.orientation = "landscape"
        ws.page_setup.paperSize = 9
        ws.sheet_view.showGridLines = False
        ws.print_title_rows = "1:9"
        ws.page_margins.left = 0.25
        ws.page_margins.right = 0.25
        ws.page_margins.top = 0.35
        ws.page_margins.bottom = 0.35

        for column_index in range(1, 13):
            column_letter = get_column_letter(column_index)
            ws.column_dimensions[column_letter].hidden = False

        table_end_row = table_start_row + max(int(table_rows or 0), 1) - 1
        for row_index in range(table_start_row, table_end_row + 1):
            ws.row_dimensions[row_index].height = self._estimate_stakeholder_row_height(ws, row_index)
            for column_index in range(1, 13):
                cell = ws.cell(row=row_index, column=column_index)
                cell.alignment = Alignment(
                    horizontal=getattr(cell.alignment, "horizontal", None) or "center",
                    vertical="top",
                    wrap_text=True,
                )
                if cell.font and cell.font.sz and float(cell.font.sz) > 9:
                    source_font = cell.font
                    cell.font = Font(
                        name=source_font.name,
                        sz=9,
                        b=source_font.b,
                        i=source_font.i,
                        vertAlign=source_font.vertAlign,
                        underline=source_font.underline,
                        strike=source_font.strike,
                        color=copy(source_font.color),
                        charset=source_font.charset,
                        family=source_font.family,
                        scheme=source_font.scheme,
                        outline=source_font.outline,
                        shadow=source_font.shadow,
                        condense=source_font.condense,
                        extend=source_font.extend,
                    )

        last_content_row = table_end_row
        for row_index in range(1, ws.max_row + 1):
            if any(ws.cell(row=row_index, column=column_index).value not in (None, "") for column_index in range(1, 13)):
                last_content_row = max(last_content_row, row_index)
        if last_content_row < ws.max_row:
            ws.delete_rows(last_content_row + 1, ws.max_row - last_content_row)

        ws.print_area = f"A1:L{last_content_row}"

    def generate_stakeholders_report(self, db: Any, proyecto_id: int, empresa_id: int, template_id: str = "001") -> io.BytesIO:
        from app.models.proyecto import Proyecto
        from app.repositories.stakeholder import stakeholder_repo

        proyecto = (
            db.query(Proyecto)
            .filter(Proyecto.id == proyecto_id, Proyecto.empresa_id == empresa_id)
            .first()
        )
        if not proyecto:
            raise ValueError("Proyecto no encontrado")

        detail = self._get_project_detail(db, proyecto, empresa_id)
        stakeholders = stakeholder_repo.get_by_project_root(
            db,
            getattr(proyecto, "codigo_root", None) or getattr(proyecto, "codigo", None) or "",
            empresa_id,
            proyecto_id=proyecto_id,
        )

        filename = "001 - Stakeholders.xlsx"
        data = {
            "#REVISION": self._format_revision_label(getattr(proyecto, "revision", None)),
            "#PRO_TITULO": self._resolve_project_title(proyecto, getattr(proyecto, "descripcion", None)),
            "#CODIGOPROYECTO": getattr(proyecto, "codigo", None) or getattr(proyecto, "codigo_root", None) or "",
            "#CODIGOREFERENCIAL": getattr(detail, "cod_referencial", None) or "",
            "#CIUDAD": getattr(detail, "ciudad", None) or "",
            "#PRO_FECHA": self._format_date_label(getattr(proyecto, "fecha_creacion", None)),
        }
        table_data = []
        for index, stk in enumerate(stakeholders, start=1):
            location = self._join_report_parts([
                getattr(stk, "ciudad", None),
                getattr(stk, "canton", None),
            ], " / ")
            profession = self._join_report_parts([
                getattr(stk, "profesion", None),
                getattr(stk, "institucion", None),
            ])
            table_data.append({
                "#ITEM": index,
                "#CODIGO_STKR": getattr(stk, "codigo", None) or "",
                "#NOMBRES": self._normalize_report_description(getattr(stk, "nombre", None)),
                "#APELLIDOS": self._normalize_report_description(getattr(stk, "apellidos", None)),
                "#PROFESION": self._normalize_report_description(profession),
                "#DIRECCIONSTKR": self._normalize_report_description(getattr(stk, "direccion_detalle", None)),
                "#CIUDADSTKR": location,
                "#PROVINCIASTKR": getattr(stk, "provincia", None) or "",
                "#PAISSTKR": getattr(stk, "pais", None) or "",
                "#TELEFONOSTKR": getattr(stk, "movil", None) or "",
                "#CORREOSTKR": getattr(stk, "email", None) or "",
                "#ROL": getattr(stk, "rol_nombre", None) or "Sin rol",
            })

        template_path = os.path.join(self.templates_dir, filename)
        if not os.path.exists(template_path):
            raise FileNotFoundError(f"Plantilla no encontrada: {template_path}")
        wb = openpyxl.load_workbook(template_path)
        ws = wb.active
        self._apply_template_to_sheet(ws, data, table_data, "#ITEM")
        self._apply_omniclass_visibility(ws, False)
        self._prepare_stakeholders_report_sheet(ws, 10, len(table_data))
        return self._save_workbook_buffer(wb)

    def _get_project_reference_code(self, db: Any, presupuesto: Any) -> str:
        from app.models.proyecto_detalle import ProyectoDetalle

        proyecto = getattr(presupuesto, "proyecto", None)
        if not proyecto:
            return ""

        codigo_root = getattr(proyecto, "codigo_root", None)
        empresa_id = getattr(proyecto, "empresa_id", None) or getattr(presupuesto, "empresa_id", None)
        if not codigo_root or not empresa_id:
            return ""

        detail = (
            db.query(ProyectoDetalle)
            .filter(
                ProyectoDetalle.codigo_root == codigo_root,
                ProyectoDetalle.empresa_id == empresa_id,
            )
            .first()
        )
        return getattr(detail, "cod_referencial", "") or ""

    def _get_project_detail(self, db: Any, proyecto: Any, empresa_id: Optional[int] = None) -> Any:
        from app.models.proyecto_detalle import ProyectoDetalle

        if not proyecto:
            return None

        codigo_root = getattr(proyecto, "codigo_root", None)
        resolved_empresa_id = empresa_id or getattr(proyecto, "empresa_id", None)
        if not codigo_root or not resolved_empresa_id:
            return None

        return (
            db.query(ProyectoDetalle)
            .filter(
                ProyectoDetalle.codigo_root == codigo_root,
                ProyectoDetalle.empresa_id == resolved_empresa_id,
            )
            .first()
        )

    def _get_project_location(self, db: Any, proyecto: Any, empresa_id: Optional[int] = None) -> str:
        detail = self._get_project_detail(db, proyecto, empresa_id)
        if not detail:
            return ""

        parts = [
            getattr(detail, "provincia", None),
            getattr(detail, "canton", None),
            getattr(detail, "ciudad", None),
            getattr(detail, "direccion", None),
        ]
        return " · ".join([part.strip() for part in parts if isinstance(part, str) and part.strip()])

    def _get_budget_line_edt_code(self, line: Any) -> str:
        edt_node = getattr(line, "edt_node", None)
        return (
            getattr(edt_node, "codigo", None)
            or getattr(edt_node, "codigo_completo", None)
            or getattr(line, "codigo_item", None)
            or ""
        )

    def _get_budget_line_visible_item_code(self, line: Any) -> str:
        if getattr(line, "apu_id", None) is None:
            return ""
        return str(getattr(line, "codigo_item", None) or "").strip()

    def _get_budget_line_visible_edt_code(self, line: Any) -> str:
        edt_node = getattr(line, "edt_node", None)
        edt_code = (
            getattr(edt_node, "codigo", None)
            or getattr(edt_node, "codigo_completo", None)
            or ""
        )
        edt_code = str(edt_code or "").strip()
        if edt_code:
            return edt_code

        structural_code = str(getattr(line, "codigo_item", None) or "").strip()
        if getattr(line, "apu_id", None) is None:
            return structural_code

        if "." in structural_code:
            return structural_code.rsplit(".", 1)[0].strip()
        return ""

    def _split_hierarchical_code(self, value: Any) -> Tuple[Any, ...]:
        raw = str(value or "").strip()
        if not raw:
            return (float("inf"),)
        parts: List[Any] = []
        for token in raw.split("."):
            token = token.strip()
            if token.isdigit():
                parts.append(int(token))
            elif token:
                parts.append(token.lower())
        return tuple(parts) if parts else (float("inf"),)

    def _get_budget_line_sort_key(self, line: Any) -> Tuple[Any, ...]:
        edt_code = self._get_budget_line_edt_code(line)
        item_code = getattr(line, "codigo_item", None) or edt_code
        is_structural = getattr(line, "apu_id", None) is None
        return (
            self._split_hierarchical_code(edt_code),
            0 if is_structural else 1,
            self._split_hierarchical_code(item_code),
            getattr(line, "id", 0) or 0,
        )

    def _sort_budget_lines_for_report(self, lines: List[Any]) -> List[Any]:
        return sorted(lines, key=self._get_budget_line_sort_key)

    def _resolve_budget_line_report_item(self, line: Any) -> Any:
        orden = getattr(line, "orden", None)
        if orden is None:
            return ""
        try:
            return int(orden) + 1
        except (TypeError, ValueError):
            return orden

    def _get_budget_line_display_code(self, line: Any) -> str:
        return (getattr(line, "codigo_item", None) or self._get_budget_line_edt_code(line) or "").strip()

    def _get_budget_structural_total(self, line: Any, detail_lines: List[Any]) -> float:
        code = self._get_budget_line_display_code(line)
        if not code:
            return 0.0
        prefix = f"{code}."
        total = 0.0
        for detail in detail_lines:
            if getattr(detail, "apu_id", None) is None:
                continue
            detail_code = self._get_budget_line_display_code(detail)
            if detail_code == code or detail_code.startswith(prefix):
                total += float(getattr(detail, "precio_total", 0) or 0)
        return total

    def _build_presupuesto_table_data(self, presupuesto: Any, template_id: str = "001") -> List[Dict[str, Any]]:
        ordered_lines = self._sort_budget_lines_for_report(list(presupuesto.detalle or []))
        sercop_counter = 0
        table_data: List[Dict[str, Any]] = []

        for line in ordered_lines:
            is_structural = getattr(line, "apu_id", None) is None
            display_code = self._get_budget_line_display_code(line)
            item_visible = self._get_budget_line_visible_item_code(line)
            edt_code_visible = self._get_budget_line_visible_edt_code(line)
            apu = getattr(line, "apu", None)
            apu_code = (getattr(apu, "codigo", None) or "").strip() if apu else ""
            descripcion = str(getattr(line, "descripcion", "") or "").strip()
            structural_total = self._get_budget_structural_total(line, ordered_lines) if is_structural else 0.0

            if template_id == "002":
                item_value = ""
                if not is_structural:
                    sercop_counter += 1
                    item_value = sercop_counter
                table_data.append({
                    "__STRUCTURAL": is_structural,
                    "ITEM": item_value,
                    "ITEM_VISIBLE": item_visible,
                    "CODIGO_EDT": edt_code_visible,
                    "DESCRIPCION": descripcion.upper() if is_structural else self._normalize_report_description(descripcion),
                    "UNIDAD": "" if is_structural else (line.unidad or ""),
                    "CANTIDAD": "" if is_structural else float(line.cantidad) if line.cantidad else 0.0,
                    "PUNITARIO": "" if is_structural else float(line.precio_unitario) if line.precio_unitario else 0.0,
                    "SUBTOTAL": float(structural_total if is_structural else (line.precio_total or 0)),
                })
                continue

            table_data.append({
                "__STRUCTURAL": is_structural,
                "ITEM": display_code,
                "ITEM_VISIBLE": item_visible,
                "CODIGO_EDT": edt_code_visible,
                "CODIGO_APU": "" if is_structural else apu_code,
                "DESCRIPCION": descripcion.upper() if is_structural else self._normalize_report_description(descripcion),
                "UNIDAD": "" if is_structural else (line.unidad or ""),
                "CANTIDAD": "" if is_structural else float(line.cantidad) if line.cantidad else 0.0,
                "PUNITARIO": "" if is_structural else float(line.precio_unitario) if line.precio_unitario else 0.0,
                "SUBTOTAL": float(structural_total if is_structural else (line.precio_total or 0)),
            })

        return table_data

    def _apply_presupuesto_row_typography(self, ws, table_rows: List[Dict[str, Any]], template_id: str) -> None:
        data_start_row = 7 if template_id == "002" else 9
        for offset, row_data in enumerate(table_rows):
            row_idx = data_start_row + offset
            is_structural = bool(row_data.get("__STRUCTURAL"))
            for cell in ws[row_idx]:
                if cell.value in (None, ""):
                    continue
                current_font = copy(cell.font)
                current_font.bold = is_structural
                cell.font = current_font

    def _template_requires_category_engine(self, ws) -> bool:
        category_tokens = (
            "#CODCAT1",
            "#CANTIDAD1",
            "#PRECIO1",
            "#RENDIMIENTO1",
            "#SUBTOTAL1",
            "#PORCENT1",
            "#TOTAL1",
            "#TOTPORCENT1",
            "TOTPORCENT1",
            "#OMNICLASS_COD1",
            "#OMNICLASS_TIT1",
            "@OMNICLASS_TIT1",
        )
        for row in ws.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and any(token in cell.value for token in category_tokens):
                    return True
        return False

    def _get_empresa_format_config(self, db: Any, empresa_id: int) -> Dict[str, int]:
        from app.models.empresa import Empresa

        empresa = db.query(Empresa).filter(Empresa.id == empresa_id).first()
        return {
            "money_decimals": int(getattr(empresa, "decimales_moneda", 2) or 2),
            "calc_decimals": int(getattr(empresa, "decimales_calculos", 4) or 4),
            "use_omniclass": bool(getattr(empresa, "use_omniclass", True)),
        }

    def _resolve_use_omniclass(self, format_config: Dict[str, Any], template_id: Optional[str] = None) -> bool:
        if str(template_id or "") == "002":
            return False
        return bool(format_config.get("use_omniclass", True))

    def _round_half_up(self, value: Any, decimals: int) -> float:
        return float(round_decimal(Decimal(str(value if value is not None else 0)), decimals))

    def _format_fixed(self, value: Any, decimals: int) -> str:
        return f"{self._round_half_up(value, decimals):.{decimals}f}"

    def _format_for_excel(self, value: Any, kind: str, money_decimals: int, calc_decimals: int) -> Any:
        if value is None or value == "":
            return ""
        if kind == "money":
            return self._format_fixed(value, money_decimals)
        if kind == "percent":
            return self._format_fixed(value, money_decimals)
        if kind == "calc":
            return self._format_fixed(value, calc_decimals)
        return value

    def _format_excel_data(self, data: Dict[str, Any], field_kinds: Dict[str, str], money_decimals: int, calc_decimals: int) -> Dict[str, Any]:
        return {
            key: self._format_for_excel(value, field_kinds.get(key, "raw"), money_decimals, calc_decimals)
            for key, value in data.items()
        }

    def _format_excel_rows(self, rows: List[Dict[str, Any]], field_kinds: Dict[str, str], money_decimals: int, calc_decimals: int) -> List[Dict[str, Any]]:
        formatted_rows = []
        for row in rows:
            formatted_rows.append({
                key: self._format_for_excel(value, field_kinds.get(key, "raw"), money_decimals, calc_decimals)
                for key, value in row.items()
            })
        return formatted_rows

    def _replace_placeholder_token(self, text: str, placeholder: str, value: Any) -> str:
        if not isinstance(text, str) or placeholder not in text:
            return text
        safe_value = "" if value is None else str(value)
        pattern = re.compile(re.escape(placeholder) + r"(?![A-Za-z0-9_])")
        return pattern.sub(safe_value, text)

    def _copy_cell_style(self, source_cell, target_cell) -> None:
        if source_cell.has_style:
            target_cell.font = copy(source_cell.font)
            target_cell.border = copy(source_cell.border)
            target_cell.fill = copy(source_cell.fill)
            target_cell.number_format = copy(source_cell.number_format)
            target_cell.protection = copy(source_cell.protection)
            target_cell.alignment = copy(source_cell.alignment)

    def _ensure_apu_omniclass_columns(self, ws) -> None:
        ws.column_dimensions[get_column_letter(9)].width = max(ws.column_dimensions[get_column_letter(9)].width or 0, 18)
        ws.column_dimensions[get_column_letter(10)].width = max(ws.column_dimensions[get_column_letter(10)].width or 0, 34)

        for category_idx in range(1, 5):
            item_row_idx = self._find_row_with_any_placeholder(ws, [f"#CODCAT{category_idx}"])
            if not item_row_idx:
                continue

            header_row_idx = item_row_idx - 1
            header_code_cell = ws.cell(row=header_row_idx, column=9)
            header_title_cell = ws.cell(row=header_row_idx, column=10)
            item_code_cell = ws.cell(row=item_row_idx, column=9)
            item_title_cell = ws.cell(row=item_row_idx, column=10)

            if not header_code_cell.value:
                header_code_cell.value = "OmniClass Cod"
            if not header_title_cell.value:
                header_title_cell.value = "Clasificación"
            if not item_code_cell.value:
                item_code_cell.value = f"#OMNICLASS_COD{category_idx}"
            if not item_title_cell.value:
                item_title_cell.value = f"#OMNICLASS_TIT{category_idx}"

            style_header_source_row = 10 if ws.cell(row=10, column=9).has_style or ws.cell(row=10, column=10).has_style else header_row_idx
            style_item_source_row = 11 if ws.cell(row=11, column=9).has_style or ws.cell(row=11, column=10).has_style else item_row_idx
            style_header_source_col = 9 if ws.cell(row=style_header_source_row, column=9).has_style else 8
            style_title_source_col = 10 if ws.cell(row=style_header_source_row, column=10).has_style else 8
            style_item_source_col = 9 if ws.cell(row=style_item_source_row, column=9).has_style else 8
            style_item_title_source_col = 10 if ws.cell(row=style_item_source_row, column=10).has_style else 8

            self._copy_cell_style(ws.cell(row=style_header_source_row, column=style_header_source_col), header_code_cell)
            self._copy_cell_style(ws.cell(row=style_header_source_row, column=style_title_source_col), header_title_cell)
            self._copy_cell_style(ws.cell(row=style_item_source_row, column=style_item_source_col), item_code_cell)
            self._copy_cell_style(ws.cell(row=style_item_source_row, column=style_item_title_source_col), item_title_cell)

    def _ensure_apu_omniclass_columns_with_metadata(self, ws, metadata: Dict[str, Any]) -> None:
        ws.column_dimensions[get_column_letter(9)].width = max(ws.column_dimensions[get_column_letter(9)].width or 0, 18)
        ws.column_dimensions[get_column_letter(10)].width = max(ws.column_dimensions[get_column_letter(10)].width or 0, 34)

        for category_idx, category_meta in (metadata.get("categories") or {}).items():
            item_row_idx = category_meta.get("item_row")
            if not item_row_idx:
                continue

            header_row_idx = item_row_idx - 1
            header_code_cell = ws.cell(row=header_row_idx, column=9)
            header_title_cell = ws.cell(row=header_row_idx, column=10)
            item_code_cell = ws.cell(row=item_row_idx, column=9)
            item_title_cell = ws.cell(row=item_row_idx, column=10)

            if not header_code_cell.value:
                header_code_cell.value = "OmniClass Cod"
            if not header_title_cell.value:
                header_title_cell.value = "Clasificación"
            if not item_code_cell.value:
                item_code_cell.value = f"#OMNICLASS_COD{category_idx}"
            if not item_title_cell.value:
                item_title_cell.value = f"#OMNICLASS_TIT{category_idx}"

            header_style_source = ws.cell(row=header_row_idx, column=8 if ws.max_column >= 8 else header_title_cell.column)
            item_style_source = ws.cell(row=item_row_idx, column=8 if ws.max_column >= 8 else item_title_cell.column)
            self._copy_cell_style(header_style_source, header_code_cell)
            self._copy_cell_style(header_style_source, header_title_cell)
            self._copy_cell_style(item_style_source, item_code_cell)
            self._copy_cell_style(item_style_source, item_title_cell)

    def _apply_omniclass_visibility(self, ws, use_omniclass: bool) -> None:
        if use_omniclass:
            return

        columns_to_hide = set()
        token_markers = ("OMNICLASS", "OMNICLASS_COD", "OMNICLASS_TIT")
        literal_markers = {"OmniClass Cod", "Clasificación"}

        for row in ws.iter_rows():
            for cell in row:
                if not isinstance(cell.value, str):
                    continue
                value = cell.value.strip()
                upper_value = value.upper()
                if any(token in upper_value for token in token_markers) or value in literal_markers:
                    columns_to_hide.add(cell.column)

        for column_index in columns_to_hide:
            ws.column_dimensions[get_column_letter(column_index)].hidden = True

    def _shift_merged_ranges_below_row(self, ws, start_row: int, delta_rows: int) -> None:
        if not delta_rows:
            return
        ranges_to_shift = [CellRange(str(rng)) for rng in ws.merged_cells.ranges if rng.min_row >= start_row]
        for merged_range in ranges_to_shift:
            try:
                ws.unmerge_cells(str(merged_range))
            except KeyError:
                if str(merged_range) in ws.merged_cells:
                    ws.merged_cells.remove(str(merged_range))
        for merged_range in ranges_to_shift:
            ws.merge_cells(
                start_row=merged_range.min_row + delta_rows,
                start_column=merged_range.min_col,
                end_row=merged_range.max_row + delta_rows,
                end_column=merged_range.max_col,
            )

    def _apply_template_to_sheet(self, ws, data: Dict[str, Any], table_data: List[Dict[str, Any]] = None, table_row_marker: str = None) -> None:
        if table_data and table_row_marker:
            marker_row_idx = -1
            marker_cols = {}

            for row in ws.iter_rows():
                found = False
                for cell in row:
                    if isinstance(cell.value, str) and table_row_marker in cell.value:
                        marker_row_idx = cell.row
                        found = True
                        break
                if found:
                    for cell in ws[marker_row_idx]:
                        if isinstance(cell.value, str) and cell.value.startswith('#'):
                            marker_cols[cell.value] = cell.column
                    break

            if marker_row_idx != -1:
                footer_placeholders = [
                    key for key in data.keys()
                    if isinstance(key, str) and key.startswith('#') and key not in marker_cols
                ]
                footer_row_idx = self._find_next_placeholder_row(ws, marker_row_idx + 1, footer_placeholders)
                if footer_row_idx and footer_row_idx > marker_row_idx + 1:
                    self._remove_rows_between(ws, marker_row_idx + 1, footer_row_idx - 1)

                num_rows = len(table_data)
                if num_rows > 1:
                    self._shift_merged_ranges_below_row(ws, marker_row_idx + 1, num_rows - 1)
                    ws.insert_rows(marker_row_idx + 1, num_rows - 1)
                    source_row = ws[marker_row_idx]
                    for i in range(1, num_rows):
                        target_row_idx = marker_row_idx + i
                        for cell in source_row:
                            new_cell = ws.cell(row=target_row_idx, column=cell.column)
                            if cell.has_style:
                                from copy import copy
                                new_cell.font = copy(cell.font)
                                new_cell.border = copy(cell.border)
                                new_cell.fill = copy(cell.fill)
                                new_cell.number_format = copy(cell.number_format)
                                new_cell.protection = copy(cell.protection)
                                new_cell.alignment = copy(cell.alignment)

                for i, row_data in enumerate(table_data):
                    current_row_idx = marker_row_idx + i
                    for placeholder, col_idx in marker_cols.items():
                        clean_key = placeholder.replace('#', '')
                        import re
                        clean_key = re.sub(r'\d+$', '', clean_key)
                        if placeholder in row_data:
                            val = row_data.get(placeholder)
                        elif clean_key in row_data:
                            val = row_data.get(clean_key)
                        elif placeholder.replace('#', '') in row_data:
                            val = row_data.get(placeholder.replace('#', ''))
                        else:
                            val = ""
                        ws.cell(row=current_row_idx, column=col_idx).value = val

        for row in ws.iter_rows():
            for cell in row:
                if isinstance(cell.value, str):
                    for key, val in data.items():
                        if cell.value == key:
                            cell.value = val
                            break
                        cell.value = self._replace_placeholder_token(cell.value, key, val)

    def _copy_sheet_row(self, ws, source_row_idx: int, target_row_idx: int) -> None:
        source_row = ws[source_row_idx]
        for cell in source_row:
            new_cell = ws.cell(row=target_row_idx, column=cell.column)
            if isinstance(cell.value, str) and cell.value.startswith("="):
                try:
                    new_cell.value = Translator(cell.value, origin=cell.coordinate).translate_formula(new_cell.coordinate)
                except Exception:
                    new_cell.value = cell.value
            else:
                new_cell.value = cell.value
            if cell.has_style:
                new_cell.font = copy(cell.font)
                new_cell.border = copy(cell.border)
                new_cell.fill = copy(cell.fill)
                new_cell.number_format = copy(cell.number_format)
                new_cell.protection = copy(cell.protection)
                new_cell.alignment = copy(cell.alignment)
        if source_row_idx in ws.row_dimensions:
            ws.row_dimensions[target_row_idx].height = ws.row_dimensions[source_row_idx].height
        self._clone_single_row_merged_ranges(ws, source_row_idx, target_row_idx)

    def _capture_row_blueprint(self, ws, row_idx: int) -> Dict[str, Any]:
        cells = []
        for col_idx in range(1, ws.max_column + 1):
            cell = ws.cell(row=row_idx, column=col_idx)
            cells.append({
                "col": col_idx,
                "value": cell.value,
                "font": copy(cell.font) if cell.has_style else None,
                "border": copy(cell.border) if cell.has_style else None,
                "fill": copy(cell.fill) if cell.has_style else None,
                "number_format": copy(cell.number_format) if cell.has_style else None,
                "protection": copy(cell.protection) if cell.has_style else None,
                "alignment": copy(cell.alignment) if cell.has_style else None,
            })
        merges = [
            (merged_range.min_col, merged_range.max_col)
            for merged_range in ws.merged_cells.ranges
            if merged_range.min_row == row_idx and merged_range.max_row == row_idx
        ]
        return {
            "height": ws.row_dimensions[row_idx].height,
            "cells": cells,
            "merges": merges,
        }

    def _clear_single_row_merges(self, ws, row_idx: int) -> None:
        ranges_to_remove = [
            str(merged_range)
            for merged_range in ws.merged_cells.ranges
            if merged_range.min_row == row_idx and merged_range.max_row == row_idx
        ]
        for range_ref in ranges_to_remove:
            try:
                ws.unmerge_cells(range_ref)
            except KeyError:
                if range_ref in ws.merged_cells:
                    ws.merged_cells.remove(range_ref)

    def _restore_row_blueprint(self, ws, row_idx: int, blueprint: Dict[str, Any]) -> None:
        self._clear_single_row_merges(ws, row_idx)
        for cell_meta in blueprint.get("cells", []):
            self._set_sheet_value_safe(ws, row_idx, cell_meta["col"], cell_meta.get("value"))
            target_cell = ws.cell(row=row_idx, column=cell_meta["col"])
            if isinstance(target_cell, MergedCell):
                continue
            if cell_meta.get("font") is not None:
                target_cell.font = copy(cell_meta["font"])
                target_cell.border = copy(cell_meta["border"])
                target_cell.fill = copy(cell_meta["fill"])
                target_cell.number_format = copy(cell_meta["number_format"])
                target_cell.protection = copy(cell_meta["protection"])
                target_cell.alignment = copy(cell_meta["alignment"])
        ws.row_dimensions[row_idx].height = blueprint.get("height")
        for min_col, max_col in blueprint.get("merges", []):
            ws.merge_cells(start_row=row_idx, start_column=min_col, end_row=row_idx, end_column=max_col)

    def _clone_single_row_merged_ranges(self, ws, source_row_idx: int, target_row_idx: int) -> None:
        source_ranges = [
            CellRange(str(merged_range))
            for merged_range in ws.merged_cells.ranges
            if merged_range.min_row == source_row_idx and merged_range.max_row == source_row_idx
        ]
        for merged_range in source_ranges:
            target_range = CellRange(
                min_col=merged_range.min_col,
                max_col=merged_range.max_col,
                min_row=target_row_idx,
                max_row=target_row_idx,
            )
            target_range_str = str(target_range)
            if target_range_str in ws.merged_cells:
                continue
            ws.merge_cells(target_range_str)

    def _replace_placeholders_in_row(self, ws, row_idx: int, replacements: Dict[str, Any]) -> None:
        for cell in ws[row_idx]:
            if not isinstance(cell.value, str):
                continue
            direct_placeholder = next((placeholder for placeholder in replacements if cell.value == placeholder), None)
            if direct_placeholder is not None:
                cell.value = replacements.get(direct_placeholder, "")
                continue
            new_value = cell.value
            for placeholder, value in replacements.items():
                new_value = self._replace_placeholder_token(new_value, placeholder, value)
            cell.value = new_value

    def _find_row_with_any_placeholder(self, ws, placeholders: List[str]) -> Optional[int]:
        for row in ws.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and any(placeholder in cell.value for placeholder in placeholders):
                    return cell.row
        return None

    def _find_next_placeholder_row(self, ws, start_row: int, placeholders: List[str]) -> Optional[int]:
        if not placeholders:
            return None
        for row in ws.iter_rows(min_row=max(1, start_row)):
            for cell in row:
                if isinstance(cell.value, str) and any(placeholder in cell.value for placeholder in placeholders):
                    return cell.row
        return None

    def _remove_rows_between(self, ws, start_row: int, end_row: int) -> int:
        if end_row < start_row:
            return 0
        count = end_row - start_row + 1
        deleted_end = start_row + count - 1
        ranges_to_process = [CellRange(str(rng)) for rng in ws.merged_cells.ranges if rng.max_row >= start_row]
        for merged_range in ranges_to_process:
            try:
                ws.unmerge_cells(str(merged_range))
            except KeyError:
                if str(merged_range) in ws.merged_cells:
                    ws.merged_cells.remove(str(merged_range))
        ws.delete_rows(start_row, count)
        for merged_range in ranges_to_process:
            if merged_range.min_row > deleted_end:
                ws.merge_cells(
                    start_row=merged_range.min_row - count,
                    start_column=merged_range.min_col,
                    end_row=merged_range.max_row - count,
                    end_column=merged_range.max_col,
                )
            elif merged_range.min_row < start_row and merged_range.max_row > deleted_end:
                ws.merge_cells(
                    start_row=merged_range.min_row,
                    start_column=merged_range.min_col,
                    end_row=merged_range.max_row - count,
                    end_column=merged_range.max_col,
                )
        return count

    def _clear_unresolved_placeholders(self, ws) -> None:
        token_pattern = re.compile(r"[#@][A-Za-z0-9_%]+")
        for row in ws.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and ("#" in cell.value or "@" in cell.value):
                    cell.value = token_pattern.sub("", cell.value).strip()

    def _resolve_apu_line_category(self, linea: Any) -> int:
        if getattr(linea, "apu_hijo_id", None):
            return 2
        recurso = getattr(linea, "recurso", None)
        codigo = getattr(recurso, "codigo", "") if recurso else ""
        try:
            return int(str(codigo).strip().split("-")[0])
        except (ValueError, IndexError):
            return 1

    def _build_apu_category_payload(self, apu: Any, money_decimals: int = 2, calc_decimals: int = 4, use_omniclass: bool = True) -> Dict[int, Dict[str, Any]]:
        costo_directo = float(apu.costo_directo or 0.0)
        categories: Dict[int, Dict[str, Any]] = {
            1: {"items": [], "total": 0.0, "percent": 0.0},
            2: {"items": [], "total": 0.0, "percent": 0.0},
            3: {"items": [], "total": 0.0, "percent": 0.0},
            4: {"items": [], "total": 0.0, "percent": 0.0},
        }

        for linea in sorted(apu.lineas, key=lambda item: ((item.orden or 0), item.id or 0)):
            recurso = getattr(linea, "recurso", None)
            apu_hijo = getattr(linea, "apu_hijo", None)
            category_id = self._resolve_apu_line_category(linea)
            if category_id not in categories:
                continue

            codigo = ""
            descripcion = ""
            unidad = ""
            precio = 0.0
            omniclass_cod = ""
            omniclass_tit = ""

            if recurso:
                codigo = self._resolve_apu_report_code(recurso)
                descripcion = self._normalize_report_description(recurso.descripcion)
                unidad = recurso.unidad.descripcion if (recurso.unidad and hasattr(recurso.unidad, 'descripcion')) else ""
                precio = float(recurso.precio or 0.0)
                omniclass_cod = recurso.omniclass_codigo or "" if use_omniclass else ""
                omniclass_tit = recurso.omniclass_titulo or "" if use_omniclass else ""
            elif apu_hijo:
                codigo = self._resolve_apu_report_code(apu_hijo)
                descripcion = self._normalize_report_description(apu_hijo.descripcion)
                unidad = apu_hijo.unidad or ""
                precio = float(apu_hijo.precio_unitario_total or 0.0)
                omniclass_cod = apu_hijo.omniclass_codigo or "" if use_omniclass else ""
                omniclass_tit = apu_hijo.omniclass_titulo or "" if use_omniclass else ""

            cantidad = float(linea.cantidad or 0.0)
            rendimiento = float(linea.rendimiento or 0.0) if linea.rendimiento is not None else ""
            subtotal = float(linea.subtotal or 0.0)
            percent = (subtotal / costo_directo) if costo_directo > 0 else 0.0

            categories[category_id]["items"].append({
                "CODCAT": codigo,
                "DESCRIPCION": descripcion,
                "UNIDAD": unidad,
                "CANTIDAD": self._round_half_up(cantidad, calc_decimals),
                "PRECIO": self._round_half_up(precio, money_decimals),
                "RENDIMIENTO": "" if rendimiento == "" else self._round_half_up(rendimiento, calc_decimals),
                "SUBTOTAL": self._round_half_up(subtotal, money_decimals),
                "PORCENT": self._round_half_up(percent, 8),
                "OMNICLASS_COD": omniclass_cod,
                "OMNICLASS_TIT": omniclass_tit,
            })
            categories[category_id]["total"] += subtotal

        for category_id, category in categories.items():
            category["total"] = self._round_half_up(category["total"], money_decimals)
            category["percent"] = self._round_half_up((float(category["total"]) / costo_directo) if costo_directo > 0 else 0.0, 8)

        return categories

    def _apply_apu_category_template(self, ws, apu: Any, data: Dict[str, Any], money_decimals: int = 2, calc_decimals: int = 4, use_omniclass: bool = True) -> None:
        self._apply_apu_category_template_with_metadata(
            ws,
            apu,
            data,
            self._extract_apu_template_metadata(ws),
            money_decimals,
            calc_decimals,
            use_omniclass,
        )

    def _apply_apu_category_template_with_metadata(
        self,
        ws,
        apu: Any,
        data: Dict[str, Any],
        metadata: Dict[str, Any],
        money_decimals: int = 2,
        calc_decimals: int = 4,
        use_omniclass: bool = True,
    ) -> None:
        layout_kind = metadata.get("layout_kind") or self._resolve_apu_layout_kind(ws)
        if use_omniclass:
            self._ensure_apu_omniclass_columns_with_metadata(ws, metadata)
        for cell_meta in metadata.get("data_cells", []):
            row_idx = cell_meta["row"]
            col_idx = cell_meta["col"]
            raw_value = cell_meta["value"]
            new_value = raw_value
            for key, val in data.items():
                new_value = self._replace_placeholder_token(new_value, key, val)
            self._set_sheet_value(ws, row_idx, col_idx, new_value)

        categories = self._build_apu_category_payload(apu, money_decimals, calc_decimals, use_omniclass)
        row_offset = 0

        for category_idx in range(1, 5):
            category_meta = metadata.get("categories", {}).get(category_idx)
            if not category_meta:
                continue

            item_row_idx = category_meta["item_row"] + row_offset
            summary_row_idx = (category_meta["summary_row"] + row_offset) if category_meta.get("summary_row") else None
            gap_rows = max(0, int(category_meta.get("gap_rows") or 0))

            if summary_row_idx and gap_rows:
                removed_rows = self._remove_rows_between(ws, item_row_idx + 1, summary_row_idx - 1)
                summary_row_idx -= removed_rows
                row_offset -= removed_rows

            category = categories.get(category_idx) or {"items": [], "total": 0.0, "percent": 0.0}
            items = category["items"] or [{}]
            extra_rows = max(0, len(items) - 1)

            if extra_rows:
                self._shift_merged_ranges_below_row(ws, item_row_idx + 1, extra_rows)
                ws.insert_rows(item_row_idx + 1, extra_rows)
                item_blueprint = category_meta.get("item_blueprint")
                for offset in range(1, extra_rows + 1):
                    if item_blueprint:
                        self._restore_row_blueprint(ws, item_row_idx + offset, item_blueprint)
                    else:
                        self._copy_sheet_row(ws, item_row_idx, item_row_idx + offset)

            adjusted_summary_row_idx = summary_row_idx + extra_rows if summary_row_idx and summary_row_idx > item_row_idx else summary_row_idx
            self._restore_apu_category_from_metadata(
                ws,
                category_meta,
                item_row_idx,
                adjusted_summary_row_idx,
            )

            for offset, item in enumerate(items):
                current_row_idx = item_row_idx + offset
                replacements = {
                    f"#CODCAT{category_idx}": item.get("CODCAT", ""),
                    f"#DESCRIPCION{category_idx}": item.get("DESCRIPCION", ""),
                    f"#UNIDAD{category_idx}": item.get("UNIDAD", ""),
                    f"#CANTIDAD{category_idx}": item.get("CANTIDAD", ""),
                    f"#PRECIO{category_idx}": item.get("PRECIO", ""),
                    f"#RENDIMIENTO{category_idx}": item.get("RENDIMIENTO", ""),
                    f"#SUBTOTAL{category_idx}": item.get("SUBTOTAL", ""),
                    f"#PORCENT{category_idx}": item.get("PORCENT", ""),
                    f"#OMNICLASS_COD{category_idx}": item.get("OMNICLASS_COD", ""),
                    f"#OMNICLASS_TIT{category_idx}": item.get("OMNICLASS_TIT", ""),
                    f"@OMNICLASS_TIT{category_idx}": item.get("OMNICLASS_TIT", ""),
                }
                self._replace_placeholders_in_row(ws, current_row_idx, replacements)
                self._ensure_apu_item_row_layout(ws, current_row_idx, item.get("DESCRIPCION", ""), layout_kind)

            if adjusted_summary_row_idx:
                self._replace_placeholders_in_row(ws, adjusted_summary_row_idx, {
                    f"#TOTAL{category_idx}": category["total"],
                    f"#TOTPORCENT{category_idx}": category["percent"],
                    f"TOTPORCENT{category_idx}": category["percent"],
                })
            row_offset += extra_rows

        self._sync_apu_footer_values(ws, data, metadata=metadata, row_offset=row_offset, money_decimals=money_decimals)
        self._clear_unresolved_placeholders(ws)

    def _find_row_containing_text(self, ws, needle: str) -> Optional[int]:
        for row in ws.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and needle in cell.value:
                    return cell.row
        return None

    def _set_sheet_value_safe(self, ws, row: int, column: int, value: Any) -> None:
        target_range = None
        for merged_range in ws.merged_cells.ranges:
            if merged_range.min_row <= row <= merged_range.max_row and merged_range.min_col <= column <= merged_range.max_col:
                target_range = merged_range
                break
        if target_range:
            try:
                ws.cell(target_range.min_row, target_range.min_col).value = value
            except AttributeError:
                ws._cells[(target_range.min_row, target_range.min_col)] = OpenPyxlCell(
                    ws,
                    row=target_range.min_row,
                    column=target_range.min_col,
                    value=value,
                )
        else:
            try:
                ws.cell(row, column).value = value
            except AttributeError:
                ws._cells[(row, column)] = OpenPyxlCell(ws, row=row, column=column, value=value)

    def _set_sheet_value(self, ws, row: int, column: int, value: Any) -> None:
        try:
            ws.cell(row, column).value = value
        except AttributeError:
            self._set_sheet_value_safe(ws, row, column, value)

    def _resolve_apu_layout_kind(self, ws) -> str:
        if ws["A3"].value == "Rubro:":
            return "sercop"
        return "general"

    def _get_apu_category_blueprints(self, layout_kind: str, category_idx: int) -> Tuple[Dict[int, Any], Dict[int, Any]]:
        if layout_kind == "sercop":
            header_map = {
                1: {1: "Descripción", 2: "Cantidad", 3: "Tarifa", 4: "Costo hora", 5: "Rendimiento", 6: "Costo"},
                2: {1: "Descripción", 3: "Unidad", 4: "Cantidad", 5: "Precio unitario", 6: "Costo"},
                3: {1: "Descripción", 3: "Unidad", 4: "Cantidad", 5: "Tarifa", 6: "Costo"},
                4: {1: "Descripción", 2: "Cantidad", 3: "Jornal/hr", 4: "Costo hora", 5: "Rendimiento", 6: "Costo"},
            }
            item_map = {
                1: {1: "#DESCRIPCION1", 2: "#CANTIDAD1", 3: "#PRECIO1", 5: "#RENDIMIENTO1", 6: "#SUBTOTAL1"},
                2: {1: "#DESCRIPCION2", 3: "#UNIDAD2", 4: "#CANTIDAD2", 5: "#PRECIO2", 6: "#SUBTOTAL2"},
                3: {1: "#DESCRIPCION3", 3: "#UNIDAD3", 4: "#CANTIDAD3", 5: "#PRECIO3", 6: "#SUBTOTAL3"},
                4: {1: "#DESCRIPCION4", 2: "#CANTIDAD4", 3: "#PRECIO4", 5: "#RENDIMIENTO4", 6: "#SUBTOTAL4"},
            }
            return header_map.get(category_idx, {}), item_map.get(category_idx, {})

        header_map = {
            1: {1: "Código", 2: "Descripción", 3: "Unidad", 4: "Cantidad", 5: "Precio", 6: "Rendim.", 7: "Total", 8: "%"},
            2: {1: "Código", 2: "Descripción", 3: "Unidad", 4: "Cantidad", 5: "Precio", 7: "Total", 8: "%"},
            3: {1: "Código", 2: "Descripción", 3: "Unidad", 4: "Cantidad", 5: "Tarifa/U", 6: "Distancia", 7: "Total", 8: "%"},
            4: {1: "Código", 2: "Descripción", 4: "Número", 5: "S.R.H.", 6: "Rendim.", 7: "Total", 8: "%"},
        }
        item_map = {
            1: {1: "#CODCAT1", 2: "#DESCRIPCION1", 3: "#UNIDAD1", 4: "#CANTIDAD1", 5: "#PRECIO1", 6: "#RENDIMIENTO1", 7: "#SUBTOTAL1", 8: "#PORCENT1"},
            2: {1: "#CODCAT2", 2: "#DESCRIPCION2", 3: "#UNIDAD2", 4: "#CANTIDAD2", 5: "#PRECIO2", 7: "#SUBTOTAL2", 8: "#PORCENT2"},
            3: {1: "#CODCAT3", 2: "#DESCRIPCION3", 3: "#UNIDAD3", 4: "#CANTIDAD3", 5: "#PRECIO3", 6: "#RENDIMIENTO3", 7: "#SUBTOTAL3", 8: "#PORCENT3"},
            4: {1: "#CODCAT4", 2: "#DESCRIPCION4", 4: "#CANTIDAD4", 5: "#PRECIO4", 6: "#RENDIMIENTO4", 7: "#SUBTOTAL4", 8: "#PORCENT4"},
        }
        return header_map.get(category_idx, {}), item_map.get(category_idx, {})

    def _restore_apu_category_row_blueprints(self, ws, category_idx: int, item_row_idx: int) -> None:
        layout_kind = self._resolve_apu_layout_kind(ws)
        header_values, item_values = self._get_apu_category_blueprints(layout_kind, category_idx)
        header_row_idx = item_row_idx - 1
        for column, value in header_values.items():
            self._set_sheet_value(ws, header_row_idx, column, value)
        for column, value in item_values.items():
            self._set_sheet_value(ws, item_row_idx, column, value)

    def _restore_apu_category_from_metadata(self, ws, category_meta: Dict[str, Any], item_row_idx: int, summary_row_idx: Optional[int]) -> None:
        pre_title_blueprint = category_meta.get("pre_title_blueprint")
        title_blueprint = category_meta.get("title_blueprint")
        header_blueprint = category_meta.get("header_blueprint")
        item_blueprint = category_meta.get("item_blueprint")
        summary_blueprint = category_meta.get("summary_blueprint")
        if pre_title_blueprint:
            self._restore_row_blueprint(ws, item_row_idx - 3, pre_title_blueprint)
        if title_blueprint:
            self._restore_row_blueprint(ws, item_row_idx - 2, title_blueprint)
        if header_blueprint:
            self._restore_row_blueprint(ws, item_row_idx - 1, header_blueprint)
        if item_blueprint:
            self._restore_row_blueprint(ws, item_row_idx, item_blueprint)
        if summary_row_idx and summary_blueprint:
            self._restore_row_blueprint(ws, summary_row_idx, summary_blueprint)

    def _ensure_apu_item_row_layout(self, ws, row_idx: int, description: Any, layout_kind: str) -> None:
        desc_col = 1 if layout_kind == "sercop" else 2
        desc_cell = ws.cell(row=row_idx, column=desc_col)
        current_alignment = copy(desc_cell.alignment) if desc_cell.alignment else Alignment()
        current_alignment.wrap_text = True
        current_alignment.vertical = current_alignment.vertical or "center"
        desc_cell.alignment = current_alignment

        text = str(description or "").strip()
        if not text:
            return

        chars_per_line = 34 if layout_kind == "sercop" else 28
        line_count = max(1, text.count("\n") + 1)
        estimated_lines = max(line_count, (len(text) // chars_per_line) + (1 if len(text) % chars_per_line else 0))

        if estimated_lines <= 1:
            target_height = 15
        elif estimated_lines == 2:
            target_height = 24
        else:
            target_height = min(14 * estimated_lines, 56)

        current_height = ws.row_dimensions[row_idx].height or 15
        if target_height > current_height:
            ws.row_dimensions[row_idx].height = target_height

    def _sync_apu_footer_values(
        self,
        ws,
        data: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
        row_offset: int = 0,
        money_decimals: int = 2,
    ) -> None:
        footer_rows = (metadata or {}).get("footer_rows", {})
        footer_block = (metadata or {}).get("footer_block") or {}
        layout_kind = (metadata or {}).get("layout_kind") or self._resolve_apu_layout_kind(ws)
        footer_start = footer_block.get("start_row")
        footer_rows_blueprints = footer_block.get("rows") or []
        if footer_start and footer_rows_blueprints:
            target_start = footer_start + row_offset
            for idx, blueprint in enumerate(footer_rows_blueprints):
                self._restore_row_blueprint(ws, target_start + idx, blueprint)

        if layout_kind != "sercop":
            direct_row = footer_rows.get("direct_row")
            if direct_row is not None:
                direct_row += row_offset
            else:
                direct_row = self._find_row_containing_text(ws, "Costo Directo Total")
            if direct_row:
                self._set_sheet_value_safe(ws, direct_row, 1, "Costo Directo Total: ")
                self._set_sheet_value(ws, direct_row, 8, data.get("#COSTODIRECTO", ""))

            indirect_title_row = footer_rows.get("indirect_title_row")
            if indirect_title_row is not None:
                indirect_title_row += row_offset
            else:
                indirect_title_row = self._find_row_containing_text(ws, "COSTOS INDIRECTOS")
            if indirect_title_row:
                self._set_sheet_value_safe(ws, indirect_title_row, 1, "COSTOS INDIRECTOS")
                indirect_row = indirect_title_row + 1
                if ws.max_column >= 8:
                    self._set_sheet_value(ws, indirect_row, 1, self._format_percent_label(data.get("#%INDIRECTO", 0), money_decimals))
                    self._set_sheet_value(ws, indirect_row, 8, data.get("#COSTOINDIRECTO", ""))

            total_row = footer_rows.get("total_row")
            if total_row is not None:
                total_row += row_offset
            else:
                total_row = self._find_row_containing_text(ws, "Precio Unitario Total")
            if total_row:
                self._set_sheet_value_safe(
                    ws,
                    total_row,
                    1,
                    "Precio Unitario Total .................................................................................................",
                )
                self._set_sheet_value(ws, total_row, 8, data.get("#TTOTAL", ""))

            words_row = footer_rows.get("words_row")
            if words_row is not None:
                words_row += row_offset
            else:
                words_row = self._find_row_containing_text(ws, "Son:")
            if words_row:
                self._set_sheet_value_safe(ws, words_row, 1, "Son:")
                self._set_sheet_value(ws, words_row, 2, data.get("#TEXTOTOTAL", ""))

        if layout_kind == "sercop":
            sercop_direct_row = footer_rows.get("sercop_direct_row")
            if sercop_direct_row is not None:
                sercop_direct_row += row_offset
            else:
                sercop_direct_row = self._find_row_containing_text(ws, "TOTAL COSTO DIRECTO (M+N+O+P)")
            if sercop_direct_row:
                self._set_sheet_value(ws, sercop_direct_row, 6, data.get("#COSTODIRECTO", ""))

            sercop_indirect_row = footer_rows.get("sercop_indirect_row")
            if sercop_indirect_row is not None:
                sercop_indirect_row += row_offset
            else:
                sercop_indirect_row = self._find_row_containing_text(ws, "INDIRECTOS")
            if sercop_indirect_row:
                self._set_sheet_value(ws, sercop_indirect_row, 5, self._format_percent_label(data.get("#%INDIRECTO", 0), money_decimals))
                self._set_sheet_value(ws, sercop_indirect_row, 6, data.get("#COSTOINDIRECTO", ""))

            sercop_total_row = footer_rows.get("sercop_total_row")
            if sercop_total_row is not None:
                sercop_total_row += row_offset
            else:
                sercop_total_row = self._find_row_containing_text(ws, "COSTO TOTAL DEL RUBRO")
            if sercop_total_row:
                self._set_sheet_value(ws, sercop_total_row, 6, data.get("#TTOTAL", ""))

            sercop_offer_row = footer_rows.get("sercop_offer_row")
            if sercop_offer_row is not None:
                sercop_offer_row += row_offset
            else:
                sercop_offer_row = self._find_row_containing_text(ws, "VALOR OFERTADO")
            if sercop_offer_row:
                self._set_sheet_value(ws, sercop_offer_row, 6, data.get("#TTOTAL", ""))

    def _extract_apu_template_metadata(self, ws) -> Dict[str, Any]:
        data_tokens = {
            "#CODIGO_APU",
            "#DESCRIPCION",
            "#CATEGORIA_BASE",
            "#UNIDAD",
            "#TTOTAL",
            "#COSTODIRECTO",
            "#COSTOINDIRECTO",
            "#%INDIRECTO",
            "#TOTALO",
            "#TEXTOTOTAL",
        }
        metadata = {
            "layout_kind": self._resolve_apu_layout_kind(ws),
            "data_cells": [],
            "categories": {},
            "footer_rows": {},
            "footer_block": {},
        }

        for row in ws.iter_rows():
            for cell in row:
                if not isinstance(cell.value, str):
                    continue
                if any(token in cell.value for token in data_tokens):
                    metadata["data_cells"].append({
                        "row": cell.row,
                        "col": cell.column,
                        "value": cell.value,
                    })

        for category_idx in range(1, 5):
            item_placeholders = [
                f"#CODCAT{category_idx}",
                f"#DESCRIPCION{category_idx}",
                f"#UNIDAD{category_idx}",
                f"#CANTIDAD{category_idx}",
                f"#PRECIO{category_idx}",
                f"#RENDIMIENTO{category_idx}",
                f"#SUBTOTAL{category_idx}",
                f"#PORCENT{category_idx}",
                f"#OMNICLASS_COD{category_idx}",
                f"#OMNICLASS_TIT{category_idx}",
                f"@OMNICLASS_TIT{category_idx}",
            ]
            summary_placeholders = [
                f"#TOTAL{category_idx}",
                f"#TOTPORCENT{category_idx}",
                f"TOTPORCENT{category_idx}",
            ]
            item_row = self._find_row_with_any_placeholder(ws, item_placeholders)
            summary_row = self._find_row_with_any_placeholder(ws, summary_placeholders)
            if item_row:
                metadata["categories"][category_idx] = {
                    "pre_title_row": item_row - 3 if item_row - 3 >= 1 else None,
                    "title_row": item_row - 2 if item_row - 2 >= 1 else None,
                    "header_row": item_row - 1,
                    "item_row": item_row,
                    "summary_row": summary_row,
                    "gap_rows": max(0, (summary_row or item_row) - item_row - 1),
                    "pre_title_blueprint": self._capture_row_blueprint(ws, item_row - 3) if item_row - 3 >= 1 else None,
                    "title_blueprint": self._capture_row_blueprint(ws, item_row - 2) if item_row - 2 >= 1 else None,
                    "header_blueprint": self._capture_row_blueprint(ws, item_row - 1),
                    "item_blueprint": self._capture_row_blueprint(ws, item_row),
                    "summary_blueprint": self._capture_row_blueprint(ws, summary_row) if summary_row else None,
                }

        footer_needles = {
            "direct_row": "Costo Directo Total",
            "indirect_title_row": "COSTOS INDIRECTOS",
            "total_row": "Precio Unitario Total",
            "words_row": "Son:",
            "sercop_direct_row": "TOTAL COSTO DIRECTO (M+N+O+P)",
            "sercop_indirect_row": "INDIRECTOS",
            "sercop_total_row": "COSTO TOTAL DEL RUBRO",
            "sercop_offer_row": "VALOR OFERTADO",
        }
        for key, needle in footer_needles.items():
            metadata["footer_rows"][key] = self._find_row_containing_text(ws, needle)

        footer_row_candidates = [row for row in metadata["footer_rows"].values() if row]
        if footer_row_candidates:
            footer_start = max(1, min(footer_row_candidates) - 1)
            footer_end = max(footer_row_candidates)
            metadata["footer_block"] = {
                "start_row": footer_start,
                "rows": [self._capture_row_blueprint(ws, row_idx) for row_idx in range(footer_start, footer_end + 1)],
            }

        return metadata

    def _get_apu_template_metadata(self, template_id: str) -> Dict[str, Any]:
        cached = self._apu_template_metadata_cache.get(template_id)
        if cached:
            return cached
        filename = self._resolve_apu_template_filename(template_id)
        template_path = os.path.join(self.templates_dir, filename)
        if not os.path.exists(template_path):
            raise FileNotFoundError(f"Plantilla no encontrada: {template_path}")
        wb = openpyxl.load_workbook(template_path)
        metadata = self._extract_apu_template_metadata(wb.active)
        self._apu_template_metadata_cache[template_id] = metadata
        return metadata

    def _sanitize_sheet_title(self, value: str, fallback: str) -> str:
        invalid = set(r'[]:*?/\\')
        cleaned = ''.join(ch for ch in (value or "") if ch not in invalid).strip()
        cleaned = cleaned[:31] if cleaned else fallback
        return cleaned or fallback

    def _build_pdf_report(self, title: str, items: List[Dict[str, Any]], money_decimals: int = 2, calc_decimals: int = 4) -> io.BytesIO:
        output = io.BytesIO()
        doc = SimpleDocTemplate(
            output,
            pagesize=landscape(A4),
            leftMargin=12 * mm,
            rightMargin=12 * mm,
            topMargin=12 * mm,
            bottomMargin=12 * mm,
            title=title or "Reporte",
        )
        doc.author = self.REPORT_AUTHOR
        doc.creator = self.REPORT_AUTHOR

        def apply_pdf_metadata(canvas, _doc):
            canvas.setAuthor(self.REPORT_AUTHOR)
            canvas.setCreator(self.REPORT_AUTHOR)
            canvas.setTitle(title or "Reporte")

        styles = getSampleStyleSheet()
        eyebrow_style = ParagraphStyle(
            "ReportEyebrow",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=8,
            leading=10,
            textColor=colors.HexColor("#F39200"),
            spaceAfter=4,
        )
        title_style = ParagraphStyle(
            "ReportTitle",
            parent=styles["Heading1"],
            fontName="Helvetica-Bold",
            fontSize=16,
            leading=19,
            textColor=colors.HexColor("#111827"),
            spaceAfter=4,
        )
        meta_style = ParagraphStyle(
            "ReportMeta",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=8,
            leading=10,
            textColor=colors.HexColor("#6B7280"),
            spaceAfter=10,
        )
        summary_label_style = ParagraphStyle(
            "ReportSummaryLabel",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=7,
            leading=9,
            textColor=colors.HexColor("#6B7280"),
        )
        summary_value_style = ParagraphStyle(
            "ReportSummaryValue",
            parent=styles["Normal"],
            fontName="Helvetica-Bold",
            fontSize=11,
            leading=13,
            textColor=colors.HexColor("#111827"),
        )
        summary_total_value_style = ParagraphStyle(
            "ReportSummaryTotalValue",
            parent=summary_value_style,
            textColor=colors.HexColor("#F39200"),
        )
        cell_style = ParagraphStyle(
            "ReportCell",
            parent=styles["Normal"],
            fontName="Helvetica",
            fontSize=7,
            leading=9,
            textColor=colors.HexColor("#111827"),
        )
        cell_bold_style = ParagraphStyle(
            "ReportCellBold",
            parent=cell_style,
            fontName="Helvetica-Bold",
        )
        cell_indented_style = ParagraphStyle(
            "ReportCellIndented",
            parent=cell_style,
            leftIndent=10,
        )

        def money(value: Any) -> str:
            return f"${self._round_half_up(value or 0, money_decimals):,.{money_decimals}f}"

        def calc(value: Any) -> str:
            if value in (None, ""):
                return "-"
            return self._format_fixed(value, calc_decimals)

        def render_value(value: Any, kind: str) -> str:
            if value in (None, ""):
                return "-"
            if kind == "money":
                return money(value)
            if kind == "percent":
                return self._format_fixed(value, money_decimals)
            if kind == "calc":
                return calc(value)
            return text(value)

        def text(value: Any) -> str:
            raw = "" if value is None else str(value)
            return (
                raw.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace('"', "&quot;")
            )

        story = []
        for index, item in enumerate(items):
            if index > 0:
                story.append(PageBreak())

            story.append(Paragraph(text(title or "Reporte"), eyebrow_style))
            story.append(Paragraph(f"{text(item.get('codigo') or '-') } - {text(item.get('descripcion') or '-')}", title_style))
            meta_parts = [
                f"Categoría base: {text(item.get('categoria_base') or '-')}",
                f"Unidad: {text(item.get('unidad') or '-')}",
            ]
            metadata_hint = item.get("metadata_hint")
            if metadata_hint:
                meta_parts.append(text(metadata_hint))
            else:
                meta_parts.extend([
                    f"Costo Directo: {money(item.get('costo_directo'))}",
                    f"Costo Indirecto: {money(item.get('costo_indirecto'))}",
                    f"Total: {money(item.get('precio_total'))}",
                ])
            story.append(Paragraph(" | ".join(meta_parts), meta_style))

            summary_cards = item.get("summary_cards") or [
                {"label": "DIRECTO", "value": item.get("costo_directo"), "kind": item.get("summary_direct_kind", "money")},
                {"label": "INDIRECTO", "value": item.get("costo_indirecto"), "kind": item.get("summary_indirect_kind", "money")},
                {"label": "TOTAL", "value": item.get("precio_total"), "kind": item.get("summary_total_kind", "money"), "tone": "total"},
            ]
            summary_data = [
                [Paragraph(text(card.get("label") or ""), summary_label_style) for card in summary_cards],
                [
                    Paragraph(
                        render_value(card.get("value"), card.get("kind", "text")),
                        summary_total_value_style if card.get("tone") == "total" else summary_value_style,
                    )
                    for card in summary_cards
                ],
            ]
            summary_table = Table(
                summary_data,
                colWidths=[(165 * mm) / max(len(summary_cards), 1)] * max(len(summary_cards), 1),
            )
            summary_table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 1), colors.HexColor("#F8FAFC")),
                ("BACKGROUND", (len(summary_cards) - 1, 0), (len(summary_cards) - 1, 1), colors.HexColor("#FFF7ED")),
                ("BOX", (0, 0), (-1, 1), 0.6, colors.HexColor("#D4D4D8")),
                ("INNERGRID", (0, 0), (-1, 1), 0.4, colors.HexColor("#E4E4E7")),
                ("LEFTPADDING", (0, 0), (-1, -1), 8),
                ("RIGHTPADDING", (0, 0), (-1, -1), 8),
                ("TOPPADDING", (0, 0), (-1, -1), 6),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ]))
            story.append(summary_table)
            story.append(Spacer(1, 6 * mm))

            fields = item.get("fields") or []
            if fields:
                field_rows = [
                    [
                        Paragraph(text(field.get("label") or ""), cell_bold_style),
                        Paragraph(text(field.get("value") or "-"), cell_style),
                    ]
                    for field in fields
                ]
                fields_table = Table(field_rows, colWidths=[52 * mm, 113 * mm])
                fields_table.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#F8FAFC")),
                    ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#E4E4E7")),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("TOPPADDING", (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                    ("LEFTPADDING", (0, 0), (-1, -1), 5),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                ]))
                story.append(fields_table)
                story.append(Spacer(1, 6 * mm))

            visual_blocks = []
            referential_image_url = item.get("image_referencial_url")
            referential_image_bytes = self._fetch_remote_image_bytes(referential_image_url) if referential_image_url else None
            if referential_image_bytes:
                visual_blocks.append(("Imagen referencial", referential_image_bytes))
            map_image_url = item.get("map_image_url")
            map_image_bytes = self._fetch_remote_image_bytes(map_image_url) if map_image_url else None
            if map_image_bytes:
                visual_blocks.append(("Georreferenciación", map_image_bytes))
            for block_label, block_bytes in visual_blocks:
                try:
                    story.append(Paragraph(text(block_label), meta_style))
                    story.append(Spacer(1, 2 * mm))
                    image = ReportLabImage(io.BytesIO(block_bytes), width=165 * mm, height=90 * mm)
                    image.hAlign = "CENTER"
                    story.append(image)
                    story.append(Spacer(1, 6 * mm))
                except Exception:
                    pass

            lineas = item.get("lineas", [])
            if lineas:
                table_columns = item.get("table_columns") or [
                    {"key": "codigo", "label": "Código"},
                    {"key": "descripcion", "label": "Descripción"},
                    {"key": "unidad", "label": "Unidad"},
                    {"key": "cantidad", "label": "Cant.", "kind": "calc"},
                    {"key": "precio", "label": "Precio", "kind": "money"},
                    {"key": "rendimiento", "label": "Rend.", "kind": "calc"},
                    {"key": "subtotal", "label": "Subtotal", "kind": "money"},
                ]
                table_rows = [[
                    Paragraph(text((column.get("label") or "-").upper()), cell_bold_style)
                    for column in table_columns
                ]]
                for linea in lineas:
                    is_structural = bool(linea.get("is_structural"))
                    row_cells = []
                    for column in table_columns:
                        column_key = column.get("key")
                        raw_value = linea.get(column_key)
                        kind = column.get("kind")
                        if column_key == "descripcion":
                            descripcion = text(raw_value or "-")
                            paragraph = Paragraph(
                                descripcion,
                                cell_bold_style if is_structural else cell_indented_style,
                            )
                            row_cells.append(paragraph)
                        elif column_key == "unidad":
                            row_cells.append(Paragraph(text(raw_value or "-"), cell_style))
                        else:
                            if kind == "money":
                                rendered_value = render_value(raw_value, "money")
                            elif kind == "calc":
                                rendered_value = render_value(raw_value, "calc")
                            else:
                                rendered_value = text(raw_value or "-")
                            row_cells.append(Paragraph(rendered_value, cell_style))
                    table_rows.append(row_cells)

                total_width = 226 * mm
                if len(table_columns) <= 4:
                    col_widths = [total_width / len(table_columns)] * len(table_columns)
                else:
                    description_index = next((idx for idx, column in enumerate(table_columns) if column.get("key") == "descripcion"), None)
                    remaining = len(table_columns) - (1 if description_index is not None else 0)
                    narrow_width = 24 * mm
                    description_width = max(total_width - (narrow_width * max(remaining, 1)), 55 * mm)
                    col_widths = []
                    for idx, _column in enumerate(table_columns):
                        col_widths.append(description_width if idx == description_index else narrow_width)
                report_table = Table(
                    table_rows,
                    repeatRows=1,
                    colWidths=col_widths,
                )
                report_table.setStyle(TableStyle([
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#F4F4F5")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#52525B")),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, -1), 7),
                    ("LEADING", (0, 0), (-1, -1), 8),
                    ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#E4E4E7")),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("TOPPADDING", (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                    ("LEFTPADDING", (0, 0), (-1, -1), 5),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#FAFAFA")]),
                ]))
                story.append(report_table)

        doc.build(story, onFirstPage=apply_pdf_metadata, onLaterPages=apply_pdf_metadata)
        output.seek(0)
        return output

    def fill_template(
        self,
        template_name: str,
        data: Dict[str, Any],
        table_data: List[Dict[str, Any]] = None,
        table_row_marker: str = None,
        use_omniclass: bool = True,
    ) -> io.BytesIO:
        """
        Llena una plantilla de Excel con datos simples y opcionalmente una tabla.
        - template_name: nombre del archivo (.xlsx)
        - data: mapeo de #PLACEHOLDER -> valor para campos simples
        - table_data: lista de diccionarios para filas de tabla
        - table_row_marker: un placeholder único que identifica la fila de la tabla (ej: '#DESCRIPCION')
        """
        template_path = os.path.join(self.templates_dir, template_name)
        if not os.path.exists(template_path):
            raise FileNotFoundError(f"Plantilla no encontrada: {template_path}")

        wb = openpyxl.load_workbook(template_path)
        ws = wb.active
        if self._template_requires_category_engine(ws):
            raise ValueError(
                "La plantilla Excel seleccionada requiere motor categorizado por bloques y no puede "
                "rellenarse con el motor genérico de tabla plana."
            )
        self._apply_template_to_sheet(ws, data, table_data, table_row_marker)
        self._apply_omniclass_visibility(ws, use_omniclass)

        # Guardar en buffer
        return self._save_workbook_buffer(wb)

    def _resolve_apu_template_filename(self, template_id: str) -> str:
        filename = f"{template_id} - Analisis - APUS - General.xlsx"
        if template_id == "002":
            filename = "002 - Analisis - APUS - SERCOP.xlsx"
        elif template_id == "003":
            filename = "001 - Analisis - APUS - General.xlsx"
        return filename

    def _get_apu(self, db: Any, apu_id: int, empresa_id: int) -> Any:
        from app.models.apu import APU, APULinea
        from app.models.recurso import Recurso

        apu = (
            db.query(APU)
            .options(
                selectinload(APU.subcategoria_item),
                selectinload(APU.lineas)
                .selectinload(APULinea.recurso)
                .selectinload(Recurso.unidad),
                selectinload(APU.lineas).selectinload(APULinea.apu_hijo),
            )
            .filter(APU.id == apu_id, APU.empresa_id == empresa_id)
            .first()
        )
        if not apu:
            raise ValueError(f"APU no encontrado: {apu_id}")
        return apu

    def _get_apus_map(self, db: Any, apu_ids: List[int], empresa_id: int) -> Dict[int, Any]:
        from app.models.apu import APU, APULinea
        from app.models.recurso import Recurso

        if not apu_ids:
            return {}

        apus = (
            db.query(APU)
            .options(
                selectinload(APU.subcategoria_item),
                selectinload(APU.lineas)
                .selectinload(APULinea.recurso)
                .selectinload(Recurso.unidad),
                selectinload(APU.lineas).selectinload(APULinea.apu_hijo),
            )
            .filter(APU.empresa_id == empresa_id, APU.id.in_(apu_ids))
            .all()
        )
        return {apu.id: apu for apu in apus}

    def _get_presupuesto(self, db: Any, presupuesto_id: int, empresa_id: int) -> Any:
        from app.models.edt import EdtNode
        from app.models.presupuesto import Presupuesto, PresupuestoDetalle
        from app.services.presupuesto import refresh_presupuesto_prices
        presupuesto = (
            db.query(Presupuesto)
            .options(
                selectinload(Presupuesto.indirectos),
                selectinload(Presupuesto.empresa),
                selectinload(Presupuesto.proyecto),
                selectinload(Presupuesto.detalle).selectinload(PresupuestoDetalle.apu),
                selectinload(Presupuesto.detalle).selectinload(PresupuestoDetalle.edt_node),
            )
            .filter(Presupuesto.id == presupuesto_id, Presupuesto.empresa_id == empresa_id)
            .first()
        )
        if not presupuesto:
            raise ValueError(f"Presupuesto no encontrado: {presupuesto_id}")
        refresh_presupuesto_prices(db, presupuesto.id)
        db.refresh(presupuesto)
        return (
            db.query(Presupuesto)
            .options(
                selectinload(Presupuesto.indirectos),
                selectinload(Presupuesto.empresa),
                selectinload(Presupuesto.proyecto),
                selectinload(Presupuesto.detalle).selectinload(PresupuestoDetalle.apu),
                selectinload(Presupuesto.detalle).selectinload(PresupuestoDetalle.edt_node),
            )
            .filter(Presupuesto.id == presupuesto_id, Presupuesto.empresa_id == empresa_id)
            .first()
        )

    def _get_presupuesto_distinct_apu_ids(self, presupuesto: Any) -> List[int]:
        seen = set()
        apu_ids: List[int] = []
        for line in self._sort_budget_lines_for_report(list(presupuesto.detalle or [])):
            apu_id = getattr(line, "apu_id", None)
            if not apu_id or apu_id in seen:
                continue
            seen.add(apu_id)
            apu_ids.append(apu_id)
        return apu_ids

    def _get_presupuesto_apus_map(self, db: Any, presupuesto: Any, empresa_id: int) -> Dict[int, Any]:
        apu_ids = self._get_presupuesto_distinct_apu_ids(presupuesto)
        preloaded_map = {}
        missing_ids: List[int] = []

        for apu_id in apu_ids:
            matching_line = next((line for line in presupuesto.detalle if getattr(line, "apu_id", None) == apu_id), None)
            apu = getattr(matching_line, "apu", None) if matching_line else None
            if apu is None:
                missing_ids.append(apu_id)
                continue
            preloaded_map[apu_id] = apu

        if missing_ids:
            preloaded_map.update(self._get_apus_map(db, missing_ids, empresa_id))

        return {apu_id: preloaded_map[apu_id] for apu_id in apu_ids if apu_id in preloaded_map}

    def _resolve_apu_base_category(self, apu: Any) -> str:
        subcategoria = getattr(apu, "subcategoria_item", None)
        descripcion = getattr(subcategoria, "descripcion", None) if subcategoria else None
        return descripcion or "-"

    def _resolve_apu_line_category_label(self, linea: Any) -> str:
        category_id = self._resolve_apu_line_category(linea)
        return {
            1: "Equipos y Herramientas",
            2: "Materiales",
            3: "Transporte",
            4: "Mano de Obra",
        }.get(category_id, "-")

    def _resolve_apu_report_code(self, entity: Any) -> str:
        # Los reportes APU deben exponer siempre el código interno real del sistema.
        return str(getattr(entity, "codigo", None) or "").strip()

    def _clone_sheet(self, source_ws, target_ws) -> None:
        for row in source_ws.iter_rows():
            for cell in row:
                target_cell = target_ws.cell(row=cell.row, column=cell.column)
                target_cell.value = cell.value
                if cell.has_style:
                    target_cell.font = copy(cell.font)
                    target_cell.border = copy(cell.border)
                    target_cell.fill = copy(cell.fill)
                    target_cell.number_format = copy(cell.number_format)
                    target_cell.protection = copy(cell.protection)
                    target_cell.alignment = copy(cell.alignment)
        for col_letter, dim in source_ws.column_dimensions.items():
            target_ws.column_dimensions[col_letter].width = dim.width
            target_ws.column_dimensions[col_letter].hidden = dim.hidden
        for row_idx, dim in source_ws.row_dimensions.items():
            target_ws.row_dimensions[row_idx].height = dim.height
            target_ws.row_dimensions[row_idx].hidden = dim.hidden
        for merged_range in source_ws.merged_cells.ranges:
            target_ws.merge_cells(str(merged_range))
        if source_ws.sheet_view:
            target_ws.sheet_view.zoomScale = source_ws.sheet_view.zoomScale
            target_ws.sheet_view.showGridLines = source_ws.sheet_view.showGridLines
        target_ws.freeze_panes = source_ws.freeze_panes

    def _get_formula(self, db: Any, presupuesto_id: int) -> Any:
        from app.models.polinomica import FormulaPolinomica
        formula = db.query(FormulaPolinomica).filter(FormulaPolinomica.presupuesto_id == presupuesto_id).first()
        if not formula:
            raise ValueError("Fórmula polinómica no encontrada para este presupuesto")
        return formula

    def _build_apu_report_payload(self, apu: Any, money_decimals: int = 2, calc_decimals: int = 4, use_omniclass: bool = True) -> Dict[str, Any]:
        categoria_base = self._resolve_apu_base_category(apu)
        data = {
            "#CODIGO_APU": self._resolve_apu_report_code(apu),
            "#DESCRIPCION": self._normalize_report_description(apu.descripcion),
            "#CATEGORIA_BASE": categoria_base,
            "#UNIDAD": apu.unidad,
            "#TTOTAL": self._round_half_up(float(apu.precio_unitario_total or 0.0), money_decimals),
            "#COSTODIRECTO": self._round_half_up(float(apu.costo_directo or 0.0), money_decimals),
            "#COSTOINDIRECTO": self._round_half_up(float(apu.costo_indirecto or 0.0), money_decimals),
            "#%INDIRECTO": self._round_half_up(((float(apu.costo_indirecto or 0) / float(apu.costo_directo or 1)) * 100.0) if float(apu.costo_directo or 0) > 0 else 0.0, money_decimals),
            "#TOTALO": self._round_half_up(float(apu.precio_unitario_total or 0.0), money_decimals),
        }

        table_data = []
        categorized_preview_lines: Dict[int, List[Dict[str, Any]]] = {1: [], 2: [], 3: [], 4: []}
        for linea in sorted(apu.lineas, key=lambda item: ((item.orden or 0), item.id or 0)):
            codigo = ""
            desc = ""
            unidad = ""
            precio = 0.0
            recurso = getattr(linea, 'recurso', None)
            apu_hijo = getattr(linea, 'apu_hijo', None)

            if recurso:
                codigo = self._resolve_apu_report_code(recurso)
                desc = self._normalize_report_description(recurso.descripcion)
                unidad = recurso.unidad.descripcion if (recurso.unidad and hasattr(recurso.unidad, 'descripcion')) else ""
                precio = float(recurso.precio or 0.0)
                omniclass_cod = recurso.omniclass_codigo or "" if use_omniclass else ""
                omniclass_tit = recurso.omniclass_titulo or "" if use_omniclass else ""
            elif apu_hijo:
                codigo = self._resolve_apu_report_code(apu_hijo)
                desc = self._normalize_report_description(apu_hijo.descripcion)
                unidad = apu_hijo.unidad or ""
                precio = float(apu_hijo.precio_unitario_total or 0.0)
                omniclass_cod = apu_hijo.omniclass_codigo or "" if use_omniclass else ""
                omniclass_tit = apu_hijo.omniclass_titulo or "" if use_omniclass else ""
            else:
                desc = "--- ITEM NO VINCULADO ---"
                omniclass_cod = ""
                omniclass_tit = ""

            quantity = float(linea.cantidad or 0)
            rendimiento = float(linea.rendimiento or 1.0)
            subtotal = float(linea.subtotal or 0.0)
            percent = float((subtotal / float(apu.costo_directo) * 100) if (apu.costo_directo and float(apu.costo_directo) > 0) else 0)

            table_data.append({
                "ITEM": codigo,
                "DESCRIPCION": desc,
                "UNIDAD": unidad,
                "CANTIDAD": quantity,
                "PRECIO": precio,
                "RENDIMIENTO": rendimiento,
                "SUBTOTAL": subtotal,
                "PORCENT": percent,
                "OMNICLASS_COD": omniclass_cod,
                "OMNICLASS_TIT": omniclass_tit
            })
            category_id = self._resolve_apu_line_category(linea)
            categorized_preview_lines.setdefault(category_id, []).append({
                "codigo": codigo,
                "descripcion": desc,
                "unidad": unidad,
                "categoria_principal": self._resolve_apu_line_category_label(linea),
                "cantidad": quantity,
                "precio": precio,
                "rendimiento": rendimiento,
                "subtotal": subtotal,
                "is_structural": False,
                "cantidad_kind": "calc",
                "precio_kind": "money",
                "rendimiento_kind": "calc",
                "subtotal_kind": "money",
            })

        category_labels = {
            1: "Equipos y Herramientas",
            2: "Materiales",
            3: "Transporte",
            4: "Mano de Obra",
        }
        preview_lines = []
        for category_id in (1, 2, 3, 4):
            category_label = category_labels.get(category_id, "-")
            category_lines = categorized_preview_lines.get(category_id) or []
            if not category_lines:
                continue
            preview_lines.append({
                "codigo": "",
                "descripcion": category_label,
                "unidad": "",
                "cantidad": "",
                "precio": "",
                "rendimiento": "",
                "subtotal": "",
                "is_structural": True,
                "cantidad_kind": "raw",
                "precio_kind": "raw",
                "rendimiento_kind": "raw",
                "subtotal_kind": "raw",
            })
            preview_lines.extend(category_lines)

        return {
            "data": data,
            "table_data": table_data,
            "preview": {
                "id": apu.id,
                "codigo": apu.codigo,
                "descripcion": self._normalize_report_description(apu.descripcion),
                "unidad": apu.unidad,
                "categoria_base": categoria_base,
                "costo_directo": float(apu.costo_directo or 0),
                "costo_indirecto": float(apu.costo_indirecto or 0),
                "precio_total": float(apu.precio_unitario_total or 0),
                "is_structural": False,
                "summary_direct_kind": "money",
                "summary_indirect_kind": "money",
                "summary_total_kind": "money",
                "lineas": preview_lines,
            }
        }

    def _build_apu_template_data(self, apu: Any, money_decimals: int = 2) -> Dict[str, Any]:
        categoria_base = self._resolve_apu_base_category(apu)
        return {
            "#CODIGO_APU": self._resolve_apu_report_code(apu),
            "#DESCRIPCION": self._normalize_report_description(apu.descripcion),
            "#CATEGORIA_BASE": categoria_base,
            "#UNIDAD": apu.unidad,
            "#TTOTAL": self._round_half_up(float(apu.precio_unitario_total or 0.0), money_decimals),
            "#COSTODIRECTO": self._round_half_up(float(apu.costo_directo or 0.0), money_decimals),
            "#COSTOINDIRECTO": self._round_half_up(float(apu.costo_indirecto or 0.0), money_decimals),
            "#%INDIRECTO": self._round_half_up(
                ((float(apu.costo_indirecto or 0) / float(apu.costo_directo or 1)) * 100.0)
                if float(apu.costo_directo or 0) > 0
                else 0.0,
                money_decimals,
            ),
            "#TOTALO": self._round_half_up(float(apu.precio_unitario_total or 0.0), money_decimals),
            "#TEXTOTOTAL": self._money_to_words_excel_usd_upper(float(apu.precio_unitario_total or 0.0)),
        }

    def _build_presupuesto_preview(self, presupuesto: Any) -> Dict[str, Any]:
        lineas = []
        for line in self._sort_budget_lines_for_report(list(presupuesto.detalle or [])):
            lineas.append({
                "item_visible": self._get_budget_line_visible_item_code(line),
                "edt_code_visible": self._get_budget_line_visible_edt_code(line),
                "descripcion": self._normalize_report_description(line.descripcion),
                "unidad": line.unidad or "",
                "cantidad": float(line.cantidad or 0),
                "precio": float(line.precio_unitario or 0),
                "rendimiento": "",
                "subtotal": float(line.precio_total or 0),
                "is_structural": getattr(line, "apu_id", None) is None,
                "cantidad_kind": "calc",
                "precio_kind": "money",
                "rendimiento_kind": "calc",
                "subtotal_kind": "money",
            })

        return {
            "id": presupuesto.id,
            "codigo": presupuesto.codigo or f"PRES-{presupuesto.id}",
            "descripcion": self._normalize_report_description(presupuesto.descripcion),
            "unidad": "Presupuesto",
            "costo_directo": float(presupuesto.subtotal or 0),
            "costo_indirecto": float(presupuesto.indirectos_total or 0),
            "precio_total": float(presupuesto.total or 0),
            "is_structural": True,
            "summary_direct_kind": "money",
            "summary_indirect_kind": "money",
            "summary_total_kind": "money",
            "table_columns": [
                { "key": "item_visible", "label": "Item" },
                { "key": "edt_code_visible", "label": "Cod EDT" },
                { "key": "descripcion", "label": "Descripción" },
                { "key": "unidad", "label": "Unidad" },
                { "key": "cantidad", "label": "Cant.", "kind": "calc" },
                { "key": "precio", "label": "Precio", "kind": "money" },
                { "key": "rendimiento", "label": "Rend." },
                { "key": "subtotal", "label": "Subtotal", "kind": "money" },
            ],
            "lineas": lineas,
        }

    def _build_edt_preview(self, db: Any, proyecto_id: int, empresa_id: int, report_type: str) -> Dict[str, Any]:
        from app.models.edt import EDT
        from app.models.proyecto import Proyecto

        proyecto = db.query(Proyecto).filter(Proyecto.id == proyecto_id, Proyecto.empresa_id == empresa_id).first()
        if not proyecto:
            raise ValueError("Proyecto no encontrado")

        nodos = db.query(EDT).filter(EDT.proyecto_id == proyecto_id).order_by(EDT.codigo_completo).all()
        lineas = [{
            "codigo": nodo.codigo_completo,
            "descripcion": self._normalize_report_description(nodo.descripcion),
            "unidad": nodo.tipo_nodo or "",
            "cantidad": nodo.nivel or 0,
            "precio": float(nodo.presupuesto_asignado or 0),
            "rendimiento": "",
            "subtotal": float(nodo.presupuesto_asignado or 0),
            "is_structural": True,
            "cantidad_kind": "calc",
            "precio_kind": "money",
            "rendimiento_kind": "calc",
            "subtotal_kind": "money",
        } for nodo in nodos]

        total = sum(float(nodo.presupuesto_asignado or 0) for nodo in nodos)
        return {
            "id": proyecto.id,
            "codigo": proyecto.codigo or f"PRO-{proyecto.id}",
            "descripcion": self._normalize_report_description(f"{proyecto.nombre} · EDT {report_type}"),
            "unidad": "EDT",
            "costo_directo": total,
            "costo_indirecto": 0,
            "precio_total": total,
            "is_structural": True,
            "summary_direct_kind": "money",
            "summary_indirect_kind": "money",
            "summary_total_kind": "money",
            "lineas": lineas,
        }

    def _build_vae_preview(self, db: Any, presupuesto: Any) -> Dict[str, Any]:
        project_total = float(presupuesto.total or 0)
        lineas = []
        project_vae_total = 0.0

        for line in self._sort_budget_lines_for_report(list(presupuesto.detalle or [])):
            vae_rubro = 0.0
            if line.apu:
                costo_directo = float(line.apu.costo_directo or 1)
                for linea_apu in sorted(line.apu.lineas, key=lambda item: ((item.orden or 0), item.id or 0)):
                    subtotal = float(linea_apu.subtotal or 0)
                    cpc_porc = 0.0
                    if linea_apu.recurso and linea_apu.recurso.cpc:
                        cpc_porc = float(linea_apu.recurso.cpc.porcentaje or 0)
                    vae_rubro += (subtotal / costo_directo) * (cpc_porc / 100)
            peso_relativo = float(line.precio_total or 0) / project_total if project_total > 0 else 0
            vae_ponderado = vae_rubro * peso_relativo
            project_vae_total += vae_ponderado
            lineas.append({
                "codigo": str(self._resolve_budget_line_report_item(line) or ""),
                "descripcion": self._normalize_report_description(line.descripcion),
                "unidad": line.unidad or "",
                "cantidad": float(line.cantidad or 0),
                "precio": float(line.precio_unitario or 0),
                "rendimiento": float(round_decimal(vae_rubro, 4)),
                "subtotal": float(round_decimal(vae_ponderado, 4)),
                "cantidad_kind": "calc",
                "precio_kind": "money",
                "rendimiento_kind": "calc",
                "subtotal_kind": "calc",
            })

        return {
            "id": presupuesto.id,
            "codigo": presupuesto.codigo or f"VAE-{presupuesto.id}",
            "descripcion": self._normalize_report_description(f"{presupuesto.descripcion} · VAE"),
            "unidad": "VAE",
            "costo_directo": project_total,
            "costo_indirecto": 0,
            "precio_total": project_vae_total,
            "summary_direct_kind": "money",
            "summary_indirect_kind": "money",
            "summary_total_kind": "calc",
            "lineas": lineas,
        }

    def _build_polinomica_preview(self, presupuesto: Any, formula: Any) -> Dict[str, Any]:
        base_calculo = float((presupuesto.subtotal or 0) + (presupuesto.indirectos_total or 0))
        lineas = [{
            "codigo": m.simbolo,
            "descripcion": self._normalize_report_description(m.descripcion or m.indice_inec.descripcion if m.indice_inec else ""),
            "unidad": m.indice_inec.codigo if m.indice_inec else "",
            "cantidad": float(m.coeficiente or 0),
            "precio": base_calculo,
            "rendimiento": "",
            "subtotal": float(m.coeficiente or 0) * base_calculo,
            "cantidad_kind": "calc",
            "precio_kind": "money",
            "rendimiento_kind": "calc",
            "subtotal_kind": "money",
        } for m in sorted(formula.monomios, key=lambda x: x.simbolo)]

        return {
            "id": presupuesto.id,
            "codigo": presupuesto.codigo or f"POL-{presupuesto.id}",
            "descripcion": self._normalize_report_description(f"{presupuesto.descripcion} · Fórmula Polinómica"),
            "unidad": "Polinómica",
            "costo_directo": float(presupuesto.subtotal or 0),
            "costo_indirecto": float(presupuesto.indirectos_total or 0),
            "precio_total": base_calculo,
            "summary_direct_kind": "money",
            "summary_indirect_kind": "money",
            "summary_total_kind": "money",
            "lineas": lineas,
        }

    def generate_apu_report(self, db: Any, apu_id: int, empresa_id: int, template_id: str = "001") -> io.BytesIO:
        apu = self._get_apu(db, apu_id, empresa_id)
        format_config = self._get_empresa_format_config(db, empresa_id)
        use_omniclass = self._resolve_use_omniclass(format_config, template_id)
        template_data = self._build_apu_template_data(apu, format_config["money_decimals"])
        template_metadata = self._get_apu_template_metadata(template_id)
        filename = self._resolve_apu_template_filename(template_id)
        template_path = os.path.join(self.templates_dir, filename)
        if not os.path.exists(template_path):
            raise FileNotFoundError(f"Plantilla no encontrada: {template_path}")
        wb = openpyxl.load_workbook(template_path)
        ws = wb.active
        ws.title = self._sanitize_sheet_title(apu.codigo, "APU")
        self._apply_apu_category_template_with_metadata(
            ws,
            apu,
            template_data,
            template_metadata,
            format_config["money_decimals"],
            format_config["calc_decimals"],
            use_omniclass,
        )
        self._apply_omniclass_visibility(ws, use_omniclass)
        return self._save_workbook_buffer(wb)

    def generate_apu_report_bundle(self, db: Any, apu_ids: List[int], empresa_id: int, template_id: str = "001") -> io.BytesIO:
        if not apu_ids:
            raise ValueError("No se recibieron APUs para exportar.")
        format_config = self._get_empresa_format_config(db, empresa_id)
        use_omniclass = self._resolve_use_omniclass(format_config, template_id)
        apus_map = self._get_apus_map(db, apu_ids, empresa_id)
        template_metadata = self._get_apu_template_metadata(template_id)

        filename = self._resolve_apu_template_filename(template_id)
        template_path = os.path.join(self.templates_dir, filename)
        if not os.path.exists(template_path):
            raise FileNotFoundError(f"Plantilla no encontrada: {template_path}")

        wb = openpyxl.load_workbook(template_path)
        template_ws = wb.active
        generated_sheets = []

        for idx, apu_id in enumerate(apu_ids, start=1):
            apu = apus_map.get(apu_id)
            if not apu:
                raise ValueError(f"APU no encontrado: {apu_id}")
            template_data = self._build_apu_template_data(apu, format_config["money_decimals"])
            ws = wb.copy_worksheet(template_ws)
            ws.title = self._sanitize_sheet_title(apu.codigo, f"APU {idx}")
            self._apply_apu_category_template_with_metadata(
                ws,
                apu,
                template_data,
                template_metadata,
                format_config["money_decimals"],
                format_config["calc_decimals"],
                use_omniclass,
            )
            self._apply_omniclass_visibility(ws, use_omniclass)
            generated_sheets.append(ws)

        wb.remove(template_ws)
        if generated_sheets:
            wb.active = 0

        if not use_omniclass:
            for ws in wb.worksheets:
                self._apply_omniclass_visibility(ws, False)

        return self._save_workbook_buffer(wb)

    def generate_presupuesto_report_bundle(self, db: Any, presupuesto_id: int, empresa_id: int, template_id: str = "001") -> io.BytesIO:
        presupuesto = self._get_presupuesto(db, presupuesto_id, empresa_id)
        presupuesto_buffer = self._generate_presupuesto_report_from_entity(db, presupuesto, empresa_id, template_id)
        wb = openpyxl.load_workbook(presupuesto_buffer)

        apus_map = self._get_presupuesto_apus_map(db, presupuesto, empresa_id)
        apu_ids = list(apus_map.keys())
        if not apu_ids:
            return self._save_workbook_buffer(wb)

        format_config = self._get_empresa_format_config(db, empresa_id)
        use_omniclass = self._resolve_use_omniclass(format_config, template_id)
        cache_key = self._build_presupuesto_bundle_cache_key(
            presupuesto,
            empresa_id,
            template_id,
            use_omniclass,
            apus_map,
        )
        cached_payload = self._get_cached_bytes(self._workbook_bytes_cache, cache_key)
        if cached_payload is not None:
            return self._buffer_from_cached_bytes(cached_payload)
        template_metadata = self._get_apu_template_metadata(template_id)
        apu_template_filename = self._resolve_apu_template_filename(template_id)
        apu_template_path = os.path.join(self.templates_dir, apu_template_filename)
        if not os.path.exists(apu_template_path):
            raise FileNotFoundError(f"Plantilla no encontrada: {apu_template_path}")

        apu_template_wb = openpyxl.load_workbook(apu_template_path)
        apu_template_ws = apu_template_wb.active
        seed_ws = wb.create_sheet(title="_apu_seed_template")
        self._clone_sheet(apu_template_ws, seed_ws)

        for idx, apu_id in enumerate(apu_ids, start=1):
            apu = apus_map.get(apu_id)
            if not apu:
                raise ValueError(f"APU no encontrado: {apu_id}")
            template_data = self._build_apu_template_data(apu, format_config["money_decimals"])
            ws = wb.copy_worksheet(seed_ws)
            ws.title = self._sanitize_sheet_title(apu.codigo, f"APU {idx}")
            self._apply_apu_category_template_with_metadata(
                ws,
                apu,
                template_data,
                template_metadata,
                format_config["money_decimals"],
                format_config["calc_decimals"],
                use_omniclass,
            )
            self._apply_omniclass_visibility(ws, use_omniclass)

        wb.remove(seed_ws)

        if not use_omniclass:
            for ws in wb.worksheets:
                self._apply_omniclass_visibility(ws, False)

        output = self._save_workbook_buffer(wb)
        self._set_cached_bytes(
            self._workbook_bytes_cache,
            cache_key,
            output.getvalue(),
            self._workbook_bytes_cache_limit,
        )
        output.seek(0)
        return output

    def preview_report(self, db: Any, report_type: str, entity_ids: List[int], empresa_id: int, template_id: str = "001", variant: Optional[str] = None) -> Dict[str, Any]:
        items = []
        title = "Reporte"

        if report_type == "apu":
            title = "Reporte de APUs"
            format_config = self._get_empresa_format_config(db, empresa_id)
            use_omniclass = self._resolve_use_omniclass(format_config, template_id)
            apus_map = self._get_apus_map(db, entity_ids, empresa_id)
            for apu_id in entity_ids:
                apu = apus_map.get(apu_id)
                if not apu:
                    raise ValueError(f"APU no encontrado: {apu_id}")
                items.append(
                    self._build_apu_report_payload(
                        apu,
                        format_config["money_decimals"],
                        format_config["calc_decimals"],
                        use_omniclass,
                    )["preview"]
                )
        elif report_type == "presupuesto":
            title = "Reporte de Presupuesto"
            presupuesto = self._get_presupuesto(db, entity_ids[0], empresa_id)
            items.append(self._build_presupuesto_preview(presupuesto))
            if variant == "with_apus":
                title = "Reporte de Presupuesto + APUs"
                format_config = self._get_empresa_format_config(db, empresa_id)
                use_omniclass = self._resolve_use_omniclass(format_config, template_id)
                apus_map = self._get_presupuesto_apus_map(db, presupuesto, empresa_id)
                for apu_id in self._get_presupuesto_distinct_apu_ids(presupuesto):
                    apu = apus_map.get(apu_id)
                    if not apu:
                        raise ValueError(f"APU no encontrado: {apu_id}")
                    items.append(
                        self._build_apu_report_payload(
                            apu,
                            format_config["money_decimals"],
                            format_config["calc_decimals"],
                            use_omniclass,
                        )["preview"]
                    )
        elif report_type == "cronograma_valorado":
            report_variant = str(variant or "valorado").lower()
            if report_variant in {"cash_flow", "flujo_caja", "caja"}:
                title = "Reporte de Flujo de Caja"
                items.append(self._build_cronograma_cash_flow_preview(db, entity_ids[0], empresa_id))
            elif report_variant == "pareto":
                title = "Reporte de Pareto Temporal"
                items.append(self._build_cronograma_pareto_preview(db, entity_ids[0], empresa_id))
            elif report_variant == "gantt":
                title = "Reporte de Cronograma Gantt"
                items.append(self._build_cronograma_gantt_preview(db, entity_ids[0], empresa_id))
            elif report_variant == "integrado":
                title = "Reporte Integrado Gantt / Valorado / Caja"
                items.append(self._build_cronograma_gantt_preview(db, entity_ids[0], empresa_id))
                items.append(self._build_cronograma_valorado_preview(db, entity_ids[0], empresa_id))
                items.append(self._build_cronograma_cash_flow_preview(db, entity_ids[0], empresa_id))
            else:
                title = "Reporte de Cronograma Valorado"
                items.append(self._build_cronograma_valorado_preview(db, entity_ids[0], empresa_id))
        elif report_type == "edt":
            report_variant = variant or "listado"
            title = f"Reporte EDT · {report_variant}"
            items.append(self._build_edt_preview(db, entity_ids[0], empresa_id, report_variant))
        elif report_type == "vae":
            title = "Reporte VAE"
            presupuesto = self._get_presupuesto(db, entity_ids[0], empresa_id)
            items.append(self._build_vae_preview(db, presupuesto))
        elif report_type == "polinomica":
            title = "Reporte Fórmula Polinómica"
            presupuesto = self._get_presupuesto(db, entity_ids[0], empresa_id)
            formula = self._get_formula(db, presupuesto.id)
            items.append(self._build_polinomica_preview(presupuesto, formula))
        elif report_type == "acta_constitucion":
            from app.models.proyecto import Proyecto

            title = "Acta de Constitución del Proyecto"
            proyecto = (
                db.query(Proyecto)
                .filter(Proyecto.id == entity_ids[0], Proyecto.empresa_id == empresa_id)
                .first()
            )
            if not proyecto:
                raise ValueError(f"Proyecto no encontrado: {entity_ids[0]}")
            items.append(self._build_acta_constitucion_preview(db, proyecto, empresa_id))
        elif report_type == "stakeholders":
            from app.models.proyecto import Proyecto

            title = "Equipo del Proyecto (Stakeholders)"
            proyecto = (
                db.query(Proyecto)
                .filter(Proyecto.id == entity_ids[0], Proyecto.empresa_id == empresa_id)
                .first()
            )
            if not proyecto:
                raise ValueError(f"Proyecto no encontrado: {entity_ids[0]}")
            items.append(self._build_stakeholders_preview(db, proyecto, empresa_id))
        else:
            raise ValueError(f"Vista previa no soportada para: {report_type}")

        return {
            "report_type": report_type,
            "template_id": template_id,
            "variant": variant,
            "title": title,
            "selection_count": len(items),
            "items": items,
        }

    def generate_preview_pdf(self, db: Any, report_type: str, entity_ids: List[int], empresa_id: int, template_id: str = "001", variant: Optional[str] = None) -> io.BytesIO:
        preview = self.preview_report(db, report_type, entity_ids, empresa_id, template_id, variant)
        format_config = self._get_empresa_format_config(db, empresa_id)
        return self._build_pdf_report(
            preview.get("title") or "Reporte",
            preview.get("items") or [],
            format_config["money_decimals"],
            format_config["calc_decimals"],
        )

    def generate_edt_report(self, db: Any, proyecto_id: int, empresa_id: int, report_type: str = "listado") -> io.BytesIO:
        """
        Genera reportes de EDT: listado, diccionario o valorada.
        """
        from app.models.edt import EDT
        from app.models.proyecto import Proyecto
        
        proyecto = db.query(Proyecto).filter(Proyecto.id == proyecto_id, Proyecto.empresa_id == empresa_id).first()
        if not proyecto:
            raise ValueError("Proyecto no encontrado")

        # Determinar plantilla y datos
        filename = ""
        table_row_marker = "#DESCRIPCION"
        
        if report_type == "listado":
            filename = "001 - EDT - listado.xlsx"
        elif report_type == "diccionario":
            filename = "001 - EDT - Diccionario.xlsx"
        elif report_type == "valorada":
            filename = "001 - EDT - Valorada.xlsx"
        else:
            raise ValueError(f"Tipo de reporte EDT no válido: {report_type}")

        format_config = self._get_empresa_format_config(db, empresa_id)

        data = {
            "#PRO_TITULO": self._resolve_project_title(proyecto),
            "#CODIGOPROYECTO": proyecto.codigo or "",
            "#PRO_OFERENTE": proyecto.empresa.nombre if proyecto.empresa else "",
            "#PRO_UBICACION": self._get_project_location(db, proyecto, empresa_id),
            "#PRO_FECHA": proyecto.fecha_creacion.strftime("%d/%m/%Y") if proyecto.fecha_creacion else ""
        }

        # Obtener nodos EDT
        nodos = db.query(EDT).filter(EDT.proyecto_id == proyecto_id).order_by(EDT.codigo_completo).all()
        
        table_data = []
        for nodo in nodos:
            row = {
                "CODEDT": nodo.codigo_completo,
                "DESCRIPCION": self._normalize_report_description(nodo.descripcion),
                "NIVEL": nodo.nivel,
                "TIPO": nodo.tipo_nodo,
                "RESPONSABLE": nodo.responsable or "",
                "FECHA_INICIO": nodo.fecha_inicio.strftime("%d/%m/%Y") if nodo.fecha_inicio else "",
                "FECHA_FIN": nodo.fecha_fin.strftime("%d/%m/%Y") if nodo.fecha_fin else "",
                "PRESUPUESTO": float(nodo.presupuesto_asignado or 0)
            }
            # Para el diccionario, podemos tener campos adicionales
            if report_type == "diccionario":
                row["ENTREGABLES"] = nodo.entregables or ""
                row["CRITERIOS"] = nodo.criterios_aceptacion or ""
            
            table_data.append(row)

        if report_type == "valorada":
            for row in table_data:
                row["SUBTOTAL_CUENTA"] = row.get("PRESUPUESTO", 0)
            data["#TEXTOTOTAL"] = ""

        formatted_data = self._format_excel_data(
            data,
            {
                "#SUBTOTAL_CUENTA": "money",
            },
            format_config["money_decimals"],
            format_config["calc_decimals"],
        )
        formatted_rows = self._format_excel_rows(
            table_data,
            {
                "NIVEL": "calc",
                "PRESUPUESTO": "money",
                "SUBTOTAL_CUENTA": "money",
            },
            format_config["money_decimals"],
            format_config["calc_decimals"],
        )

        return self.fill_template(
            filename,
            formatted_data,
            formatted_rows,
            table_row_marker=table_row_marker,
            use_omniclass=format_config["use_omniclass"],
        )

    def _generate_presupuesto_report_from_entity(self, db: Any, presupuesto: Any, empresa_id: int, template_id: str = "001") -> io.BytesIO:
        # 001 - Presupuesto.xlsx
        filename = "001 - Presupuesto.xlsx"
        if template_id == "002":
            filename = "002 - Presupuesto - SERCOP.xlsx"

        format_config = self._get_empresa_format_config(db, empresa_id)
        use_omniclass = self._resolve_use_omniclass(format_config, template_id)
        reference_code = self._get_project_reference_code(db, presupuesto)

        subtotal_presupuesto = float(presupuesto.subtotal or 0)
        iva_porcentaje = float(presupuesto.iva_aplicado or 0)
        iva_reporte = subtotal_presupuesto * (iva_porcentaje / 100.0)
        total_reporte = subtotal_presupuesto + iva_reporte

        data = {
            "#PRO_TITULO": self._resolve_project_title(presupuesto.proyecto, presupuesto.descripcion),
            "#CODIGOPROYECTO": presupuesto.proyecto.codigo if presupuesto.proyecto else "",
            "#CODIGOREFERENCIAL": reference_code,
            "#REVISION": self._format_revision_label(presupuesto.revision),
            "#PRO_OFERENTE": presupuesto.empresa.nombre if presupuesto.empresa else "",
            "#PRO_UBICACION": self._get_project_location(db, presupuesto.proyecto, empresa_id),
            "#PRO_FECHA": presupuesto.fecha_creacion.strftime("%d/%m/%Y") if presupuesto.fecha_creacion else "",
            "#%IVA": f"{self._format_fixed(float(presupuesto.iva_aplicado or 0), format_config['money_decimals'])}%",
            "#SUBTOTALSINIVA": subtotal_presupuesto,
            "#IVA": iva_reporte,
            "#TTOTAL": total_reporte,
            "#TEXTOTOTAL": self._money_to_words_body_es(total_reporte)
        }

        table_data = self._build_presupuesto_table_data(presupuesto, template_id)

        formatted_data = self._format_excel_data(
            data,
            {
                "#SUBTOTALSINIVA": "money",
                "#IVA": "money",
                "#TTOTAL": "money",
            },
            format_config["money_decimals"],
            format_config["calc_decimals"],
        )
        formatted_rows = self._format_excel_rows(
            table_data,
            {
                "CANTIDAD": "calc",
                "PUNITARIO": "money",
                "SUBTOTAL": "money",
            },
            format_config["money_decimals"],
            format_config["calc_decimals"],
        )
        output = self.fill_template(
            filename,
            formatted_data,
            formatted_rows,
            table_row_marker="#DESCRIPCION",
            use_omniclass=use_omniclass,
        )
        output.seek(0)
        wb = openpyxl.load_workbook(output)
        ws = wb.active
        self._apply_presupuesto_row_typography(ws, table_data, template_id)
        if not use_omniclass:
            for current_ws in wb.worksheets:
                self._apply_omniclass_visibility(current_ws, False)
        return self._save_workbook_buffer(wb)

    def generate_presupuesto_report(self, db: Any, presupuesto_id: int, empresa_id: int, template_id: str = "001") -> io.BytesIO:
        presupuesto = self._get_presupuesto(db, presupuesto_id, empresa_id)
        return self._generate_presupuesto_report_from_entity(db, presupuesto, empresa_id, template_id)

    def _get_cronograma_valorado_payload(self, db: Any, presupuesto_id: int, empresa_id: int) -> Tuple[Any, Any]:
        from app.api.endpoints.cronogramas import _get_or_create_cronograma, _serialize_cronograma

        presupuesto = self._get_presupuesto(db, presupuesto_id, empresa_id)
        cronograma = _get_or_create_cronograma(db, presupuesto)
        return presupuesto, _serialize_cronograma(db, presupuesto, cronograma)

    def _format_cronograma_period_values(self, values: List[Any], decimals: int = 2, suffix: str = "") -> str:
        return " | ".join(f"{self._format_fixed(value, decimals)}{suffix}" for value in values)

    def _summarize_cronograma_manual_schedule_pending(self, cronograma: Any) -> Dict[str, Any]:
        rows = list(getattr(cronograma, "rows", []) or [])
        pending_rows = [row for row in rows if bool(getattr(row, "requires_manual_schedule", False))]
        pending_amount = sum(float(getattr(row, "precio_total", 0) or 0) for row in pending_rows)
        total_amount = sum(float(getattr(row, "precio_total", 0) or 0) for row in rows)
        scheduled_amount = max(0.0, total_amount - pending_amount)
        pending_pct = (pending_amount / total_amount * 100.0) if total_amount > 0 else 0.0
        scheduled_pct = (scheduled_amount / total_amount * 100.0) if total_amount > 0 else 0.0
        return {
            "count": len(pending_rows),
            "pending_amount": pending_amount,
            "scheduled_amount": scheduled_amount,
            "total_amount": total_amount,
            "pending_pct": round(pending_pct, 4),
            "scheduled_pct": round(scheduled_pct, 4),
            "has_pending": bool(pending_rows),
        }

    def _summarize_gantt_operational_reporting(self, schedule: Any, cronograma: Any = None) -> Dict[str, Any]:
        rows = list(getattr(schedule, "rows", []) or [])
        valuado_rows = {
            str(getattr(row, "linea_id", "") or "").strip(): row
            for row in list(getattr(cronograma, "rows", []) or [])
            if str(getattr(row, "linea_id", "") or "").strip()
        }
        valuado_periods = list(getattr(cronograma, "periods", []) or [])
        subbar_rows = 0
        subbar_count = 0
        draft_subbar_count = 0
        manual_temporal_rows = 0
        interparent_merge_rows = 0
        interparent_merge_count = 0
        conflict_rows = 0
        conflict_periods = 0

        for row in rows:
            metadata = dict(getattr(row, "metadata", None) or {})
            operational = dict(metadata.get("gantt_operational") or {})
            raw_subbars = list(metadata.get("gantt_subbars") or [])
            budget_line_id = str(
                getattr(row, "presupuesto_linea_id", None)
                or getattr(row, "linea_id", None)
                or getattr(row, "budget_line_id", None)
                or operational.get("budget_line_id")
                or ""
            ).strip()
            if operational.get("has_subbars"):
                subbar_rows += 1
            subbar_count += int(operational.get("subbar_count") or 0)
            draft_subbar_count += sum(
                1 for segment in raw_subbars
                if str(segment.get("status", "") or "").strip().lower() == "draft_session"
            )
            row_interparent_merge_count = sum(
                1 for segment in raw_subbars
                if str(segment.get("source", "") or "").strip().lower() == "gantt_interparent_merge"
            )
            interparent_merge_count += row_interparent_merge_count
            if row_interparent_merge_count > 0:
                interparent_merge_rows += 1
            if operational.get("has_manual_temporal_window"):
                manual_temporal_rows += 1

            valuado_row = valuado_rows.get(budget_line_id)
            if not valuado_row or not raw_subbars or not valuado_periods:
                continue

            distribution = list(getattr(valuado_row, "distribution", []) or [])
            line_total = float(getattr(valuado_row, "precio_total", 0) or 0)
            period_buckets: Dict[str, Dict[str, float]] = {}
            for segment in raw_subbars:
                period_id = str(segment.get("period_id") or segment.get("parent_period_id") or "").strip()
                if not period_id:
                    continue
                current = period_buckets.get(period_id) or {"actual_percent": 0.0, "actual_amount": 0.0}
                current["actual_percent"] += float(segment.get("percent") or 0)
                current["actual_amount"] += float(segment.get("amount") or 0)
                period_buckets[period_id] = current

            row_conflicts = 0
            for index, period in enumerate(valuado_periods):
                period_id = str(getattr(period, "id", None) or f"P{index + 1}")
                actual = period_buckets.get(period_id) or {"actual_percent": 0.0, "actual_amount": 0.0}
                allowed_percent = float(distribution[index] or 0) if index < len(distribution) else 0.0
                allowed_amount = float(line_total * (allowed_percent / 100.0)) if line_total > 0 else 0.0
                if actual["actual_percent"] - allowed_percent > 0.0001 or actual["actual_amount"] - allowed_amount > 0.01:
                    row_conflicts += 1
            if row_conflicts > 0:
                conflict_rows += 1
                conflict_periods += row_conflicts

        has_operational_state = bool(subbar_rows or manual_temporal_rows or draft_subbar_count or conflict_rows)

        return {
            "subbar_rows": subbar_rows,
            "subbar_count": subbar_count,
            "draft_subbar_count": draft_subbar_count,
            "manual_temporal_rows": manual_temporal_rows,
            "interparent_merge_rows": interparent_merge_rows,
            "interparent_merge_count": interparent_merge_count,
            "conflict_rows": conflict_rows,
            "conflict_periods": conflict_periods,
            "has_operational_state": has_operational_state,
        }

    def _build_cronograma_valorado_preview(self, db: Any, presupuesto_id: int, empresa_id: int) -> Dict[str, Any]:
        presupuesto, cronograma = self._get_cronograma_valorado_payload(db, presupuesto_id, empresa_id)
        pending_summary = self._summarize_cronograma_manual_schedule_pending(cronograma)
        budget_lines_by_id = {
            int(getattr(line, "id", 0)): line
            for line in list(presupuesto.detalle or [])
            if getattr(line, "id", None) is not None
        }
        period_columns = [
            { "key": f"periodo_{index}", "label": period.label, "kind": "money" }
            for index, period in enumerate(cronograma.periods)
        ]
        lineas = []
        for row in cronograma.rows:
            source_line = budget_lines_by_id.get(int(getattr(row, "linea_id", 0) or 0))
            line = {
                "item_visible": str(getattr(row, "codigo_item", None) or "").strip(),
                "edt_code_visible": self._get_budget_line_visible_edt_code(source_line) if source_line else "",
                "descripcion": self._normalize_report_description(row.descripcion),
                "unidad": row.unidad or "",
                "cantidad": row.cantidad,
                "precio_unitario": row.precio_unitario,
                "precio_total": row.precio_total,
            }
            for index, pct in enumerate(row.distribution):
                line[f"periodo_{index}"] = row.precio_total * (pct / 100)
            lineas.append(line)

        return {
            "id": presupuesto.id,
            "codigo": getattr(presupuesto.proyecto, "codigo", None) or getattr(presupuesto.proyecto, "codigo_root", None) or "",
            "descripcion": self._resolve_project_title(presupuesto.proyecto, presupuesto.descripcion),
            "unidad": cronograma.moneda,
            "metadata_hint": (
                f"Cronograma valorado · {cronograma.period_type} · {len(cronograma.periods)} periodo(s)"
                + (" · temporalidad parcial" if pending_summary["has_pending"] else "")
            ),
            "summary_cards": [
                { "label": "Presupuesto", "value": sum(row.precio_total for row in cronograma.rows), "kind": "money", "tone": "total" },
                { "label": "Periodos", "value": len(cronograma.periods), "kind": "calc" },
                { "label": "Modo", "value": cronograma.distribution_mode, "kind": "raw" },
                *([
                    { "label": "Pendiente manual", "value": pending_summary["pending_amount"], "kind": "money" },
                    { "label": "Cobertura valorada", "value": pending_summary["scheduled_pct"], "kind": "calc" },
                ] if pending_summary["has_pending"] else []),
            ],
            "table_columns": [
                { "key": "item_visible", "label": "Item" },
                { "key": "edt_code_visible", "label": "Cod EDT" },
                { "key": "descripcion", "label": "Descripción" },
                { "key": "unidad", "label": "Unid." },
                { "key": "cantidad", "label": "Cant.", "kind": "calc" },
                { "key": "precio_unitario", "label": "P. Unit.", "kind": "money" },
                { "key": "precio_total", "label": "Subtotal", "kind": "money" },
                *period_columns,
            ],
            "lineas": lineas,
        }

    def _build_cronograma_cash_flow_preview(self, db: Any, presupuesto_id: int, empresa_id: int) -> Dict[str, Any]:
        presupuesto, cronograma = self._get_cronograma_valorado_payload(db, presupuesto_id, empresa_id)
        pending_summary = self._summarize_cronograma_manual_schedule_pending(cronograma)
        lineas = [
            {
                "periodo": point.label,
                "fecha_inicio": point.starts_at.strftime("%d/%m/%Y %H:%M"),
                "fecha_fin": point.ends_at.strftime("%d/%m/%Y %H:%M"),
                "horas_periodo": point.work_hours,
                "costo_periodo": point.cost,
                "equipos": (point.category_costs or {}).get("Equipos", 0),
                "mano_obra": (point.category_costs or {}).get("Mano de obra", 0),
                "transporte": (point.category_costs or {}).get("Transporte", 0),
                "categoria_dominante": point.dominant_category or "",
                "costo_acumulado": point.cumulative_cost,
                "porcentaje_periodo": point.cost_pct,
                "porcentaje_acumulado": point.cumulative_pct,
            }
            for point in cronograma.cash_flow
        ]

        return {
            "id": presupuesto.id,
            "codigo": getattr(presupuesto.proyecto, "codigo", None) or getattr(presupuesto.proyecto, "codigo_root", None) or "",
            "descripcion": self._resolve_project_title(presupuesto.proyecto, presupuesto.descripcion),
            "unidad": cronograma.moneda,
            "metadata_hint": (
                f"Flujo de caja · {cronograma.period_type} · {len(cronograma.cash_flow)} periodo(s)"
                + (" · cobertura parcial" if pending_summary["has_pending"] else "")
            ),
            "summary_cards": [
                { "label": "Costo total", "value": cronograma.cash_flow[-1].cumulative_cost if cronograma.cash_flow else 0, "kind": "money", "tone": "total" },
                { "label": "Periodos", "value": len(cronograma.cash_flow), "kind": "calc" },
                { "label": "Horas efectivas", "value": sum(float(point.work_hours or 0) for point in cronograma.cash_flow), "kind": "calc" },
                { "label": "Categoría líder", "value": max(
                    (
                        (
                            label,
                            sum(float((point.category_costs or {}).get(label, 0) or 0) for point in cronograma.cash_flow)
                        )
                        for label in {"Equipos", "Mano de obra", "Transporte"}
                    ),
                    key=lambda item: item[1],
                    default=("Sin categoría", 0),
                )[0], "kind": "raw" },
                { "label": "Origen", "value": "Gantt parcial" if cronograma.distribution_mode == "gantt" and pending_summary["has_pending"] else ("Gantt" if cronograma.distribution_mode == "gantt" else "Valorado"), "kind": "raw" },
                *([
                    { "label": "Pendiente manual", "value": pending_summary["pending_amount"], "kind": "money" },
                    { "label": "Cobertura valorada", "value": pending_summary["scheduled_pct"], "kind": "calc" },
                ] if pending_summary["has_pending"] else []),
            ],
            "table_columns": [
                { "key": "periodo", "label": "Periodo" },
                { "key": "fecha_inicio", "label": "Inicio" },
                { "key": "fecha_fin", "label": "Fin" },
                { "key": "horas_periodo", "label": "Horas", "kind": "calc" },
                { "key": "costo_periodo", "label": "Costo", "kind": "money" },
                { "key": "equipos", "label": "Equipos", "kind": "money" },
                { "key": "mano_obra", "label": "Mano de obra", "kind": "money" },
                { "key": "transporte", "label": "Transporte", "kind": "money" },
                { "key": "categoria_dominante", "label": "Dominante" },
                { "key": "costo_acumulado", "label": "Costo acum.", "kind": "money" },
                { "key": "porcentaje_periodo", "label": "% periodo", "kind": "calc" },
                { "key": "porcentaje_acumulado", "label": "% acum.", "kind": "calc" },
            ],
            "lineas": lineas,
        }

    def _build_cronograma_gantt_preview(self, db: Any, presupuesto_id: int, empresa_id: int) -> Dict[str, Any]:
        from app.services.cronograma_trabajo import cronograma_trabajo_service

        presupuesto = self._get_presupuesto(db, presupuesto_id, empresa_id)
        schedule = cronograma_trabajo_service.get_schedule(
            db,
            presupuesto_id=presupuesto.id,
            proyecto_id=presupuesto.proyecto_id,
            empresa_id=empresa_id,
        )
        _, cronograma = self._get_cronograma_valorado_payload(db, presupuesto_id, empresa_id)
        operational_summary = self._summarize_gantt_operational_reporting(schedule, cronograma)
        budget_lines_by_id = {
            int(getattr(line, "id", 0)): line
            for line in list(presupuesto.detalle or [])
            if getattr(line, "id", None) is not None
        }
        lineas = []
        for row in schedule.rows or []:
            dependencies = getattr(row, "dependencies", []) or []
            dependency_labels = [
                f"{dependency.source_id}:{dependency.type}{'+' if dependency.lag_days and dependency.lag_days > 0 else ''}{dependency.lag_days or 0:g}d"
                for dependency in dependencies
            ]
            source_line = budget_lines_by_id.get(int(getattr(row, "presupuesto_linea_id", 0) or 0))
            lineas.append({
                "item_visible": str(getattr(row, "codigo_item", None) or "").strip(),
                "edt_code_visible": self._get_budget_line_visible_edt_code(source_line) if source_line else "",
                "descripcion": self._normalize_report_description(row.descripcion),
                "inicio": row.start_date.strftime("%d/%m/%Y") if row.start_date else "",
                "fin": row.end_date.strftime("%d/%m/%Y") if row.end_date else "",
                "duracion": row.dias_calendario or row.dias_utiles or 0,
                "avance": row.progress_pct or 0,
                "predecesoras": ", ".join(str(item) for item in (row.predecessors or [])),
                "dependencias": " | ".join(dependency_labels),
            })

        return {
            "id": presupuesto.id,
            "codigo": getattr(presupuesto.proyecto, "codigo", None) or getattr(presupuesto.proyecto, "codigo_root", None) or "",
            "descripcion": self._resolve_project_title(presupuesto.proyecto, presupuesto.descripcion),
            "unidad": "días",
            "metadata_hint": (
                f"Gantt · {len(lineas)} tarea(s) · {schedule.config.dias_laborables_semana if schedule.config else 5:g} días laborables/semana"
                + (" · reconciliación operativa" if operational_summary["has_operational_state"] else "")
            ),
            "summary_cards": [
                { "label": "Tareas", "value": len(lineas), "kind": "calc" },
                { "label": "Trabajo útil", "value": schedule.summary.trabajo_total if schedule.summary else 0, "kind": "calc" },
                { "label": "Cuadrilla", "value": schedule.summary.cuadrilla_total if schedule.summary else 0, "kind": "calc" },
                *([
                    { "label": "Líneas con subbarras", "value": operational_summary["subbar_rows"], "kind": "calc" },
                    { "label": "Tramos operativos", "value": operational_summary["subbar_count"], "kind": "calc" },
                    { "label": "Tramos en borrador", "value": operational_summary["draft_subbar_count"], "kind": "calc" },
                    { "label": "Fusiones intertramo", "value": operational_summary["interparent_merge_count"], "kind": "calc" },
                    { "label": "Ventanas manuales", "value": operational_summary["manual_temporal_rows"], "kind": "calc" },
                    { "label": "Conflictos valorado", "value": operational_summary["conflict_periods"], "kind": "calc" },
                ] if operational_summary["has_operational_state"] else []),
            ],
            "table_columns": [
                { "key": "item_visible", "label": "Item" },
                { "key": "edt_code_visible", "label": "Cod EDT" },
                { "key": "descripcion", "label": "Descripción" },
                { "key": "inicio", "label": "Inicio" },
                { "key": "fin", "label": "Fin" },
                { "key": "duracion", "label": "Dur.", "kind": "calc" },
                { "key": "avance", "label": "% Av.", "kind": "calc" },
                { "key": "predecesoras", "label": "Predec." },
                { "key": "dependencias", "label": "Dependencias" },
            ],
            "lineas": lineas,
        }

    def _build_cronograma_pareto_preview(self, db: Any, presupuesto_id: int, empresa_id: int) -> Dict[str, Any]:
        from app.api.endpoints.cronogramas_trabajo import _build_cronograma_trabajo_pareto_response
        from app.services.cronograma_trabajo import cronograma_trabajo_service

        presupuesto = self._get_presupuesto(db, presupuesto_id, empresa_id)
        schedule = cronograma_trabajo_service.get_schedule(
            db,
            presupuesto_id=presupuesto.id,
            proyecto_id=presupuesto.proyecto_id,
            empresa_id=empresa_id,
        )
        price_map = {
            int(linea.id): float(linea.precio_total or 0.0)
            for linea in (presupuesto.detalle or [])
        }
        pareto = _build_cronograma_trabajo_pareto_response(
            presupuesto_id=presupuesto.id,
            rows=schedule.rows,
            price_map=price_map,
            view="integrated",
            top=20,
        )
        lineas = []
        for item in pareto.items:
            lineas.append({
                "ranking": item.ranking,
                "codigo": item.codigo or "",
                "descripcion": self._normalize_report_description(item.descripcion),
                "costo": item.cost_value,
                "duracion_dias": item.duration_days,
                "horas_efectivas": item.work_hours,
                "impacto": item.porcentaje,
                "impacto_acumulado": item.porcentaje_acumulado,
            })

        return {
            "id": presupuesto.id,
            "codigo": getattr(presupuesto.proyecto, "codigo", None) or getattr(presupuesto.proyecto, "codigo_root", None) or "",
            "descripcion": self._resolve_project_title(presupuesto.proyecto, presupuesto.descripcion),
            "unidad": presupuesto.moneda or "USD",
            "metadata_hint": f"Pareto temporal · {pareto.view} · top {pareto.visible_items}",
            "summary_cards": [
                {"label": "Items", "value": pareto.visible_items, "kind": "calc"},
                {"label": "Acumulado", "value": pareto.visible_acumulado, "kind": "calc"},
                {"label": "Modo", "value": "integrado", "kind": "raw"},
            ],
            "table_columns": [
                {"key": "ranking", "label": "Rank", "kind": "calc"},
                {"key": "codigo", "label": "Item"},
                {"key": "descripcion", "label": "Descripción"},
                {"key": "costo", "label": "Costo", "kind": "money"},
                {"key": "duracion_dias", "label": "Dur. días", "kind": "calc"},
                {"key": "horas_efectivas", "label": "Horas", "kind": "calc"},
                {"key": "impacto", "label": "% impacto", "kind": "calc"},
                {"key": "impacto_acumulado", "label": "% acum.", "kind": "calc"},
            ],
            "lineas": lineas,
        }

    def _build_simple_report_workbook(self, title: str, items: List[Dict[str, Any]], money_decimals: int, calc_decimals: int) -> io.BytesIO:
        wb = openpyxl.Workbook()
        default_ws = wb.active
        wb.remove(default_ws)
        for item_index, item in enumerate(items, start=1):
            sheet_title = (item.get("metadata_hint") or title or f"Reporte {item_index}").split("·")[0].strip()[:31] or f"Reporte {item_index}"
            ws = wb.create_sheet(sheet_title)
            ws.cell(row=1, column=1, value=title)
            ws.cell(row=1, column=1).font = Font(bold=True, size=14)
            ws.cell(row=2, column=1, value=item.get("descripcion") or "")
            ws.cell(row=3, column=1, value=item.get("metadata_hint") or "")
            start_row = 5
            columns = item.get("table_columns") or []
            for column_index, column in enumerate(columns, start=1):
                cell = ws.cell(row=start_row, column=column_index, value=column.get("label") or column.get("key"))
                cell.font = Font(bold=True)
                cell.alignment = Alignment(horizontal="center")
            for row_index, line in enumerate(item.get("lineas") or [], start=start_row + 1):
                for column_index, column in enumerate(columns, start=1):
                    value = line.get(column.get("key"))
                    kind = column.get("kind")
                    if kind == "money":
                        value = self._round_half_up(value, money_decimals)
                    elif kind == "calc":
                        value = self._round_half_up(value, calc_decimals)
                    ws.cell(row=row_index, column=column_index, value=value)
            for column_index, column in enumerate(columns, start=1):
                width = max(12, min(42, len(str(column.get("label") or column.get("key"))) + 6))
                ws.column_dimensions[get_column_letter(column_index)].width = width
            ws.freeze_panes = ws.cell(row=start_row + 1, column=1)
        wb.properties.title = title
        return self._save_workbook_buffer(wb)

    def generate_cronograma_valorado_report(self, db: Any, presupuesto_id: int, empresa_id: int, template_id: str = "001", variant: Optional[str] = None) -> io.BytesIO:
        report_variant = str(variant or "valorado").lower()
        if report_variant in {"cash_flow", "flujo_caja", "caja"}:
            format_config = self._get_empresa_format_config(db, empresa_id)
            return self._build_simple_report_workbook(
                "Flujo de Caja",
                [self._build_cronograma_cash_flow_preview(db, presupuesto_id, empresa_id)],
                format_config["money_decimals"],
                format_config["calc_decimals"],
            )
        if report_variant == "pareto":
            format_config = self._get_empresa_format_config(db, empresa_id)
            return self._build_simple_report_workbook(
                "Pareto Temporal",
                [self._build_cronograma_pareto_preview(db, presupuesto_id, empresa_id)],
                format_config["money_decimals"],
                format_config["calc_decimals"],
            )
        if report_variant == "gantt":
            format_config = self._get_empresa_format_config(db, empresa_id)
            return self._build_simple_report_workbook(
                "Cronograma Gantt",
                [self._build_cronograma_gantt_preview(db, presupuesto_id, empresa_id)],
                format_config["money_decimals"],
                format_config["calc_decimals"],
            )
        if report_variant == "integrado":
            format_config = self._get_empresa_format_config(db, empresa_id)
            return self._build_simple_report_workbook(
                "Cronograma Integrado",
                [
                    self._build_cronograma_gantt_preview(db, presupuesto_id, empresa_id),
                    self._build_cronograma_valorado_preview(db, presupuesto_id, empresa_id),
                    self._build_cronograma_cash_flow_preview(db, presupuesto_id, empresa_id),
                ],
                format_config["money_decimals"],
                format_config["calc_decimals"],
            )

        presupuesto, cronograma = self._get_cronograma_valorado_payload(db, presupuesto_id, empresa_id)
        filename = "002 - Cronograma Valorado SERCOP.xlsx" if template_id == "002" else "001 - Cronograma Valorado General.xlsx"
        format_config = self._get_empresa_format_config(db, empresa_id)
        reference_code = self._get_project_reference_code(db, presupuesto)
        total_presupuesto = sum(row.precio_total for row in cronograma.rows)
        period_labels = [period.label for period in cronograma.periods]

        data = {
            "#PRO_TITULO": self._resolve_project_title(presupuesto.proyecto, presupuesto.descripcion),
            "#CODIGOPROYECTO": presupuesto.proyecto.codigo if presupuesto.proyecto else "",
            "#CODIGOREFERENCIAL": reference_code,
            "#REVISION": self._format_revision_label(presupuesto.revision),
            "#PRO_OFERENTE": presupuesto.empresa.nombre if presupuesto.empresa else "",
            "#PRO_UBICACION": self._get_project_location(db, presupuesto.proyecto, empresa_id),
            "#PRO_FECHA_INICIO": cronograma.periods[0].starts_at.strftime("%d/%m/%Y") if cronograma.periods else "",
            "#PRO_FECHA_FIN": cronograma.periods[-1].ends_at.strftime("%d/%m/%Y") if cronograma.periods else "",
            "#PRO_PLAZO": len(cronograma.periods),
            "#PRO_TIPO_PERIODO": cronograma.period_type,
            "#PRO_NUM_PERIODO": " | ".join(period_labels),
            "#TOTAL_PRESUPUESTO": total_presupuesto,
            "#TOTAL_PARCIAL": self._format_cronograma_period_values(cronograma.footer.inversion_parcial, format_config["money_decimals"]),
            "#PORCENT_PARCIAL": self._format_cronograma_period_values(cronograma.footer.avance_parcial_pct, format_config["calc_decimals"], "%"),
            "#TOTAL_ACUM": self._format_cronograma_period_values(cronograma.footer.inversion_acumulada, format_config["money_decimals"]),
            "#PORCENT_ACUM": self._format_cronograma_period_values(cronograma.footer.avance_acumulado_pct, format_config["calc_decimals"], "%"),
            "#CIUDAD": self._get_project_location(db, presupuesto.proyecto, empresa_id),
            "#PRO_FECHA": date.today().strftime("%d/%m/%Y"),
        }

        table_data = []
        budget_lines_by_id = {
            int(getattr(line, "id", 0)): line
            for line in list(presupuesto.detalle or [])
            if getattr(line, "id", None) is not None
        }
        for index, row in enumerate(cronograma.rows, start=1):
            period_amounts = [row.precio_total * (pct / 100) for pct in row.distribution]
            source_line = budget_lines_by_id.get(int(getattr(row, "linea_id", 0) or 0))
            table_data.append({
                "ITEM": row.codigo_item or index,
                "ITEM_VISIBLE": str(getattr(row, "codigo_item", None) or "").strip(),
                "CODIGO_EDT": self._get_budget_line_visible_edt_code(source_line) if source_line else "",
                "CODIGO_APU": row.apu_id or "",
                "DESCRIPCION": self._normalize_report_description(row.descripcion),
                "UNIDAD": row.unidad or "",
                "CANTIDAD": row.cantidad,
                "PUNITARIO": row.precio_unitario,
                "SUBTOTAL": row.precio_total,
                "DATOPERIODO": self._format_cronograma_period_values(period_amounts, format_config["money_decimals"]),
                "DATOS_PERIODO": self._format_cronograma_period_values(period_amounts, format_config["money_decimals"]),
            })

        formatted_data = self._format_excel_data(
            data,
            {
                "#TOTAL_PRESUPUESTO": "money",
            },
            format_config["money_decimals"],
            format_config["calc_decimals"],
        )
        formatted_rows = self._format_excel_rows(
            table_data,
            {
                "CANTIDAD": "calc",
                "PUNITARIO": "money",
                "SUBTOTAL": "money",
            },
            format_config["money_decimals"],
            format_config["calc_decimals"],
        )
        return self.fill_template(
            filename,
            formatted_data,
            formatted_rows,
            table_row_marker="#DESCRIPCION",
            use_omniclass=False,
        )
    
    def generate_vae_report(self, db: Any, presupuesto_id: int, empresa_id: int, template_id: str = "001") -> io.BytesIO:
        from app.models.presupuesto import Presupuesto
        from app.models.recurso import Recurso
        from app.models.apu import APU
        
        presupuesto = db.query(Presupuesto).filter(Presupuesto.id == presupuesto_id, Presupuesto.empresa_id == empresa_id).first()
        if not presupuesto:
            raise ValueError("Presupuesto no encontrado")

        filename = "001 - VAE Proyecto - General.xlsx"
        if template_id == "002":
            filename = "002 - VAE Proyecto - SERCOP.xlsx"

        format_config = self._get_empresa_format_config(db, empresa_id)
        use_omniclass = self._resolve_use_omniclass(format_config, template_id)
        reference_code = self._get_project_reference_code(db, presupuesto)

        project_total = float(presupuesto.total or 0)
        
        data = {
            "#PRO_TITULO": self._resolve_project_title(presupuesto.proyecto, presupuesto.descripcion),
            "#CODIGOPROYECTO": presupuesto.proyecto.codigo if presupuesto.proyecto else "",
            "#CODIGOREFERENCIAL": reference_code,
            "#REVISION": self._format_revision_label(presupuesto.revision),
            "#PRO_FECHA": presupuesto.fecha_creacion.strftime("%d/%m/%Y") if presupuesto.fecha_creacion else "",
            "#%IVA": f"{self._format_fixed(float(presupuesto.iva_aplicado or 0), format_config['money_decimals'])}%",
            "#IVA": float(presupuesto.impuestos or 0),
            "#TTOTAL": project_total
        }

        table_data = []
        project_vae_total = 0.0
        
        for line in self._sort_budget_lines_for_report(list(presupuesto.detalle or [])):
            vae_rubro = 0.0
            if line.apu:
                costo_directo = float(line.apu.costo_directo or 1)
                for linea_apu in sorted(line.apu.lineas, key=lambda item: ((item.orden or 0), item.id or 0)):
                    subtotal = float(linea_apu.subtotal or 0)
                    cpc_porc = 0.0
                    if linea_apu.recurso and linea_apu.recurso.cpc:
                        cpc_porc = float(linea_apu.recurso.cpc.porcentaje or 0)
                    vae_rubro += (subtotal / costo_directo) * (cpc_porc / 100)
            
            peso_relativo = float(line.precio_total) / project_total if project_total > 0 else 0
            vae_ponderado = vae_rubro * peso_relativo
            project_vae_total += vae_ponderado

            table_data.append({
                "ITEM": self._resolve_budget_line_report_item(line),
                "DESCRIPCION": self._normalize_report_description(line.descripcion),
                "UNIDAD": line.unidad or "",
                "CANTIDAD": float(line.cantidad) if line.cantidad else 0.0,
                "PUNITARIO": float(line.precio_unitario) if line.precio_unitario else 0.0,
                "PGLOBAL": float(line.precio_total) if line.precio_total else 0.0,
                "PESORELAT": peso_relativo,
                "VAERUBRO": vae_rubro,
                "VAEPOND": vae_ponderado
            })

        data["#VAE_TOTAL"] = project_vae_total
        formatted_data = self._format_excel_data(
            data,
            {
                "#IVA": "money",
                "#TTOTAL": "money",
                "#VAE_TOTAL": "calc",
            },
            format_config["money_decimals"],
            format_config["calc_decimals"],
        )
        formatted_rows = self._format_excel_rows(
            table_data,
            {
                "CANTIDAD": "calc",
                "PUNITARIO": "money",
                "PGLOBAL": "money",
                "PESORELAT": "percent",
                "VAERUBRO": "calc",
                "VAEPOND": "calc",
            },
            format_config["money_decimals"],
            format_config["calc_decimals"],
        )
        return self.fill_template(
            filename,
            formatted_data,
            formatted_rows,
            table_row_marker="#DESCRIPCION",
            use_omniclass=use_omniclass,
        )

    def generate_polinomica_report(self, db: Any, presupuesto_id: int, empresa_id: int, template_id: str = "001") -> io.BytesIO:
        from app.models.presupuesto import Presupuesto
        from app.models.polinomica import FormulaPolinomica
        
        presupuesto = db.query(Presupuesto).filter(Presupuesto.id == presupuesto_id, Presupuesto.empresa_id == empresa_id).first()
        if not presupuesto:
            raise ValueError("Presupuesto no encontrado")

        formula = db.query(FormulaPolinomica).filter(FormulaPolinomica.presupuesto_id == presupuesto_id).first()
        if not formula:
            raise ValueError("Fórmula polinómica no encontrada para este presupuesto")

        filename = "001 - Formula Polinomica.xlsx"
        if template_id == "002":
            filename = "002 - Formula Polinómica - sin desglose de equipo.xlsx"

        format_config = self._get_empresa_format_config(db, empresa_id)
        use_omniclass = self._resolve_use_omniclass(format_config, template_id)
        reference_code = self._get_project_reference_code(db, presupuesto)

        data = {
            "#PRO_TITULO": self._resolve_project_title(presupuesto.proyecto, presupuesto.descripcion),
            "#CODIGOPROYECTO": presupuesto.proyecto.codigo if presupuesto.proyecto else "",
            "#CODIGOREFERENCIAL": reference_code,
            "#REVISION": self._format_revision_label(presupuesto.revision),
            "#PRO_FECHA": presupuesto.fecha_creacion.strftime("%d/%m/%Y") if presupuesto.fecha_creacion else "",
            "#COEF_FIJO": float(formula.coeficiente_fijo or 0),
            "#FORMULA_POLINOMICA": ""
        }

        monomios_str = [f"{self._format_fixed(float(formula.coeficiente_fijo or 0), format_config['calc_decimals'])} (A)"]
        table_data = []
        for m in sorted(formula.monomios, key=lambda x: x.simbolo):
            monomios_str.append(f"+ {self._format_fixed(float(m.coeficiente or 0), format_config['calc_decimals'])} ({m.simbolo})")
            table_data.append({
                "SIMBOLO": m.simbolo,
                "DESCRIPCION": self._normalize_report_description(m.descripcion or m.indice_inec.descripcion if m.indice_inec else ""),
                "COEFICIENTE": float(m.coeficiente),
                "COD_INEC": m.indice_inec.codigo if m.indice_inec else ""
            })
        
        data["#FORMULA_POLINOMICA"] = " ".join(monomios_str)
        formatted_data = self._format_excel_data(
            data,
            {
                "#COEF_FIJO": "calc",
            },
            format_config["money_decimals"],
            format_config["calc_decimals"],
        )
        formatted_rows = self._format_excel_rows(
            table_data,
            {
                "COEFICIENTE": "calc",
            },
            format_config["money_decimals"],
            format_config["calc_decimals"],
        )

        return self.fill_template(
            filename,
            formatted_data,
            formatted_rows,
            table_row_marker="#DESCRIPCION",
            use_omniclass=use_omniclass,
        )

reporting_service = ReportingService()
