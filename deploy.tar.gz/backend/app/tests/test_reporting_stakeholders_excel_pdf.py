import os

import openpyxl

from app.services.reporting import ReportingService


def test_stakeholders_sheet_is_prepared_for_pdf_from_excel():
    service = ReportingService()
    workbook = openpyxl.load_workbook(os.path.join(service.templates_dir, "001 - Stakeholders.xlsx"))
    worksheet = workbook.active

    table_rows = [
        {
            "#ITEM": 1,
            "#CODIGO_STKR": "STK-0001",
            "#NOMBRES": "Nombre con datos completos",
            "#APELLIDOS": "Apellido de prueba",
            "#PROFESION": "Ingeniero civil · Institucion publica con nombre largo",
            "#DIRECCIONSTKR": "Avenida de prueba muy larga con edificio, piso y referencia adicional",
            "#CIUDADSTKR": "Quito / Distrito Metropolitano",
            "#PROVINCIASTKR": "Pichincha",
            "#PAISSTKR": "Ecuador",
            "#TELEFONOSTKR": "+593 999 999 999",
            "#CORREOSTKR": "correo.largo.de.prueba@example.com",
            "#ROL": "Fiscalizador principal del proyecto",
        },
        {
            "#ITEM": 2,
            "#CODIGO_STKR": "STK-0002",
            "#NOMBRES": "Segundo nombre",
            "#APELLIDOS": "Segundo apellido",
            "#PROFESION": "Arquitecto",
            "#DIRECCIONSTKR": "Calle corta",
            "#CIUDADSTKR": "Cuenca",
            "#PROVINCIASTKR": "Azuay",
            "#PAISSTKR": "Ecuador",
            "#TELEFONOSTKR": "+593 988 888 888",
            "#CORREOSTKR": "contacto@example.com",
            "#ROL": "Sin rol",
        },
    ]

    service._apply_template_to_sheet(
        worksheet,
        {
            "#REVISION": "R001",
            "#PRO_TITULO": "Proyecto de prueba",
            "#CODIGOPROYECTO": "PR-001",
            "#CODIGOREFERENCIAL": "REF-001",
            "#CIUDAD": "Quito",
            "#PRO_FECHA": "07/04/2026",
        },
        table_rows,
        "#ITEM",
    )
    service._prepare_stakeholders_report_sheet(worksheet, 10, len(table_rows))
    output = service._save_workbook_buffer(workbook)
    rendered_workbook = openpyxl.load_workbook(output)
    rendered_sheet = rendered_workbook.active

    assert rendered_sheet.print_area.startswith("'Hoja1'!$A$1:$L$")
    assert rendered_sheet.max_row <= 22
    assert rendered_sheet.page_setup.orientation == "landscape"
    assert rendered_sheet.page_setup.fitToWidth == 1
    assert rendered_sheet.page_setup.fitToHeight == 0
    assert rendered_sheet.row_dimensions[10].height > 25
    assert rendered_sheet["E10"].value == "Ingeniero civil · Institucion publica con nombre largo"
    assert rendered_sheet["K10"].value == "correo.largo.de.prueba@example.com"
    assert rendered_sheet["L11"].value == "Sin rol"
