import sys
import os
import json
from sqlalchemy import create_engine, inspect
from sqlalchemy.orm import Session
from decimal import Decimal
from datetime import datetime, date

# Añadir el path del backend para importar los modelos
sys.path.append(os.getcwd())
from app.core.config import settings

def custom_serializer(obj):
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError(f"Type {type(obj)} not serializable")

def export_db():
    print("Conectando a la base de datos local...")
    engine = create_engine(settings.sync_database_url)
    inspector = inspect(engine)
    db = Session(bind=engine)
    
    data = {}
    
    # Tablas críticas a exportar
    tables = inspector.get_table_names()
    
    # Si queremos todo, podemos usar inspector.get_table_names()
    # tables = inspector.get_table_names()

    try:
        from sqlalchemy import text
        with engine.connect() as connection:
            for table_name in tables:
                print(f"Exportando tabla: {table_name}...")
                try:
                    result = connection.execute(text(f"SELECT * FROM {table_name}"))
                    rows = [dict(row._mapping) for row in result]
                    data[table_name] = rows
                except Exception as e:
                    print(f"Saltando {table_name}: {e}")

        with open("db_backup.json", "w", encoding="utf-8") as f:
            json.dump(data, f, default=custom_serializer, indent=2)
        
        print("\nExportación completada: db_backup.json")
        print(f"Tablas exportadas: {', '.join(data.keys())}")

    except Exception as e:
        print(f"Error general: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    export_db()
