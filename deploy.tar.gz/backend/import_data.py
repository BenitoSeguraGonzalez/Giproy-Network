import json
import os
import sys
from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session
from datetime import datetime

# Añadir path para configuración
sys.path.append(os.getcwd())
from app.core.config import settings

def import_db():
    print("Conectando a la base de datos de producción...")
    engine = create_engine(settings.sync_database_url)
    
    if not os.path.exists("db_backup.json"):
        print("Error: No se encuentra db_backup.json")
        return

    with open("db_backup.json", "r", encoding="utf-8") as f:
        data = json.load(f)

    # Orden lógico de inserción para evitar fallos de FK
    # Primero tablas independientes, luego dependientes
    order = [
        "empresas",
        "paises",
        "unidades",
        "roles",
        "system_roles",
        "usuarios",
        "user_roles",
        "dispositivos",
        "codcpc",
        "categorias_recursos",
        "recursos",
        "proyectos",
        "presupuestos",
        "subcategorias_items",
        "apus",
        "apu_lineas",
        "presupuesto_detalles"
    ]
    
    # Añadir el resto de tablas al final si no están en la lista
    all_tables = list(data.keys())
    for t in all_tables:
        if t not in order and t != "alembic_version":
            order.append(t)

    with engine.begin() as conn:
        # Desactivar constraints temporalmente si es posible (Postgres específico)
        conn.execute(text("SET session_replication_role = 'replica';"))
        
        for table_name in order:
            if table_name not in data:
                continue
            
            rows = data[table_name]
            if not rows:
                continue
                
            print(f"Importando {len(rows)} filas en {table_name}...")
            
            # Limpiar tabla antes si es necesario (opcional)
            # conn.execute(text(f"DELETE FROM {table_name}"))
            
            for row in rows:
                columns = row.keys()
                placeholders = [f":{col}" for col in columns]
                sql = text(f"INSERT INTO {table_name} ({', '.join(columns)}) VALUES ({', '.join(placeholders)})")
                
                # Convertir strings de fecha de nuevo a objetos datetime si es necesario
                # (SQLAlchemy suele manejarlo si el dialecto lo soporta, pero Postgres es estricto)
                conn.execute(sql, row)

        # Reactivar constraints
        conn.execute(text("SET session_replication_role = 'origin';"))
        
        # Actualizar secuencias en Postgres para evitar errores de ID duplicado
        print("Actualizando secuencias...")
        for table_name in data.keys():
            try:
                # Intenta encontrar si tiene una columna 'id' con secuencia
                res = conn.execute(text(f"SELECT pg_get_serial_sequence('{table_name}', 'id')"))
                seq = res.scalar()
                if seq:
                    conn.execute(text(f"SELECT setval('{seq}', COALESCE((SELECT MAX(id)+1 FROM {table_name}), 1), false)"))
            except:
                pass

    print("\nImportación completada con éxito.")

if __name__ == "__main__":
    import_db()
